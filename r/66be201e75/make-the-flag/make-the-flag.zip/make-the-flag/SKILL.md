# /make-the-flag — Turn a Decoded Pocket Into Shirt Concepts + Prompts

The last link in the chain. Take a **decoded pocket** (who they are, how they talk, what they'd never say out loud) and turn it into the shirt itself: pick the flags this pocket waves hardest, spin ~5 concepts per flag (a phrase, a word, or a design/mark — not phrase-only), turn each concept into a generation prompt, then STOP and ask before spending a cent generating.

> **The one idea:** a design doesn't sell because it's clever or pretty. It sells when it becomes a **flag** the person would wear to say who they are. This skill picks the flags a pocket is loudest about and hands you concepts + ready-to-run prompts for each. It never guesses in a vacuum and it never auto-generates.

## Where this sits in the chain (say this to the user)
```
/parade-hunt         → find the parade (the crowd that keeps refilling)
   → pick the pocket  (one slice inside it, big but tight)      [parade-hunt flows into this]
/identity-decoder    → know the pocket (deep psychology, media diet, verbatim language)
/make-the-flag       → MAKE THE FLAG  ← YOU ARE HERE (concepts → prompts → optional generate)
```
The first three are the groundwork. This skill picks up right where a finished decode leaves off. It is USELESS on a thin decode — the flag choices and concepts are only as good as the understanding of the pocket underneath them.

## When to use
- "/make-the-flag", "make the flag", "turn this decode into shirt concepts", "give me shirt designs for this pocket", "run the flag engine", "concepts for [pocket]".
- You have a decoded pocket (from `/identity-decoder`, or an equivalent understanding) and want shirt phrase/design concepts + prompts.

## When NOT to use
- No decode yet / you only have a broad niche → run the upstream chain first (`/parade-hunt` → pick the pocket → `/identity-decoder`). This skill will OFFER to do that if you arrive without a decode.
- You already have final concepts and just want ad scenes from a finished flat design → use `/the-overlap`.
- You want to mechanically composite a design onto a PSD mockup → use `/bb-mockup`.

## The framework it applies
`references/winning-phrase-lanes.md` — the 12 flags (niche-agnostic identity mechanisms), grouped in tiers, each with a mechanism + example shapes + how to instantiate, plus the funny toolkit and the drill. READ IT before running. The 12 flags:
1. the place that defines me · 2. the hard-won stage/role · 3. what I stand for · 4. the thing I love loudly (**1–4 ≈ 70% of everything that sells**) · 5. this is my craft · 6. us together · 7. my attitude, deal with it · 8. the innocent-looking acronym · 9. you feel this too, right? · 10. what I believe / give thanks for · 11. my season / my team · 12. my role names me.

---

## ⛔ OPERATING RULES (mirror /parade-hunt, /identity-decoder, /find-angles — read before EVERY run)
1. **Never leak operator-internal plumbing.** No file paths, script names, JSON field names, token talk, retry/error mechanics. The user sees: a warm reflect, "give me a moment," then clean concepts. Do the grind silently.
2. **REFLECT first, before any work.** After you have the decode, your next message reflects the pocket back in your own words and names which way they lean — proves you read it — THEN you go pick flags. Skipping this makes it feel like a vending machine.
3. **Present as a CHOICE, gate before spend.** Show concepts + prompts, then ask "want me to generate a few samples?" Never auto-generate. Generation costs API credits — it is always a decided step, never a default.
4. **Phrase OR design — never phrase-only.** A concept can be a phrase, a single word, or a design/mark (an icon, a monogram, a shape). Design and phrase are both vehicles for the same thing: a flag they'd wear. Do not bias to text.
5. **De-fingerprint.** When this is demoed/shipped, never surface a real brand's exact winning phrase or a client-identifying detail. Instantiate the framework's example shapes for the pocket in front of you; don't recite a catalog.
6. **Each run writes to its own folder** so runs never collide: `Resources/make-the-flag/runs/<pocket-slug>/`.

---

## THE FLOW (in order — never jump to generation)

### STEP 0 — Get the decoded pocket (the fodder)
Ask for the decode. Three ways it can arrive:
- **A finished decode** — a path to an `/identity-decoder` decode HTML (or the pocket + its psychology/language pasted in). This is the ideal input.
- **A pocket name only** (e.g. "golf dads") — you can proceed on a lighter read, but SAY it's lighter and offer to run `/identity-decoder` first for a real decode.
- **Nothing / just a broad niche** — offer to run the upstream chain: `/parade-hunt` (which flows into Pick the Pocket) → `/identity-decoder`. Don't fabricate a decode.

Capture from the decode: the pocket's **sacred place, earned stage, core values, beloved object/passion, shared rituals, in-jokes, the small suffering they'd admit, their season/team/role, and their verbatim vocabulary.** These map straight onto the flags.

### STEP 1 — REFLECT the pocket (mandatory, before flag-picking)
One warm message: reflect the pocket back in your words, name what jumps out ("golf dads — the course is clearly their escape, and there's real pride in the little milestones like breaking 100"), then say you're going to pick the flags they wave hardest and go quiet.

### STEP 2 — Pick the flags for THIS pocket (score/select, not all 12)
Run the drill from `references/winning-phrase-lanes.md`:
1. **Score the 12 flags for this pocket.** Which is this crowd loudest about? Use the decode: a place-defined crowd → flag 1; a craft crowd → flag 5; a rowdy crowd → flag 7; a milestone-proud crowd → flag 2. Tiers 1–4 are the default heavy hitters (~70%); reach into 5–12 only where the decode specifically supports it.
2. **Select the strongest 3–5 flags** for this pocket (not all 12). Name the top 1–2 they wave hardest, plus the strong ones. Say in one line WHY each fits, grounded in the decode.
3. For each selected flag, note the **mode(s)** the pocket supports — sincere, funny, or both (humor is a mode you apply to a flag, never a flag by itself).

### STEP 3 — ~5 concepts per selected flag (phrase AND/OR design)
For each selected flag, generate ~5 concepts. A concept is the smallest thing that makes them nod "that's me." Mix the types — do NOT make them all phrases:
- **Phrase** — a short line in the crowd's own voice (the framework's example shapes, instantiated for the pocket).
- **Word / mark** — a single word or coined term worn as identity (a name for their stage, their place, their role).
- **Design / motif** — a visual concept with little or no text (an icon, a monogram, a silhouette, a badge, a crest) that reads as the same flag. Describe what's ON the shirt.
Each concept: a one-line label + which flag it's on + the mode + a one-line WHY it works for this pocket (so the user can judge "yeah, a person like that would wave that"). Badge-check every one: would they WEAR it to declare identity? If it's a clever line with no identity under it, cut it and repick.

### STEP 4 — Turn each concept into a FULLY ART-DIRECTED generation prompt

> 🔒 **CONFIDENTIALITY (member-facing bar):** the style library referenced below is internal and is read by the agent SILENTLY. The style *knowledge* gets used; the *source* never gets named. Nothing the member sees — not the reflect, not the concepts, not the prompts, not the output HTML — may contain a brand name, a client name, or an internal file path. Refer to the styles only by their generic names (Vintage Sunset Stripes, Retro Cartoon, Comfort-Colors Illustration, Bold Block, Y2K Sticker, Cursive+Floral, Maxxing/Definition, etc.). Never say "the [brand] style," "[brand]'s prompts," or "[brand]'s touches" in front of the member.

⛔ **The #1 failure mode of this step is a LIGHT prompt.** A one-liner like *"print-ready t-shirt design, transparent background, bold lettering reading 'X', clean vector"* is a FAIL — it hands the model no composition, no aesthetic, no craft, and it generates generic junk. The proven prompts are dense, spatially-composed art-direction specs. Match that depth or the design is worthless.

**The 8 named design styles (instantiate the full template for whichever fits the concept — match this depth, don't shortcut to a one-liner):**
1. **Vintage Sunset Stripes + Silhouette** — a rectangular band of horizontal 70s sunset stripes (red/orange/yellow/green) with heavy faded grunge distress, a black silhouette centered on top, bold black uppercase serif arched above and below flanked by small stars. Heather grey tee, product photography. *Use for: pain/struggle phrases, race-day lines.*
2. **Retro Cartoon + Comic Burst** — a hand-drawn 90s comic illustration, heavy black ink lines, comic "burst" rays, yellow/red accents, halftone shading, cartoon block-letter text arched above with a smaller subtitle in parens. References Cartoon Network / Looney Tunes. Heather olive tee. *Use for: situational humor, "the universe vs me."*
3. **Minimalist Comfort-Colors Illustration** — a simple hand-drawn line illustration (olive + soft-black line work, no shading), small lowercase script beneath, on a cream garment-dyed Comfort Colors tee styled flat on a rattan tray. Cottagecore-adjacent, soft natural light. *Use for: whimsy/cute, women-buyer / gift angle.*
4. **Infographic / Grid** — bold white distressed sans-serif title + subtitle, then a 2x3 grid of six white stencil pictograms each with a one-line caption, all white on black, vintage distress. Black tee. *Use for: "things I do," identity inventory.*
5. **Bold Block Text Statement** — the phrase is the whole design: large heavy sans-serif (Druk / Helvetica Black), all caps, tight spacing, 2-3 lines, no decoration. Heather grey tee, premium streetwear. *Use for: punchline phrases, minimalist statement.*
6. **Y2K Drippy Sticker (back print)** — a circular back design, arched uppercase text top and bottom forming a ring, a yellow drippy melting smiley in the center, "EST. 2026" flanking. Sticker-style flat, Y2K-coded, cream Comfort Colors tee, candid outdoor shot. *Use for: brand-feel mantras.*
7. **Cursive Script + Floral** — delicate white hand-lettered cursive (lowercase, flowing), a thin chain of small daisy florals beneath, on a crimson garment-dyed Comfort Colors tee styled with straw hat / dried palm props. Feminine boutique aesthetic. *Use for: positive mantras, gift, feminine identity.*
8. **Vintage Cartoon Character** — a 1950s-cartoon-style character mid-action (cream/tan/red palette, vintage line art), retro script arched above and italic script below, slight grain overlay, worn on a vibrant tee in a candid lifestyle scene. *Use for: "me when" scene-jokes.*

**Universal modifiers:** swap garment color (heather dusty pink / sage / cream / forest / vintage red / indigo / mauve); keep mockup style + lighting constant across a batch and vary only the phrase (consistency = brand feel). **Production truths:** heather grey / cream / crimson convert best; distress/grunge texture is mandatory on the vintage styles (clean vector converts worse); an "EST. 2026" mark makes a generic phrase feel like a real brand.

**The 9th style — the Maxxing / Definition format (inlined here so it's self-contained; the highest-converting typography-forward style):**
> A mock-dictionary "definition" design. WORD + phonetic pronunciation + "(verb)" + a one-line definition, rendered as flat white-ink artwork on a solid black background via Ideogram V3. Its exact visual hierarchy, top to bottom:
> 1. Large bold clean **sans-serif** block letters — the coined WORD centered at top (e.g. `GOLFMAXXING`). "Not rounded or bubbly, structured and confident like a professional logo."
> 2. Small delicate thin **radiating lines + a tiny heart accent** above the word. Generous spacing between every element.
> 3. A small **thin line-art thematic icon** below the word (a golf flag, a wine glass, a paw print — matched to the concept), often with a tiny heart.
> 4. The **phonetic pronunciation** in small clean text, e.g. `/gälf·mak·sing/`.
> 5. The **`(verb)`** notation in small italic text.
> 6. The **definition** in a clean uniform arc of hand-lettered script at the bottom, each word capitalized (e.g. "The Compulsive Pursuit Of One More Round").
> 7. "White ink only, single color, flat design, thin line-art icons, clean and airy with breathing room between all elements. No gradients, no shadows, no mockup, no t-shirt."
>
> **Exemplar (copy this depth):** *"A t-shirt graphic design on a solid black background. Large bold clean sans-serif block letters "WINEMAXXING" centered at top, not rounded or bubbly, structured and confident like a professional logo. Small delicate thin radiating lines and a tiny heart accent above. Generous spacing between elements. Below, a small thin line-art wine glass with a tiny heart. Below that in small clean text "/wīn·mak·sing/" and below that in small italic text "(verb)". Below that in a clean uniform arc, hand-lettered script text reads "Making Wine The Answer To Every Question" with each word capitalized. White ink only, single color, flat design, thin line-art style icons, clean and airy with breathing room between all elements. No gradients, no shadows, no mockup, no t-shirt."*
>
> **Ideogram V3 settings (baked into `generate.py --mode ideogram`):** `image_size: square_hd`, `rendering_speed: QUALITY`, `style: DESIGN`, `expand_prompt: false`. Locked negative: `"bubbly letters, rounded letters, childish, cartoon, mockup, t-shirt, person, body, gradient, shadow, 3d, photorealistic, cluttered, cramped, dictionary, book page, paper texture"`.
> **Text-length caution:** Ideogram accuracy drops on long text. Keep the coined WORD tight and the definition ≤7 words where possible; flag any 8+ word definition and give a shortened backup. Ideogram is for typography-heavy flat artwork; a photographic garment mockup uses NB2 instead.

**Every prompt MUST specify, explicitly (this is what makes it not-light):**
1. **A chosen style** — pick the one from the 8 named styles (or the maxxing format) that fits the concept, and instantiate its FULL template. Don't invent a vague style.
2. **The exact composition, element by element, top to bottom** — what sits where (e.g. "bold word centered at top, thin line-art icon below, arched definition at bottom"). Spatial, not a word-list.
3. **A concrete aesthetic + era reference** — "vintage retro 70s," "90s Cartoon Network / Looney Tunes," "Y2K," "cottagecore-adjacent," "premium streetwear like Druk/Helvetica Black." Never just "clean" or "modern."
4. **Exact garment + color palette** — the blank (heather grey / cream Comfort Colors / crimson / black), the ink colors, single vs multi-color. Use the proven converters.
5. **Texture + craft details** — distress/grunge overlay, halftone, thin line-art, hand-lettered script, fabric wrinkles — whatever the style calls for.
6. **The signature finishing touches where they fit** — a tiny heart accent, delicate radiating lines, generous spacing / "clean and airy with breathing room," "EST. 2026," a small brand seal (a generic maker's mark, not a real brand's).
7. **On-shirt text verbatim, kept SHORT** (2–5 words render cleanly; 8+ garbles — flag long ones and give a shortened backup).
8. **The negative/exclusion tail** — "no gradients, no shadows, no mockup, no t-shirt" (for a flat artwork prompt) or the style's own exclusions.

**Two prompt shapes:**
- **Flat design artwork (default for these)** → a **text-to-image** prompt in the maxxing/Ideogram style (`fal-ai/ideogram/v3`, `style:"DESIGN"`, black background, the locked negative_prompt) when it's typography-forward, OR a **mockup-style** NB2 prompt (garment mockup, front-facing/flat-lay, product photography) when following one of the 8 running-style templates. Either way, instantiate a FULL template, not a sentence.
- **Design held on a worn shirt (only if a finished flat design already exists)** → an **`/edit` reference-image** prompt in the `/the-overlap` style.

Aim for prompts in the **60–120 word range** like the reference examples — if a prompt is one sentence, it's too light, go back and art-direct it. Note which style each concept uses (by its generic style name). Group the prompts by flag, each in a copy-ready block.

### STEP 5 — GATE: present, then ask "generate? y/n"
Present the full set: selected flags (with why) → concepts per flag (labelled, typed, with the why) → the prompts. Then ask, plainly: **"Want me to generate a few samples so you can see them, or leave it here with the concepts + prompts?"** Do NOT generate before this answer. This is the spend gate.

### STEP 6 — Optional generation (ONLY after a yes)
If the user says yes, generate ~5 samples (a taste, not the whole batch) using the verified NB2 mechanics below. Reuse `/batch-nb2-generate` — do NOT re-implement the client. Output to `Resources/make-the-flag/runs/<pocket-slug>/images/`, then build a small review grid and LOOK at the results before declaring done.

> ⚠️ Generation spends API credits. Only run it on an explicit yes. The reference `generate.py` in this skill folder is the runnable capability — it is NOT auto-invoked.

**Verified NB2 mechanics (from `/batch-nb2-generate`, do not deviate):**
- `FAL_KEY` from the repo `.env` (or the `FAL_KEY` environment variable). `generate.py` reads it via `--env-file` / the `FAL_KEY` env var — no filesystem path is hardcoded.
- **Text-to-image (design/mark, no reference):** `fal_client.subscribe('fal-ai/nano-banana-2', arguments={{'prompt':..., 'num_images':1, 'aspect_ratio':'4:5'}})` — MUST use `subscribe()`, MUST use `aspect_ratio` string (NOT `image_size` dict — it's silently ignored → landscape).
- **`/edit` (design held via reference image):** `fal_client.submit('fal-ai/nano-banana-2/edit', arguments={{'prompt':..., 'image_urls':[data_url], 'image_size':{{'width':1024,'height':1280}}, 'num_images':1}})` then `result.get()` — MUST use `submit()+get()` (subscribe blocks silently on /edit); `image_urls` is an ARRAY; design is a base64 data URL.
- Sequential loop, `num_images:1` each.

---

## OUTPUT
- `Resources/make-the-flag/runs/<pocket-slug>/concepts.html` — the deliverable: selected flags (why each) → concepts per flag (label · type · mode · why) → copy-ready prompts. Styled to match the `/identity-decoder` + `/the-overlap` family so the whole chain looks like one system.
- `Resources/make-the-flag/runs/<pocket-slug>/images/` — sample generations (ONLY if Step 6 ran).
- `Resources/make-the-flag/runs/<pocket-slug>/review.html` — keep/regenerate grid (ONLY if Step 6 ran).

## The chain, composed (for the demo + the user)
Worth naming out loud: *this isn't one prompt — it's a chain of skills that hand off to each other.* `/parade-hunt` (find the parade, pick the pocket) → `/identity-decoder` (know the pocket) → `/make-the-flag` (make the flag). Each does a real job. This skill is the last link, and it deliberately stops before spending money so you decide what's worth generating.

## Reference

**Ships in this bundle — read these:**
- `references/winning-phrase-lanes.md` — the 12 flags, the funny toolkit, the drill (the framework this applies). This is the only file you need to read to run the skill.
- `generate.py` (this folder) — the runnable generation capability (modes: ideogram / t2i / edit), invoked ONLY after the Step 5 gate.

**Related skills — NOT part of this bundle.** These are separate skills in the same chain. If they
aren't installed, that is normal and this skill runs fine without them — do not try to read them and
do not report them as missing files.
- `/identity-decoder` — what a decoded pocket contains (this skill's ideal input).
- `/parade-hunt` — the parade → pocket step upstream.
- `/the-overlap` — the reference-image `/edit` style for putting a finished design on a worn shirt.
- `/batch-nb2-generate` — the generation mechanics `generate.py` implements (already built in here).
- **Free/public counterpart:** `make-the-flag-public` — the light, single-crowd version (top 1-2 flags, ~3 concepts each, prompts only, no generation). Keep the wedge consistent with this file: the paid version adds full-flag scoring, the complete 5-concepts-per-flag set, the full art-direction depth (the 9 named styles), and built-in generation.
