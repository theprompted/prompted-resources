# Winning Phrase Lanes — a niche-agnostic framework for t-shirt phrases

> **What this is:** the portable model for writing print-on-demand shirt phrases that SELL, for
> ANY niche or pocket — goths, golfers, gardeners, anything. It gives an agent a fixed menu of
> proven *identity mechanisms* to drive down, so phrase-writing is a structured pick, not a guess.
> The examples here are illustrative shapes you adapt to the crowd in front of you — never copy
> them verbatim, instantiate them for the niche.

---

## The one idea everything rests on

**A winning shirt phrase is an IDENTITY BADGE.** People buy the shirt to *wear who they are* —
"this is my place / my stage / my values / my thing / my tribe / my attitude." If a candidate
phrase isn't something the crowd would proudly WEAR to declare identity, it's off-lane — repick.

It wins on **two axes**, and an agent picks BOTH:
1. **WHICH identity?** → pick a LANE from the menu below.
2. **HOW delivered?** → **sincere** (aspirational, heartfelt) or **funny** (a wink).
   Humor is a MODE you apply to a lane, **never a lane by itself.** Pick the identity first, then
   decide the tone. A clever pun with no identity underneath it does not sell.

**Match the lane to the POCKET, not to your own taste.** If someone is building across several
niches at once (goths + golfers + goldfish), run this same menu independently for each — the menu
is universal, the words you drop in are per-niche.

---

## The lane menu

Lanes are grouped by how broadly they tend to work (Tier 1 = the safest, highest-pull bets; reach
into Tier 3 when the pocket specifically fits). Each lane: the **mechanism** (why it wins),
**example shapes** (adapt, don't copy), and **how to instantiate** for your niche.

### Tier 1 — start here

**1. The place that defines me**
Mechanism: the crowd claims a PLACE as identity — the spot where they're most themselves. "This is
where I belong." Low-risk, universally legible.
Shapes: *"Life Is Better On The Trail"* · *"The Range Is My Happy Place"*
Instantiate: name the crowd's sacred place (the course, the range, the trailhead, the con, the
studio) → drop into "Life Is Better At/On [place]" or "[place] Is My Happy Place."

**2. The hard-won stage or role**
Mechanism: they wear a life-STAGE or ROLE they EARNED as a badge — "I get to be this now." Pride +
permission. Works sincere OR funny.
Shapes: sincere *"Rocking The [status] Life"* · funny *"Does This Shirt Make Me Look [status]?"*
(borrow a familiar vanity question, swap the punchline to the identity).
Instantiate: what status did this crowd earn or level into? (veteran, black-belt, empty-nester,
"finally allowed to," level-100). Put it in the earned-badge or vanity-question shape.

**3. What I stand for (values)**
Mechanism: a short value/virtue signaled to the world — "this is what I'm about." Sincere,
gift-able, flatters the wearer's self-image.
Shapes: *"Spread Calm"* · *"Choose Grit"* · *"Stay Curious"*
Instantiate: name the crowd's core value (patience, grit, stillness, generosity) → imperative +
value: "Choose ___" / "Spread ___" / "Stay ___."

**4. The thing I love loudly**
Mechanism: an over-the-top declared love for the passion or companion. The volume IS the badge.
Sincere ("[thing] Love") or funny (reframe a nuisance of the thing as something they adore).
Shapes: sincere *"Horse Love"* / *"Yarn Love"* · funny *"Cat Hair Is My Glitter"* /
*"Chalk Dust Is My Glitter"*
Instantiate: name the beloved object/companion of the niche → declare "[thing] Love," OR take a
downside of loving it (hair, dust, mess, cost, lost time) and reframe it as treasure.

### Tier 2 — strong, common

**5. This is my craft**
Mechanism: the ACT of making/doing is the identity — "I'm someone who does this." Sincere
("[craft] Heart") or funny (a mash-up word capturing the vice of the craft).
Shapes: sincere *"Pottery Heart"* / *"Garden Heart"* · funny *"Procrasti-[craft]"* /
*"[craft]-aholic"* (jokes about doing it too much).
Instantiate: name the niche's core activity → "[activity] Heart" (sincere) or a portmanteau that
teases doing it too much (funny).

**6. Us, together (belonging)**
Mechanism: marks a TRIBE or shared ritual — "we do this together." Bought in groups/sets. Sincere
("[group] Trip") or funny (a cheeky in-joke about the group's ritual).
Shapes: sincere *"Crew Trip"* / *"Squad Weekend"* · funny *"Oh [ritual-pun] It's A [group] Thing"*
Instantiate: name the shared ritual/outing and the group word → a matching-set phrase, or a pun on
the ritual's signature action.

**7. My attitude, deal with it** (usually funny)
Mechanism: deadpan defiance — a flat, unbothered stance they're proud of. The lack of apology is
the joke.
Shapes: *"Not Sorry"* · *"Hard Pass"* · *"Feral By Choice"* (short, flat, no softening).
Instantiate: what does this crowd refuse to apologize for? State it flat, 2–4 words.

### Tier 3 — specialist mechanics (reach when the pocket fits)

**8. The innocent-looking acronym** (funny)
Mechanism: letters read one (cheeky) way at a glance, then reveal an innocent meaning — the
mismatch is the joke. The reveal MUST be legible on the shirt or there's no punchline.
Shape: build a fresh acronym from the niche — letters that look edgy, expansion that's
wholesome-niche (*"OMG = Old Men Golfing"*).
Instantiate: find 2–4 letters that look cheeky, expand them into the niche's wholesome reality.

**9. You feel this too, right?** (funny)
Mechanism: names a shared low-grade struggle so relatably the crowd has to nod. Bonding through
admitted imperfection.
Shapes: *"It's Fine, I'm Fine"* · *"[niche thing] Ruined My Plans, I'm Fine"*
Instantiate: name the universal small suffering of the niche, then shrug it off out loud.

**10. What I believe / give thanks for** (sincere)
Mechanism: faith or gratitude stated plainly as identity. Gift-heavy, spikes around holidays.
Shapes: *"[virtue] Over [fear]"* · *"Blessed With [niche thing]"*
Instantiate: the crowd's belief or gratitude, stated as a calm declaration.

**11. My season / my team** (sincere)
Mechanism: a season, holiday, or allegiance worn as a flag. Time-boxed demand spikes.
Shapes: *"Just A [person] Who Loves [season/team]"* · *"Wake Me When [season] Is Back"*
Instantiate: the season/team the crowd rallies around, worn as identity.

**12. My role names me** (sincere)
Mechanism: a role (in a family, a community, a game) as proud identity — "who I am to others is who
I am."
Shapes: *"My Favorite People Call Me [role]"* · *"[role] Life Is The Best Life"*
Instantiate: the crowd's defining role → drop into a "call me ___" or "___ life" shape.

---

## The Funny toolkit (the "how" of the funny mode)

There are only **two base modes**: **sincere** (said straight, she means it) and **funny** (with a
wink). But "funny" isn't one move — it's a small set of repeatable joke-engines. Pick a lane first,
then if the mode is funny, reach into this toolkit for the mechanism. (Each still sits ON a lane —
none of these is a lane by itself.)

| Funny sub-mechanic | The move | Example shape |
|--------------------|----------|---------------|
| **Reframe-the-nuisance** | take a downside of the thing she loves and call it a treasure | "[mess] Is My Glitter" |
| **Deadpan defiance** | a flat, unapologetic stance, 2–4 words, no softening | "Not Sorry" · "Hard Pass" |
| **Portmanteau / mash-up** | coin a word that names the vice of the craft | "Procrasti-[craft]" · "[craft]-aholic" |
| **Acronym reveal** | cheeky-looking letters → wholesome payoff (reveal MUST be legible) | "[letters] = [wholesome-niche]" |
| **Relatable overwhelm** | admit a shared small struggle, then shrug it off | "It's Fine, I'm Fine" |
| **Borrowed-format flip** | hijack a familiar phrase, swap the punchline to the identity | "Does This Shirt Make Me Look [status]?" |
| **Ritual pun** | pun on the group's signature action | "Oh [ritual-pun] It's A [group] Thing" |
| **Cliché-flip** | take the cheesy version of the niche she HATES, flip it into her own joke | riff on the "[cheesy niche slogan]" she rolls her eyes at |

Sincere has no sub-menu — it's a straight, calm declaration of the identity. Its craft is in
brevity and truth, not mechanism.

---

## The drill (how an agent uses this for a locked niche + pocket)

1. **Score the lanes for THIS pocket.** Which 1–2 lanes is this crowd loudest about? (A place
   crowd → lane 1; a hobby crowd → lane 5; a rowdy crowd → lane 7.) Name the top lane.
2. **Pick the mode** — sincere or funny. Many crowds support both; offer one of each.
3. **Write to the trigger, in the crowd's voice.** Use the lane's mechanism as the brief and write
   the SHORTEST phrase that makes them nod "that's me."
4. **Badge check.** Would they WEAR this to say who they are? If it's just a clever line with no
   identity under it, it's off-lane — go back to step 1.

---

## Rules to protect (do not violate)

- **Never copy a real brand's winning phrase.** The example shapes here are generic on purpose.
  Instantiate them for the crowd in front of you; don't recite a catalog.
- **Humor is a modifier, not a lane.** Always pick identity first.
- **One level of abstraction up.** A lane is a mechanism ("a hard-won stage becomes a badge"), not
  a specific instance. That's what makes it work for goths, golfers, and goldfish alike.
