#!/usr/bin/env python3
"""make-the-flag · generation capability (the LAST step, run ONLY after the Step 5 gate).

This is the runnable capability the skill wires in. It is NOT auto-invoked and it will NOT
generate anything unless you pass --go, so it can never accidentally spend API credits.

Two modes, matching the verified /batch-nb2-generate mechanics:
  - t2i   (default): text-to-image for a design/mark/motif with no reference.
                     Uses fal_client.subscribe('fal-ai/nano-banana-2', aspect_ratio='4:5').
  - edit           : hold an existing flat design EXACT via a reference image.
                     Uses fal_client.submit('fal-ai/nano-banana-2/edit', ...).get(), image_urls array.

Prompts file: a JSON list of {"label": str, "prompt": str} (+ optional "negative_prompt";
for edit mode also "ref": path-to-design-png). Output PNGs land in <out>/.

Usage (dry run — prints what WOULD generate, spends nothing):
    python3 generate.py --prompts run/prompts.json --out run/images
Usage (actually generate ~5 samples — spends credits, only after the user said yes):
    python3 generate.py --prompts run/prompts.json --out run/images --mode t2i --limit 5 --go
"""
import argparse, base64, json, os, sys


def load_fal_key(env_file=None):
    """Read FAL_KEY from the environment, or from an optional .env file, without a dotenv dependency."""
    if os.environ.get("FAL_KEY"):
        return os.environ["FAL_KEY"]
    # Fall back to a .env file: the one passed via --env-file, else a .env in the cwd.
    for path in (env_file, ".env"):
        if not path:
            continue
        try:
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if line.startswith("FAL_KEY="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
        except FileNotFoundError:
            continue
    return None


def data_url(path):
    with open(path, "rb") as fh:
        return "data:image/png;base64," + base64.b64encode(fh.read()).decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompts", required=True, help="JSON list of {label, prompt[, negative_prompt, ref]}")
    ap.add_argument("--out", required=True, help="output dir for PNGs")
    ap.add_argument("--mode", choices=["t2i", "edit", "ideogram"], default="t2i",
                    help="t2i=NB2 scene/mockup, edit=NB2 hold-design-via-ref, ideogram=Ideogram V3 flat vector artwork (best for typography-forward designs on black)")
    ap.add_argument("--limit", type=int, default=5, help="max samples (a taste, not the whole batch)")
    ap.add_argument("--go", action="store_true",
                    help="ACTUALLY generate (spends API credits). Without it, this is a dry run.")
    ap.add_argument("--env-file", default=None,
                    help="optional path to a .env holding FAL_KEY (defaults to $FAL_KEY, then ./.env)")
    args = ap.parse_args()

    with open(args.prompts) as fh:
        prompts = json.load(fh)
    prompts = prompts[: args.limit]
    os.makedirs(args.out, exist_ok=True)

    if not args.go:
        print(f"DRY RUN — mode={args.mode}, would generate {len(prompts)} sample(s). Spends nothing.")
        print("Pass --go to actually generate (only after the user said yes at the gate).\n")
        for i, p in enumerate(prompts, 1):
            print(f"  [{i}] {p.get('label','(no label)')}")
            print(f"      {p['prompt'][:120]}{'...' if len(p['prompt'])>120 else ''}")
            if args.mode == "edit":
                print(f"      ref: {p.get('ref','(MISSING — edit mode needs a ref design)')}")
        return

    key = load_fal_key(args.env_file)
    if not key:
        sys.exit("FAL_KEY not found (checked $FAL_KEY, --env-file, and ./.env). Cannot generate.")
    os.environ["FAL_KEY"] = key
    import fal_client  # imported only on --go so dry runs need no dependency

    for i, p in enumerate(prompts, 1):
        label = p.get("label", f"sample-{i}")
        slug = "".join(c if c.isalnum() or c in "-_" else "-" for c in label.lower())[:48]
        save_path = os.path.join(args.out, f"{i:02d}-{slug}.png")

        if args.mode == "ideogram":
            # Ideogram V3 — the tool for typography-forward flat artwork. subscribe(), style DESIGN.
            # Per-prompt negative_prompt overrides the default if provided.
            default_neg = ("bubbly letters, rounded letters, childish, cartoon, mockup, t-shirt, "
                           "person, body, gradient, shadow, 3d, photorealistic, cluttered, cramped, "
                           "dictionary, book page, paper texture")
            result = fal_client.subscribe(
                "fal-ai/ideogram/v3",
                arguments={
                    "prompt": p["prompt"],
                    "image_size": "square_hd",
                    "rendering_speed": "QUALITY",
                    "style": "DESIGN",
                    "expand_prompt": False,
                    "num_images": 1,
                    "negative_prompt": p.get("negative_prompt", default_neg),
                },
            )
            url = result["images"][0]["url"]
            import requests
            open(save_path, "wb").write(requests.get(url).content)
        elif args.mode == "t2i":
            # Mode B — MUST use subscribe() + aspect_ratio string (image_size dict is ignored here).
            result = fal_client.subscribe(
                "fal-ai/nano-banana-2",
                arguments={
                    "prompt": p["prompt"],
                    "negative_prompt": p.get("negative_prompt", ""),
                    "num_images": 1,
                    "aspect_ratio": "4:5",
                },
            )
            url = result["images"][0]["url"]
            import requests
            open(save_path, "wb").write(requests.get(url).content)
        else:
            # Mode A — /edit holds the design exact. MUST use submit()+get(), image_urls as ARRAY.
            ref = p.get("ref")
            if not ref:
                print(f"  [{i}] SKIP {label} — edit mode requires a 'ref' design path.")
                continue
            handle = fal_client.submit(
                "fal-ai/nano-banana-2/edit",
                arguments={
                    "prompt": p["prompt"],
                    "image_urls": [data_url(ref)],
                    "image_size": {"width": 1024, "height": 1280},  # 4:5
                    "num_images": 1,
                },
            )
            result = handle.get()
            url = result["images"][0]["url"]
            import urllib.request
            urllib.request.urlretrieve(url, save_path)

        print(f"  [{i}] saved {save_path}")

    print(f"\nDone. {len(prompts)} sample(s) in {args.out}. Now LOOK at them before declaring done.")


if __name__ == "__main__":
    main()
