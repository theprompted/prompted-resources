# /identity-decoder — Discover a Market's Hidden Buyer Identities

Decode the psychological terrain of a market: surface the distinct buyer archetypes worth pursuing, let the user choose which one to go deep on, then generate hyper-specific creative ammunition for that one identity.

A **3-step wizard**: SCAN (5 scored archetypes) → user PICKS one → DECODE (deep psychology + media diet + language). Targeting that feels like mind-reading.

> The full (private/in-program) version: SCAN + DECODE. Same prompts, output structure, and depth as the UI tool, generated through a skill. One genuine upgrade over the UI: the SCAN is grounded in **real review/forum research**, not inferred from the product page alone. (The free/public counterpart is `identity-decoder-public` — decode-only, no scanner.)

---

## When To Use
- "decode the market for [product]" · "find the buyer identities for [brand]" · "who actually buys [product]" · "run identity decoder on [url]"
- The first move when you need to understand who a market's real buyers are and which one to build creative for.

## Output
Two files in the working/client folder: `[product-slug]-identity-scan.html` (the 5 scored archetypes) and `[product-slug]-identity-decode-[archetype-slug].html` (the deep decode of the chosen one). HTML styled to mirror the tool's UI. Verbatim/visceral language throughout.

---

## STEP 1 — SCAN (Market Scanner)

**System role:** You are a Creative Strategy Decoder focused on DISCOVERY. Scan the psychological terrain of a market and surface the distinct buyer archetypes worth pursuing. You are NOT generating full creative ammunition yet — you're helping the user CHOOSE where to go deep. This is the reconnaissance pass: enough signal to make an informed decision about which buyer identity to pursue first, without drowning in detail.

**Research first — the SOURCE ARCHITECTURE (the upgrade over the UI):** before generating archetypes, do real web research. Read the product page first, then go to the sources below. These are chosen deliberately: LLMs ingest **text-heavy, HTML-clean** pages far more accurately than visual/video-first platforms, so we point research at the places where real buyers leave *written* language — that's where the verbatim gold is, and it's what a model can actually read reliably.

**Tiered source list (use WebSearch/WebFetch; hit as many tiers as the product allows):**
1. **Review platforms** (highest signal, most text-dense): Amazon/retailer reviews, Trustpilot, dedicated review sites (e.g. Innerbody-type), the brand's own reviews.
2. **Forums & communities** (unfiltered self-talk): relevant subreddits (search `site:reddit.com [product/category]`), Quora, niche forums. This is where people describe their problem to *each other*, not to a brand.
3. **Competitor & category copy:** competitor review sections + competitor ad/landing copy, to see the beliefs already in the market.
4. **Creator/skeptic content (transcripts/comments, not the video itself):** "is [product] worth it" reviews, "[product] honest review" — mine the *text* (titles, comments, transcripts), since that's the HTML-readable part.

**Rules:** Never fabricate — verbatim language beats inference. Pull the actual words real buyers use. **Record which sources you actually hit** (name them: e.g. "Trustpilot 4.6★, r/Supplements, Innerbody, acoupleconsumers 8-wk review") and surface that list in the output header — so the run's sophistication is visible and verifiable, not claimed. If a source tier returns nothing usable, note it rather than inventing.

**Generate exactly 5 distinct buyer archetypes.** Each needs exactly these 9 fields:
1. **name** — evocative, memorable ("The Heritage Guardian", "The Workboot Warrior")
2. **identity** — three visceral sentences (own line each): (1) who they are + surface situation, (2) the deeper truth about what they're running FROM, (3) what they're secretly running TOWARD. Insightful, not informative — reveal psychology they wouldn't admit out loud.
3. **marketLevel** — `large` (30%+ of addressable market) | `moderate` (10-30%) | `niche` (<10%)
4. **marketValue** — total annual market value (e.g., "$1.8B/year")
5. **marketEvidence** — 2-3 sentences showing your math: demographic size → % actively seeking this solution → average annual spend. Specific to THIS archetype + THIS category.
6. **captureScenario** — the 1%-capture dollar amount (e.g., "$18M/year")
7. **conversionScore** — 1-10 (8-10 = low friction, 5-7 = moderate, 1-4 = high friction)
8. **conversionRationale** — 2-3 sentences: psychological readiness, barriers, urgency, what it takes to convert them
9. **whyThisRanking** — 3-4 sentences synthesizing market size AND conversion ease into an expert strategic take

Requirements: EXACTLY 5 · identity-level specificity (each feels like a real person with a face, a life, a moment of shame) · visceral "running from / running toward" language · name the fear, show the desire.

**Score + sort.** Opportunity score = `(marketWeight × 0.4) + (conversionScore × 0.6)`, where marketWeight = large→10, moderate→6, niche→3. Sort descending; the top one is the ⭐ Top Pick. Friction label: ≥8 "Low friction", ≥5 "Moderate friction", else "High friction". Market-level label: large "30%+ of market", moderate "10-30% of market", niche "<10% of market".

**Present the scan** as: a comparison table (# · Archetype · Market Size · Conversion · Opportunity, ⭐ on top pick) + detailed profiles for each. Then **STOP and ask the user which archetype to decode deeply.** Do not auto-pick. This is the hand-holding moment — the whole point of the two-stage design.

---

## STEP 2 — DECODE Pass 1 (Psychology Deep Dive)

Once the user picks an archetype, generate all **10 psychology sections** for THAT archetype only — **all ten, every time.** This is full-fidelity output that mirrors the UI tool; producing only the "obvious" 4-5 (triggers/beliefs/shame/workarounds) and stopping is the #1 failure mode. The back half (aspirationalIdentity, hiddenRisks, tinyWins, momentOfTriumph, identityContradiction, avoidanceIdentity) is exactly where the differentiated creative ammunition lives — it is NOT optional. Each finding 1-2 sentences max — raw creative ammunition, not essays. Stay in character: everything belongs to this ONE archetype, don't blend. Use pronouns (they/she/he), not the archetype name repeated.

Each section = a **preface** (2-3 sentences bridging the principle to THIS archetype's situation) + the **findings array**:

| Section | Label | # findings |
|---|---|---|
| triggerMoments | Trigger Moments | 5-8 life moments that trigger purchase consideration |
| limitingBeliefs | Limiting Beliefs | 3-6 stories they tell themselves that hold them back |
| privateShame | Private Shame / Frustration | 3-6 hidden frustrations they'd never post publicly |
| currentWorkarounds | Current Workarounds | 5-8 bad solutions they're cobbling together now |
| aspirationalIdentity | Aspirational Identity | 3-6 aspects of who they want to become |
| hiddenRisks | Hidden Risks | 3-6 unspoken fears about purchasing |
| tinyWins | Tiny Wins | 5-8 small signals something is working |
| momentOfTriumph | Moment of Triumph | 3-6 future moments they've imagined |
| identityContradiction | Identity Contradiction | preface + **tension** ("I want X, but Y") + **sharp** (a more visceral version) |
| avoidanceIdentity | Avoidance Identity | 3-6 identities they're terrified of becoming |

Each section in the report is prefixed with its hardcoded **"wise preface"** (see `reference/wise-prefaces.md`) shown in italics under "The Principle", then the archetype-specific preface, then the findings.

---

## STEP 3 — DECODE Pass 2 (Media Diet + Language)

For the same archetype, generate content-consumption + language. Each example 1-2 sentences. Full descriptive examples — NOT @handles.

- **Image Content They Consume** — preface + 4-6 objects, each: `category` (descriptive, e.g. "Relatable Night Sweat Memes"), `examples` (3-5 full descriptions), `whyEngage` (1-2 sentences)
- **Video Content They Consume** — preface + 4-6 objects, same shape
- **Words & Hooks** — preface + `vocabulary` (6-12 words/phrases that resonate) + `hooks` (3-6 scroll-stopping headline-style hooks)

---

## OUTPUT — HTML report (mirror the UI)

Write the scan as `[slug]-identity-scan.html` and the decode as `[slug]-identity-decode-[archetype].html`, styled with the **PromptedOS design system** (`.claude/skills/promptedos-html-design/SKILL.md` — teal accents, offset shadows, mono headers). Structure:

- **Scan report:** title + comparison table (scored, ⭐ top pick) → detailed archetype cards (identity 3-liner · Market Size block · Conversion block · Opportunity score + why-this-ranking).
- **Decode report:** the chosen archetype summary at top → the 10 psychology sections (each: label → "The Principle" wise-preface in italics → archetype preface → findings as a list; identityContradiction renders tension + sharp) → media diet (category cards with examples + whyEngage) → vocabulary chips + hooks list.

**Verify before done — TWO gates, both required (a clean render is NOT enough):**

1. **Completeness gate (full fidelity — this is the one runs skip).** The decode MUST match the UI tool's depth. Before declaring done, count what you actually produced and confirm every item below is present. If any is missing, the decode is INCOMPLETE — go back and generate it. Do not ship a partial decode.
   - [ ] All **10** psychology sections present (not 5, not 8): triggerMoments · limitingBeliefs · privateShame · currentWorkarounds · **aspirationalIdentity** · **hiddenRisks** · **tinyWins** · **momentOfTriumph** · **identityContradiction** (with both `tension` AND `sharp`) · **avoidanceIdentity**.
   - [ ] Each section has its **wise preface** (from `reference/wise-prefaces.md`) + an archetype-specific preface + the findings, and each section hits its **minimum finding count** from the table above (e.g. triggerMoments ≥5, limitingBeliefs ≥3).
   - [ ] Media diet is the **full** Pass 2: Image Content (**4-6** category objects, each with `category` + `examples` + `whyEngage`) · Video Content (**4-6** objects, same shape) · Words & Hooks (vocabulary **6-12** + hooks **3-6**). NOT collapsed into flat bullet lists.
   - State the counts explicitly when you finish (e.g. "10/10 psych sections, image 5 cats, video 4 cats, 9 vocab, 4 hooks") — surfacing the numbers is how the gate is enforced. A light decode (the trap: 5 psych sections + 3 bullet media lists) is a FAIL even if it looks clean.

2. **Render gate.** Screenshot the rendered HTML (agent-browser full page; `npx agent-browser` if not on PATH) and confirm it renders clean before declaring complete.

## Reference
- Wise prefaces (hardcoded section intros) + full field spec: `reference/wise-prefaces.md`
- Free/public counterpart: `identity-decoder-public` (decode-only — use the full version here when you also need the market scanner to find + rank which buyer to decode).
