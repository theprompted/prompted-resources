# Identity Decoder — Wise Prefaces (hardcoded section intros)

These are the "wise preface" texts shown for each section. In the report, each section shows its label, then **"The Principle"** with the matching preface below in italics, then the archetype-specific preface, then the findings.

## Psychology sections

**Trigger Moments** — People don't go from zero to purchase because of an ad. Something was already brewing—a comment that stung, a moment of doubt, a question they couldn't shake. Your ad doesn't create the desire. It meets them when the desire is already forming. The brands that win aren't the loudest. They're the ones that show up at the exact moment someone is finally ready to hear it. Timing isn't luck—it's understanding what's already happening in their life before they ever see your ad.

**Limiting Beliefs** — The thing stopping them from buying isn't price or timing. It's a story they've told themselves so many times it feels like fact. "I'm not the kind of person who spends money on this." "This probably won't work for someone like me." "I've tried things before." These beliefs run quietly in the background, filtering out your message before it ever lands. Name the belief out loud, and something shifts. You're no longer selling a product—you're offering permission to think differently about themselves.

**Private Shame / Frustration** — What they complain about publicly is rarely what keeps them up at night. The real friction lives in the things they'd never post—the quiet frustrations they assume nobody else would understand. The embarrassment they laugh off. The resentment they swallow. This is where purchase decisions actually get made—not in logic, but in the need to stop feeling a certain way. When your marketing speaks to the thing they've never said out loud, they don't just feel seen. They feel relieved that someone finally gets it.

**Current Workarounds** — Before they find you, they're already solving the problem—badly. Duct tape solutions, half-measures, making do. They've Frankensteined something together from YouTube videos, Amazon purchases, and advice from people who don't really understand. These workarounds reveal what they actually care about—they cared enough to try. When you understand what they're cobbling together, you understand what they're ready to replace. Your product isn't introducing a new problem to solve. It's offering a better answer to one they've been wrestling with for a while.

**Aspirational Identity** — People don't buy products. They buy the version of themselves they're trying to become. The question isn't what your product does—it's who they believe they'll be once they own it. Every purchase is a bet on a future self: more put-together, more confident, more aligned with who they want to be seen as. The features matter less than the identity they're reaching toward. When your marketing reflects that future version back to them—clearly, specifically—you're not convincing them to buy. You're helping them become who they already want to be.

**Hidden Risks** — Every purchase carries an unspoken fear: what if this doesn't work? What if I look foolish? What if it's not for someone like me? These aren't objections they'll type in a chat box. They're the quiet hesitations that make them close the tab and "think about it." Until you address the risk they're not saying out loud, they'll hesitate—even when they want to buy. The best marketing doesn't just sell the upside. It quietly removes the fear that's been blocking the decision all along.

**Tiny Wins** — Transformation isn't one big moment. It's a series of small signals that something is working—a glance, a comment, a feeling they notice before anyone else does. The compliment they weren't expecting. The morning they felt slightly different. The moment they caught themselves doing something they didn't used to do. These micro-victories are what they're really buying. Not the end state—the early evidence that they're on their way. Your marketing should name these small wins specifically, because that's what makes the bigger promise feel believable.

**Moment of Triumph** — There's a scene they've imagined—a future moment where the struggle is behind them and the change is undeniable. Maybe it's a vacation photo, a conversation with an old friend, or just a quiet morning where they finally feel at home in themselves. They can see it. They've rehearsed it in their mind. Your product is the bridge between where they are and that mental snapshot of who they'll become. When your marketing puts them in that moment—viscerally, specifically—you're not selling. You're showing them what's possible.

**Identity Contradiction** — They hold two beliefs at once: who they think they should be, and who they secretly are. The responsible one who wants to be reckless. The independent one who craves support. The practical one who dreams of something indulgent. This tension is uncomfortable—and it's where the most resonant marketing lives. Acknowledge the contradiction, and they feel understood in a way they rarely experience. You're not calling them out. You're giving them permission to be both things at once—and showing how your product fits into that complexity.

**Avoidance Identity** — Knowing who they want to become only tells half the story. The other half is who they're terrified of becoming—the version of themselves they're running from. The out-of-touch parent. The person who let themselves go. The one who gave up on something that mattered. This fear often drives behavior more than aspiration does. They're not just moving toward a better self—they're sprinting away from an unacceptable one. When you understand both directions, you understand the full emotional weight behind their decisions.

## Media Diet sections

**Image Content They Consume** — Your ad doesn't exist in a vacuum. It drops into a feed already full of content that trained their eye, shaped their taste, and earned their attention. The images they stop for aren't random—they're signals of what resonates: the aesthetics, the emotions, the visual language that feels like "theirs." Ads that mirror this visual diet feel native. Ads that ignore it feel like interruptions.

**Video Content They Consume** — The algorithm already knows what makes them stop scrolling. The reels they watch, save, and share reveal their emotional priorities—the pacing they respond to, the narratives that hook them, the moments that make them feel something. Video ads that match this rhythm don't feel like ads. They feel like content they chose to watch. Study what they already consume, and your ads inherit the permission they've already granted.

## Language section

**Words & Hooks** — Words are the last thing they process—but the first thing they remember. A single phrase that names what they've felt but never articulated can do more than paragraphs of explanation. The right hook doesn't convince—it resonates. It makes them stop and think, "how did they know?" This isn't about being clever. It's about being precise. The words that work don't sound like marketing. They sound like something they've quietly thought to themselves but never heard anyone else say out loud.

## Group prefaces (shown above each group)
- **Psychology:** People don't buy with logic—they buy with emotion and justify with logic later. These sections reveal the emotional operating system running beneath their conscious awareness: what triggers them, what stops them, what they're really reaching for.
- **Media Diet:** Every person has a visual diet—the content that stops their scroll, earns their attention, shapes their taste. These sections decode what that looks like for this archetype, so your creative feels native instead of intrusive.
