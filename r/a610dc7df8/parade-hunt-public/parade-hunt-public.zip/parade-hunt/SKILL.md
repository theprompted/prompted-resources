# Parade Hunt — Find Identity-Replenishment T-Shirt Niches (Parades)

Use when you want to find new POD t-shirt parades (crowds that keep refilling with new buyers) — "find me parades," "parade hunt," "candidate niches," or scout fresh niches for your portfolio.

> A "parade" = a crowd that keeps refilling with new buyers (people enter the interest, ride it, drift off, new people march in behind). Same concept this skill scores as "identity-replenishment." Renamed from `niche-hunt` 2026-06-18 to match the 1k-plan video language. Invocation: `/parade-hunt`.

## How it's invoked (channel-agnostic — one skill, two front doors)
This SKILL.md is the single source of truth. Same method runs no matter who triggers it:
1. **Directly in Claude Code** — anyone with Claude Code runs `/parade-hunt` and drives the conversation themselves (this is the direct, hands-on way to run it).
2. **Via a Slack-bot agent (for members)** — our SDK bots (pm2-managed, Claude Agent SDK — see `system/sdk-telegram-bots.md`) load this same skill and run it **for** a member through Slack. The agent IS the "Agent" in the conversation flow below; the member is the human on the other end. Same Step 0 question, same reflect-then-run, same seeded pool, same anti-collision rules — just delivered in the member's Slack DM instead of a terminal.

**The only behavioral difference between channels:** in Claude Code the operator both runs the tool and reads the output; via a bot the agent must (a) post the Step 0 question into the member's channel and WAIT for their real reply (don't self-answer), (b) run the pool/scoring server-side, (c) deliver the ranked output back into the chat (link the HTML artifact + summarize the top picks in-message), and (d) carry the reflect/lock/flow-into-Pocket beats as chat turns. Everything else is identical. The seeded-pool anti-collision is *especially* critical on the bot channel, since that's where many members run it against each other.

## ⛔ OPERATING RULES — non-negotiable, read before EVERY run
These are gates, not suggestions — they keep the member experience clean and trustworthy.

1. **NEVER leak operator-internal plumbing to the member.** This is the #1 rule. The member NEVER sees: file paths, folder names, script names, raw data fields, error messages, "let me write the pool," batch mechanics, rate-limit errors, "dead data," or any process internals. All of that is silent operator work — do it without narrating it. The member only ever sees: the seed question, a warm reflect, "give me a moment," then clean results in plain language. If you'd be embarrassed for a customer to read it, it doesn't go in the chat.
2. **The REFLECT beat is mandatory and happens BEFORE any work.** After the member answers, your VERY NEXT message reflects their specifics back warmly in your own words and names why it's promising ("a sleep-deprived dad running on coffee — love it, both the dad-world and the survival-parent crowds run deep"). THEN say you're going to look, THEN go quiet and run. Do not jump straight into building. This is the trust moment; skipping it makes the tool feel like a vending machine.
3. **Run silently; return with clean results.** Acknowledge ("give me a minute"), do all fetching/scoring/auditing WITHOUT posting progress or mechanics, then return with the ranked crowds in plain language. The member never watches the grind.
4. **If a data source fails, handle it silently — never surface the failure.** Trends getting rate-limited, a weak query, a thin candidate — that's our problem, fixed quietly behind the scenes. Never tell the member "Trends 429'd" or "this one returned dead data." Just don't show crowds you couldn't measure well; present the ones you're confident in.
5. **Present as a CHOICE, then flow into Pick the Pocket — don't decide for them, don't dead-end.** Show the ranked crowds, say "none of these is wrong — which one are you drawn to?", let THEM pick. Once they pick, give a one-line refresher of what picking the pocket means in our approach (*"now we narrow that whole crowd down to one specific slice inside it — the exact sub-group that's both big enough and easy to sell to, so your designs hit dead-on instead of spread thin"*), and invite them into it as the next step. It's a presented option, not an automated decision.
6. **Each run writes to its OWN folder** (e.g. a `runs/<seed-slug>/` folder) so runs never collide with or reuse another run's files.

## What this is

A repeatable process for finding **identity-replenishment t-shirt niches** — crowds that keep refilling so a design sells for years. Output: ranked candidates with a deep audit on the top picks. Not a brainstorm — it's data-driven scoring against a calibrated rubric.

## When NOT to use this skill

- For one-off "is X a good niche" gut checks (just answer directly)
- For competitive audit of an existing brand (use the sloth-hiking-club style competitor audit, not this)
- For brand-strategy work on an already-picked niche

## The core insight (calibrated against a proven reference niche, 94% rubric score)

**SHC didn't find a tight pre-existing tribe.** They created a *posture* (slow, self-mocking, gentle, anti-toxic-positivity) and flag-planted it inside a massive casual activity (hiking). The shirt converts the wearer into a "sloth hiker" — the identity didn't exist before the brand.

This reframes the entire search. We're not looking for tight tribes. We're looking for **massive casual activities/interests with universal pain points + self-mocking posture available + identity-replenishment behavior**.

## The Identity-Replenishment filter (most important)

Buyers in a good niche **buy multiple shirts** because their identity needs ongoing expression. Not "I own one and I'm done." Each new shirt is a stanza of the same poem.

**Signal of replenishment:** ongoing serialized content + tribal vocabulary that compounds + new in-jokes from new experiences/seasons/releases.

**Examples that pass:** Teachers (every grade/season/parent interaction = new shirt), Romance Books (every trope/book finished = new in-joke), Nurses (every shift = new dark joke), Cottagecore (every sub-aesthetic season = new flag).

**Examples that fail despite high rubric scores:** Sourdough (wardrobe ceiling at 3-4 shirts), Reactive Dogs (one good shirt = done), Stoicism (minimalist by ethos).

## The Rubric v1 (10 dimensions, weighted)

| # | Dimension | Weight | Measured by |
|---|---|---|---|
| 1 | Wide casual base | 2x | Subreddit subs + TikTok hashtag views |
| 2 | Universal pain point | 3x | Pain-language density in top 100 posts |
| 3 | Identity-aspirational, not skill-gated | 3x | Manual flag (can anyone claim membership?) |
| 4 | In-group humor/memes | 3x | Humor-language density |
| 5 | Visual codes abundant | 2x | Manual flag (per cluster) |
| 6 | Year-round | 2x | Google Trends seasonality |
| 7 | Audience self-decorates (gear-flex) | 3x | Gear-language density in top posts |
| 8 | Self-deprecating posture available | 3x | Self-mock-language density |
| 9 | Political/trademark KILL switch | KILL | Binary flag |
| 10 | Not dominated by mega-player | 2x | Competitor search |

**SHC calibration score:** 108/115 (94%). Rubric is validated.

**Known blind spot:** some crowds score LOW because their posts don't show self-mocking even though the opportunity is real — the wedge has to be *created* rather than harvested. Low rubric score doesn't always mean low opportunity. Note this when reviewing results.

## ⚠️ ANTI-COLLISION — the most important design rule (added 2026-06-19)

**The problem:** the scoring is deterministic (same sources, same rubric, same weights → same ranking). If every member runs the SAME candidate pool, every member gets the SAME top parades (Running, Horse People, Nurses…) and they compete head-to-head. With 100 members that's a manufactured bloodbath — and they'll blame us.

**The fix:** the candidate pool must be **SEEDED FROM THE MEMBER**, never a fixed list. Two members with different inputs get different pools, so they can't collide. The scoring stays identical and trustworthy; only the *starting material* personalizes. This is non-negotiable for any multi-member run.

**The expansion is where divergence is won or lost.** A weak expansion ("fitness → the same 5 obvious fitness niches") collides anyway. The seed must expand HARD along three axes so even two similar inputs branch apart:
1. **Sub-divide** — break the interest into its real sub-tribes ("fitness" → powerlifting, HYROX, run-club, calisthenics, masters-athletes…).
2. **Cross-pollinate** — combine the interest with any life-stage/identity/job the member implied ("fitness" + "new parent" → postpartum-return crowds; "fitness" + "teacher" → totally different branch).
3. **Adjacent-jump** — hop to the neighboring worlds (fitness → the *recovery* world, the *gear-nerd* world, the *coach* world).
**The more specific the member's answer, the more divergent the pool.** Lean the expansion into the axis their specifics most support.

**Secondary safeguard (light, not territory-claiming):** always surface 5+ ranked pockets and tell the member "you don't have to take #1 — here's where each one is open." So even a near-collision self-resolves without a heavy shared-state claim system. (If collisions still happen at scale, escalate to claim-and-exclude later — but seeded inputs should make that unnecessary.)

## Process

### Step 0: Get the member's seed (REQUIRED for member runs)
Ask ONE question, phrased to make them WANT to answer (not feel surveyed). The phrasing matters as much as the question — it's the product's first impression, and a good prompt pulls out the *specifics* that make the anti-collision work. **Locked phrasing (2026-06-19):**

> Let's start with you. What's something you're into, or weirdly deep on, that you could talk about forever?
>
> Don't keep it broad — the specific stuff is gold. "I run" is fine, but "I run slow and I've got two chaotic dogs" is way better.

Why this phrasing: "talk about forever" is the strongest specificity-extractor (it invites the deep, exact, slightly-nerdy answer instead of "fitness, I guess"), and the worked example *shows* them the level of detail you want. Capture the specifics — the combination is what diverges them ("I lift and I'm a teacher" → a totally different pool than "I lift and I travel"). The seed can be a theme you name, or your answer to the question above.

#### THE CONVERSATION FLOW (the canonical interaction — follow this shape)
The agent is a collaborator, not a vending machine. The shape: **ask → they answer → REFLECT their specifics back (prove you listened) → run → show ranked output → invite them to lean toward one → lock it → flow straight into Pick the Pocket.** Never dump a result without the reflect beat; never end on the result without flowing forward.

**Worked example (member = "Maria"):**

> **Agent:** Let's start with you. What's something you're into, or weirdly deep on, that you could talk about forever? Don't keep it broad — the specific stuff is gold. "I run" is fine, but "I run slow and I've got two chaotic dogs" is way better.
>
> **Maria:** lol ok. I'm a NICU nurse, night shifts. And I got really into houseplants during covid, my apartment is a jungle now.
>
> **Agent (REFLECT — repeat the specifics in your own words, name why it's good, THEN go):** Oh, that's a great combo to work with. A NICU night-shift nurse who's also a low-key plant hoarder — those are two crowds that both run deep and both love wearing their identity. Give me a minute, I'm going to find the pockets inside each that actually buy, plus a couple you might not have thought of.
>
> *(runs the seeded pool + scoring — the "cut past the wait" moment; member doesn't watch it grind)*
>
> **Agent (SHOW the output):** Okay, here's what came back. I pulled real signals on a bunch of crowds seeded from what you told me — scored on how big they are, how passionate, and whether they're growing. *[shows ranked list]* A couple jump out. "Night-shift nurses" scored really high — its own world, its own dark humor, and almost nobody's serving it well. And on the plant side, "plant-parents who over-water" is a funny, tight pocket that's wide open. None of these is a wrong answer though — scan it, which one are you leaning toward?
>
> **Maria:** honestly the night shift nurse one, that's so me
>
> **Agent (LOCK + offer Pick the Pocket as a CHOICE + refresher, no dead end):** Perfect, that's your parade — and you just did the most important step in about two minutes. So you know what's next: now we narrow that whole crowd down to one specific slice inside it. The exact sub-group that's both big enough to be worth it and easy to sell to, so your designs land dead-on instead of spread thin. For night-shift nurses, that might be new grads on nights, or one unit like ER or NICU. Want to go find your pocket?

**Rules baked into the flow (see also ⛔ OPERATING RULES above — those are the gates):**
- **Reflect FIRST, before any work** (rule 2). If the seed was thin, the reflect can fold in ONE light sharpener ("night shift — which unit?") — but only if needed; don't make it a survey.
- **Run silently; never make them watch** (rules 1, 3).
- **Present the ranked crowds as a CHOICE** — "none of these is wrong, which are you drawn to?" — never assign #1 (rule 5, anti-collision).
- **After they pick: refresher on what Pick the Pocket means in our approach, then offer it as the next step** (rule 5). Parade → pocket → design is one thread, but each handoff is a presented choice, not an automated jump.

### Step 1: Calibrate (skip if rubric is current)
If rubric weights changed, re-score SHC and confirm it still scores 85%+.

### Step 2: Build the SEEDED candidate pool (~30-40) — NOT a fixed list
Take the Step 0 seed and expand it via the three axes above (sub-divide / cross-pollinate / adjacent-jump) into ~30-40 candidate crowds. **Do not fall back to the generic outdoors/fitness/crafts/reading/pets list** — that list is the collision trap. The pool is a function of the member's seed. Then, for each candidate, pull the signal data (open-signal sources below, or Reddit if reachable). Keep ~3-5 "stretch" candidates the member would never have named (the discovery value).
- Open-signal sources: YouTube (views/comments), Google Autocomplete, Wikipedia pageviews, Google Trends. Pull these for each candidate, score them, and write each run's data + output into its OWN folder so runs never collide (rule 6). Trends is best-effort — if it rate-limits, proceed on the YouTube/Wikipedia signals and DON'T surface the failure (rule 4).
- Reddit path (when reachable): subreddit subs + top-100 posts via Reddit JSON API + curl/User-Agent.


### Step 3: Score on social signals
For each candidate, count from top 100 posts:
- `self_mock` regex hits
- `identity` regex hits  
- `gear` regex hits
- `pain` regex hits
- `humor` regex hits
- Vocab density (distinct words 5+ uses, length 4+)

Normalize each to 1-5 by percentile against the pool.

### Step 4: Apply manual cluster flags
Each cluster gets fixed scores for visual-codes, year-round, political-risk, saturation. See `00-rubric-calibration.md` for current values.

### Step 5: Pull Google Trends
Use pytrends with consistent anchor terms ("running" + "yoga") batched 3+anchor per query. Extract:
- recent 3-mo avg
- 12-month slope
- 5-year slope
- Relative-to-anchor ratio

### Step 6: Competitor density check
WebSearch each top candidate for "[niche] t-shirt brand shopify bestseller". Categorize:
- No dominant Shopify brand = HIGH opportunity
- Existing Shopify brand owns wedge = MEDIUM (need differentiation)
- Multiple established brands = LOW (skip or laser-niche)

### Step 7: Apply identity-replenishment filter (MANUAL)
For each top candidate ask: **does the buyer have a wardrobe ceiling, or does every new experience justify a new shirt?**

If wardrobe ceiling = demote despite high rubric score.

### Step 8: Recommend 5 across these tiers
- 2 highest-confidence (best rubric + best replenishment)
- 2 highest-replenishment (even if lower confidence)
- 1 dark horse (low rubric but high opportunity-creation potential)

### Step 9: Deep audit on the 5
For each:
- Pull 100 top posts from the primary + 2-3 adjacent subreddits
- Extract in-group vocab (top 40 niche-specific words, top 25 bigrams)
- Identify 3-5 existing competitors and their wedges
- Write 4-5 design wedge categories
- Generate 10-12 starter phrases
- Specify first 5 shirts to test
- Define visual codes (palette, typography, iconography)

### Step 10: Deliver HTML
Deliver as a clean, readable HTML page — one section per niche.

## Locked decisions for this project

- T-shirts only
- No political content (platform compliance)
- 5 disparate niches per round
- Identity-replenishment is the #1 filter — overrides rubric score
- You pick 5 from the top 15, but the skill proposes if you defer
- The make-or-break is the IDENTIFICATION process, not the execution — execution is already systemized

## Files this skill produces

```
<your-run-folder>/
├── 00-rubric-calibration.md         # rubric definition + SHC calibration
├── candidates-raw.json              # ~40 candidates with subs
├── candidates-scored-raw.json       # signal counts per candidate
├── candidates-ranked.json           # ranked with weighted scores
├── trends.json                      # Google Trends data
├── trends-normalized.json           # normalized against anchor
├── recommendation.json              # final 5 with reasoning
├── deep-audit-raw.json              # 100-post pulls for the 5
├── deep-audit-processed.json        # vocab + bigram extraction
├── final-5-deep-audit.json          # curated deliverable data
├── final-5-audit.html               # final HTML deliverable
└── top-15.html                      # interim top-15 HTML
```

## What this skill does NOT do

- It does not design shirts. Hand off to the design pipeline (`/dtc-ad-generate`, `/batch-nb2-generate`).
- It does not validate via ad spend. That happens after launch.
- It does not project revenue. The scorecard predicts wedge-strength, not revenue.

## Pitfalls / failure modes (learned from first run)

1. **Don't trust rubric alone on identity-replenishment.** Sourdough scored well but has a wardrobe ceiling. Apply Step 7 filter rigorously.
2. **Google Trends batches rescale.** Always use the same 2-3 anchor terms across all batches; don't trust within-batch ratios across batches.
3. **High vocab density isn't always good.** Astrology had 1639 vocab density (highest) but trends are flat — peaked-tribe signal.
4. **Outdoor activity subs systematically under-score.** Their posts don't talk in self-mocking voice (SHC creates it). Manually elevate outdoor sports if they have other strong signals.
5. **"Dominated by mega-player" check is critical.** Backyard Chickens scored well but Chicken Bawks already runs the SHC playbook there (50K+ shirts shipped, subscription model). Don't enter occupied lanes without differentiation.
