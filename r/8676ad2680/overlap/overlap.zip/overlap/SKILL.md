# The Overlap — Flat Design → Reference-Image Ad Scenes (full version)

disable-model-invocation: true

> **The model this skill embodies:** the ad worth making lives where three circles OVERLAP — **who they are** (the parade + the pocket) × **what they want** (the reasons they buy) × **what's easy for AI to generate** (a clean, legible design it can render without fighting it). This skill operates that overlap: it takes a design that's already easy-to-generate (Circle 3), an avatar you understand (Circle 1), and turns it into ads built on what they want (Circle 2).

Take ONE flat design (a print-ready t-shirt graphic, supplement label, any product artwork) and an avatar, and produce a batch of finished ad-scene images, where the design is held EXACT via a reference image. Works for any product, any avatar. The chain: write reference-image scene prompts → batch-generate via NB2 `/edit` → review.

It is THIN and INTERACTIVE on purpose: it writes the prompts, shows them, and generates on your ok. One confirmation gate. It does NOT autonomously read a product page or invent concepts, and it does NOT mechanically composite onto a PSD template — it builds real ad *scenes* from a design you already have.

## When to use
- "/overlap", "run the overlap", "turn this design into ads", "make ad scenes from this design", "generate ad images from this flat design".
- You have a finished flat design (PNG/JPG) and want people-wearing-it / lifestyle ad images that keep the design pixel-faithful.

## When NOT to use
- Flat design → mockup on a PSD template only (no scene): use a mockup tool.
- Scenes with NO reference design (text-to-image): use a plain text-to-image generator.

## The model this skill serves (why variety = "what they want")
Variety is driven by the buyer's **"what they want" reasons** — the three reasons people buy (Circle 2 of the Overlap):
1. **BE SEEN** — wearing it in a circumstance they want to be seen in.
2. **FEEL SOMETHING** — confidence, nostalgia, humor, pride, whatever they ARE.
3. **GIFT IT** — give it to someone who'd get it (buyer is often NOT the wearer).
N prompts per reason → the batch covers the buyer's psychology, not one repeated scene. (If the avatar's wants differ, use theirs — the three above are the default.)

## Intake (one AskUserQuestion call, then go)
1. **The flat design file** — path to the design PNG/JPG (the reference image). Free-text.
2. **The avatar** — one line (who they are + the 3 "what they want" reasons). Default to the three above if not given.
3. **Prompts per reason** — default 10 (so 30 total across 3 reasons).
4. **Generate now or just write prompts?** — "write + show" (stop at the prompts for review) vs "write + generate" (continue to images on confirm).

## Steps

### Step 1 — Verify the design reference
- Confirm the design file exists and READ it (look at it). Note: the exact text on the design, the colors, the key graphic elements, and the shirt/garment color if it's already on a garment. These become the "EXACT design from the attached reference image" anchor in every prompt.
- If the design is a flat-lay/mockup (design already on a shirt), that's fine — the reference still locks the artwork; just name the garment color in the prompts.

### Step 2 — Write the scene prompts (the reference-image style — THIS IS THE LOAD-BEARING PART)
For each "what they want" reason, write N prompts. Every prompt MUST follow this proven structure:

> [Scene: a real person from the avatar, in a believable moment that fits THIS reason] + [posture rule that keeps the CHEST CLEAR so the design shows] + [setting/light]. The shirt MUST use the EXACT design from the attached reference image — same text, same colors, same elements, on the same [garment color] shirt. The design must be LARGE, occupying at least 55-60% of the visible chest, fully legible, in sharp focus, facing the camera squarely, ONLY on the front. Real photographic ad. Even flattering light on the chest so the text reads clearly.

Rules that make these work (Circle 3 — clarity is the constraint):
- **Chest must stay clear.** Bake a posture into every prompt (arms relaxed/crossed-below-chest/behind-back, holding a prop to the side/at hip, leaning back). Arms across the chest = ruined ad.
- **Design LARGE + legible.** Always state ≥55-60% of chest, sharp focus, facing camera. Legibility is what makes the algorithm serve it + the buyer convert.
- **Match the reason.** BE SEEN = a circumstance/setting. FEEL = expression/emotion-forward, tighter framing. GIFT = two people + a giving moment + the shirt held facing camera (often NOT worn).
- **GIFT prompts: the design must still read** — held open, unfolded enough, or a flat-lay gift styling. The buyer needs to see what they're giving.
- Match the AVATAR's world (their job, their props, their settings) — don't write generic people.

Write the prompts to `<output-dir>/design-to-ads-prompts.md`, grouped by reason, each in a copy-ready block. **Show them to the user.** If intake said "write + show", STOP here.

### Step 3 — Generate (only if "write + generate", after the user's ok)
Use the NanoBanana 2 `/edit` mode. The verified mechanics (these gotchas each cost real cycles, do not deviate):
- Endpoint: `fal-ai/nano-banana-2/edit`
- `fal_client.submit(...)` then `result.get()` — NOT `subscribe()` (subscribe blocks silently on /edit).
- `image_urls` as an **array** (not `image_url`), the design as a **base64 data URL**.
- `image_size: {'width': 1024, 'height': 1280}` (4:5).
- `num_images: 1`, sequential loop.
- `FAL_KEY` from your `.env` (a fal.ai API key).

Canonical `/edit` code block (self-contained — use it verbatim):

```python
import os, base64, fal_client

FAL_KEY = os.environ["FAL_KEY"]  # from your .env

def data_url(path):
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f"data:image/png;base64,{b64}"

design = data_url("path/to/design.png")  # the reference image — held EXACT

def generate(prompt, out_path):
    handle = fal_client.submit(            # submit + get, NOT subscribe (subscribe blocks on /edit)
        "fal-ai/nano-banana-2/edit",
        arguments={
            "prompt": prompt,
            "image_urls": [design],        # array, not image_url
            "image_size": {"width": 1024, "height": 1280},  # 4:5
            "num_images": 1,
        },
    )
    result = handle.get()
    img_url = result["images"][0]["url"]
    # download img_url -> out_path
```

Run the prompts sequentially. Output images to `<output-dir>/images/`, named `<reason>-NN.png`.

### Step 4 — Review grid
Build a simple HTML review grid (image + its prompt + keep/regenerate). Verify a sample of generated images: the design is legible, the chest isn't blocked, the scene matches the reason. Flag any garbled-text generations (long phrases garble — that's the model; re-run or note it). Do not declare done without looking at the images.

## Output
- `design-to-ads-prompts.md` — the N×3 prompts, copy-ready, grouped by reason.
- `images/` — generated ad images (if Step 3 ran).
- `review.html` — keep/regenerate grid (if Step 3 ran).

## Notes
- Default output dir: alongside the design file, or a `design-to-ads/<slug>-<date>/` folder if generating a batch.
- Long on-shirt phrases (8+ words) garble in some models — slot-check the design FIRST (a clean reference image in = clean design held across all scenes out).
