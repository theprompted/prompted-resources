# Funnel Relay System

Point at a product page. Walk away. Come back to a complete advertorial funnel — research, locked segment, full avatar, locked strategy, headline, page-one education copy, page-two offer copy, editorial images, and a passed QA gate.

## What's in this bundle

```
funnel-relay-system/
├── README.md                  ← you are here
├── .env.example               ← copy to .env and add your FAL_KEY
├── requirements.txt           ← Python deps (just fal-client)
├── skills/
│   ├── setup/                 ← run first: "set up the funnel relay system"
│   ├── funnel-relay/          ← the orchestrator: "/funnel-relay"
│   ├── segment-score/         ← leg 2
│   ├── funnel-thesis/         ← legs 3 + 4
│   ├── advertorial-presell/   ← leg 6
│   ├── advertorial-offer/     ← leg 7
│   ├── funnel-images/         ← leg 8
│   └── funnel-qa/             ← leg 9
└── scripts/
    ├── funnel-relay.sh        ← the autonomous loop driver
    ├── funnel-relay.template.json
    ├── FUNNEL-RELAY.md        ← per-leg orchestration prompt
    └── generate_funnel_images.py
```

## Quickstart

1. Unzip this bundle to a folder you'll keep around (e.g. `~/Desktop/funnel-relay-system`).
2. Open Claude Code in that folder:
   ```
   cd ~/Desktop/funnel-relay-system && claude
   ```
3. Once you see the `❯` prompt, paste:
   ```
   set up the funnel relay system
   ```
4. Claude Code installs Python (if missing), `fal-client`, prompts you for your `FAL_KEY`, and copies all 7 skills into place.
5. Then run your first funnel:
   ```
   run the funnel relay on https://your-product-page.com/products/example
   ```
6. Wait ~2.5–3.5 hours. The relay creates `funnel-relays/<slug>-<date>/` and runs 9 legs autonomously.
7. Open the result: `funnel-relays/<slug>-<date>/artifacts/page-1.html` and `page-2.html`.

## Requirements

- **Claude Code** — you're a paid Claude subscriber, this is the only assumption
- **Python 3.9+** — setup installs it for you on Mac (via Homebrew) and Linux
- **fal.ai key** — free signup at https://fal.ai, pay-as-you-go (~$0.20–$0.50 per funnel)

## Cost

Roughly $0.20–$0.50 in fal credits per full funnel run (5 images per funnel at $0.04–$0.10 each). The Claude side of the relay uses your Claude Code subscription.

## What the 9 legs do

| Leg | Skill | Output |
|-----|-------|--------|
| L1 | market researcher (4 parallel agents) | `research/market-intelligence.md` |
| L2 | `/segment-score` | `research/segment-score.md` |
| L3 | `/funnel-thesis` (avatar phases) | `research/avatar-document.md` + `avatar-cheatsheet.md` |
| L4 | `/funnel-thesis` (strategy phases) | `artifacts/strategic-decisions.md` |
| L5 | inline headline writer | `artifacts/headline-candidates.md` |
| L6 | `/advertorial-presell` | `artifacts/page-1-draft.md` + `page-1.html` |
| L7 | `/advertorial-offer` | `artifacts/page-2-draft.md` + `page-2.html` |
| L8 | `/funnel-images` | `images/r1.png`–`r5.png` |
| L9 | `/funnel-qa` + voice audit | `artifacts/qa-report.md` |

Each leg writes its output to a file. The next fresh Claude instance picks it up and runs its leg. If L9 fails on voice or strategy lock, the relay retries up to 2 times before halting for human review.

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `fal-client not found` | `pip install --break-system-packages fal-client` |
| `FAL_KEY not set` | New terminal — run `set -a; source .env; set +a` and retry |
| `fal 401` | Bad key — regenerate at https://fal.ai/dashboard/keys |
| `fal 402` | Out of credits — top up at https://fal.ai/dashboard/billing |
| A leg hangs | Stale `tail -f` — `ps aux | grep tail` and kill it |
| L9 fails repeatedly | Open `qa-report.md`, fix L6 draft manually, or restart with a different segment |
