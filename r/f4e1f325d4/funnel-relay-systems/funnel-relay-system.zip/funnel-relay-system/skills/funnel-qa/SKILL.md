---
name: Funnel QA
description: "Pre-delivery QA checklist for any funnel HTML package. Trigger phrases: '/funnel-qa', 'qa the funnel', 'check before sending', 'is this ready to deliver', 'run qa'. Catches absolute paths, placeholders, broken images, and render issues before anyone else sees the funnel."
---

# /funnel-qa — Pre-Delivery Funnel QA

Run this before zipping, deploying, or sharing any funnel. Five gates. All must pass.

**Trigger phrases:** "qa the funnel", "check before we send", "is this ready to deliver", "run qa", or any time the word "deliver" comes up in a funnel session.

---

## Gate 1: No Absolute Filesystem Paths

Images and assets must use relative paths — not a local user-specific path.

```bash
grep -rn "/Users/\|/home/\|Dropbox\|Documents/\|/Library/" *.html
```

**PASS:** No output.
**FAIL:** Replace the offending path with a relative one (e.g. `images/r1.png`), then re-grep to confirm.

---

## Gate 2: No Placeholder Strings

Unfinished copy or links that the reader will see.

```bash
grep -rn 'href="#"\|\[.*to confirm\]\|\[.*to provide\]\|\[BRAND\]\|\[TBD\]\|\[placeholder\]' *.html
```

**PASS:** No output.
**FAIL:** List what's still outstanding and resolve before delivering.

---

## Gate 3: No Internal Attribution

Don't expose internal methodology names, framework practitioners, or working-document file names to the reader.

```bash
grep -rni "avatar system\|swipe-to-funnel\|internal methodology\|zone.*self map\|zone-self" *.html
```

**PASS:** No output.
**FAIL:** Replace with "our process" or "our framework." Never name third-party practitioners or internal methodology files.

---

## Gate 4: Images Load

Verify every referenced image file actually exists in the `images/` folder.

```bash
# List all image src values
grep -oh 'src="[^"]*"' *.html | sort -u

# List what's actually in images/
ls images/
```

**PASS:** Every src value in the HTML has a matching file in `images/`.
**FAIL:** Either copy the missing image or fix the src path.

---

## Gate 5: Visual Render Check

Screenshot at 375px (mobile) and 1200px (desktop) before delivering. Both must look right — no broken layout, no white-on-white buttons, no overflowing text.

If you have a browser automation tool available:

```bash
# Mobile
[browser-tool] set viewport 375 812
[browser-tool] open file:///absolute/path/to/page.html
[browser-tool] screenshot page-mobile.png

# Desktop
[browser-tool] set viewport 1200 900
[browser-tool] screenshot page-desktop.png
```

Otherwise, open the file in Chrome and resize the window manually.

Check both screenshots. Specifically look for:
- Buttons visible and clearly clickable (not white-on-white)
- Images rendering (not broken img placeholders)
- Text not overflowing containers on mobile
- The CTA actually points to the offer page (presell) or the product page (offer)

---

## QA Report Format

After running all gates, report:

```
Gate 1 — Absolute paths:  PASS / FAIL ([what was found])
Gate 2 — Placeholders:    PASS / FAIL ([what's still outstanding])
Gate 3 — Attribution:     PASS / FAIL ([what was removed])
Gate 4 — Images:          PASS / FAIL ([missing files])
Gate 5 — Visual render:   PASS / FAIL ([screenshot note])
```

All PASS = ready to deliver. Any FAIL = fix before sending.

---

## Voice Audit (additional check used by /funnel-relay at L9)

When called from inside the relay, also check the voice constraint line by line. Strategy lock and voice failures are what most AI funnel tools skip.

**Strategy lock fidelity:**
- Every section of page-1 and page-2 orbits the four locked decisions in `strategic-decisions.md` (awareness level, opening violation, metaphor system, framing)
- The hero of page-2 pays off the listicle of page-1

**Voice constraint:**
- No exclamation marks in body copy
- No banned words: amazing / transform / revolutionary / game-changing / breakthrough / paradise language
- Reading level: sixth grade (estimate via Flesch-Kincaid)
- Product arrives at 75–80% of page-1 word count
- Avatar's language bank used (cross-reference at least 5 verbatim phrases from `avatar-cheatsheet.md`)

**On FAIL inside the relay:** write `qa-report.md` with PASS/FAIL plus the line-by-line failures, name the leg to retry (typically L6 or L7), and append `## Leg 9 — FAIL` to the baton. The relay will re-run that leg with the failure list as additional context.
