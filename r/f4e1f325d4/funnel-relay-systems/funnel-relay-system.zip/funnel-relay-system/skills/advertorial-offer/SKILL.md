---
name: Advertorial Offer
description: "Offer/product page (page 2) of the advertorial funnel. Trigger phrases: '/advertorial-offer', 'build the offer page', 'build page two of the funnel', 'write the product reveal page'. Requires completed /advertorial-presell output first."
---

# /advertorial-offer — Product Reveal + Offer Page (Page 2)

This is Step 3 of the 3-skill advertorial chain:

`/funnel-thesis` → `/advertorial-presell` → **`/advertorial-offer`**

**Requires from `/advertorial-presell`:** coined term, 5 "things to check" spec items, product page URL for CTAs, path to page-1.html.

---

## What This Page Does

The offer page confirms. The reader arrives from the presell already believing the problem is real and knowing what spec to look for. This page does one thing: proves the product meets every item on that list — then makes it easy to buy.

**Rule:** the hero headline is the payoff of the presell. If the presell built 5 "things to check", the offer headline says "this is the one that checks every box."

---

## Page Structure

### 1. Hero section
- **H1:** plain-language payoff — the product fulfills the spec from the presell. Avoid jargon ("criterion", "specification") as labels.
- **Spec line:** the exact spec the product meets, in plain text, in the product's own words.
- **Confirmation line:** "[Brand] built to it." — one sentence, no fluff
- **Product image:** real product photo if available, embedded immediately below confirmation line. Use relative path.
- **Social proof line:** stars + review count + customer count

### 2. Testimonials strip (3 quotes)
Short, specific quotes from real customers (pull from the product's actual review corpus — Amazon, Trustpilot, on-site, wherever they live). Each quote should confirm one of the specific claims from the presell. Not generic praise. If no real reviews are available, mark the section as a placeholder rather than inventing quotes.

### 3. Credibility bar (dark background)
4 items: customer count, review count/rating, manufacturing credential (Made in [Country], certifications, etc.), return policy. Icons.

### 4. Formula / "What's Actually in It" section
Reveal each component of the product and what it does. Plain language. No ingredient-science lecture — one sentence each explaining the job of each part. This mirrors the presell's "things to check" list but now names the product's spec explicitly.

**Order:** main mechanism → supporting mechanism(s) → stress points / edge cases → usability/care notes.

### 5. Trust bar
5 items inline: returns, free shipping threshold, delivery time, manufacturing origin, certification. Teal background.

### 6. "Who this is for" section
Checkmark list. Each item describes a specific physical moment from the presell intro — not a demographic, not a personality type. The reader should tick every box.

### 7. Comparison table
3 columns: [Category Average / Competitor], [Premium Alternative], [This Product]. Rows: the 5–8 most important properties from the presell. The product wins on most rows; where it doesn't win (e.g. price vs. budget) it still shows up honestly.

### 8. "What to expect" timeline
4 time periods (first use, first week, first month, long term). Each is a specific physical observation, not a feeling.

### 9. Full testimonials section (6 cards, 2-column grid)
More specific than the strip. Each quote names a specific mechanism from the presell. Include: stars, quote, name, "Verified Purchase", time ago.

### 10. Promo banner (sticky, appears here — not at top of page)
Free shipping threshold + return guarantee. This is where the offer is revealed, so the banner appears here, not at page load.

### 11. Bundle section
3 pack sizes. Middle card: popular badge, highlighted border, primary CTA color. Cards: name + tagline + price + per-unit price + CTA button. Below cards: trust row (returns, shipping, delivery, satisfied customers).

**Bundle naming pattern:** Trial / Most Popular / Complete Reset (or equivalent). The trial removes risk; the most popular anchors; the complete reset maximizes AOV.

### 12. Guarantee section (dark background)
Specific, behavioral guarantee: "Use it. Put it through your normal routine." Not a corporate-sounding guarantee. No conditions. Contact within [X] days. No hoops.

### 13. Final CTA section
3 paragraphs max: restate what they've been doing wrong (briefly) → one line naming the root cause → confirm the product fixes it + social proof number. Then: large teal CTA button + trust row.

### 14. FAQ
7–9 questions. The first question is always "What's actually different?" (plain-language answer: the mechanism). Other questions address: usability, comparison to alternatives, durability/longevity, sizes/quantities, shipping, guarantee.

### 15. Second CTA section (dark background, at page bottom before footer)
Short. Dark background. H2: a plain question. One sentence of social proof. Teal button. Trust line below.

---

## Image Rules

**Hero image:** real product photo if available. If not, use the best editorial product image from the generated set or request one. Relative path. Max-width 420px, centered, light box-shadow.

**No lifestyle images on the offer page.** If no real product photo exists, use a placeholder with a clear label — do not generate a fake "product shot."

---

## HTML Standards

- **Font:** same as presell
- **Primary color:** same teal as presell
- **Max content width:** 1100px (offer pages are wider than presell)
- **Narrow container:** 760px for text-heavy sections (formula, guarantee, FAQ)
- **Promo banner:** sticky, positioned AFTER the credibility bar section — not at top of page
- **Bundle CTAs:** teal for the most popular; dark (#121212) for the other two
- **All buy links:** point to the product page URL provided from thesis step

---

## Optional Additions

Consider these elements depending on the product:

| Element | Worth adding? |
|---|---|
| "How to use / how it works" section | Yes if product use is non-obvious |
| Urgency badge on hero (% off, limited stock) | Yes if there's a real promotion |
| Expert/authority section | Only if product needs credibility validation |
| Bonus section | Only if there's a real bonus to offer |
| "This only works if..." disqualification | Strong trust builder — usually worth adding |
| Second bundle CTA mid-page | Always — long-scroll buyers won't scroll back up |
| 365-day vs 30-day guarantee | Evaluate per brand — longer = stronger signal |

---

## Self-Audit Before Done

- [ ] Hero headline is plain language (no "criterion", no "specification" used as jargon)
- [ ] Product image loads (relative path, not placeholder, not absolute filesystem path)
- [ ] Promo banner appears mid-page, not at top
- [ ] Formula section uses plain labels
- [ ] All bundle CTAs link to the real product page URL
- [ ] Full testimonials section exists (not just the 3-quote strip)
- [ ] Second bundle CTA exists at the bottom
- [ ] Reading level: sixth grade throughout
- [ ] Screenshot at 375px mobile and 1200px desktop — bundle cards, hero image, CTA buttons all render correctly

---

## After This Step

Run `/funnel-qa` before delivering or sharing. All 5 gates must pass.
