---
name: Funnel Relay
description: "Autonomous advertorial funnel builder. Trigger phrases: '/funnel-relay', 'run the funnel relay', 'launch the funnel relay', 'build me a funnel for', 'build an advertorial for'. Point at a product page, walk away, come back to a complete advertorial funnel."
---

# The Funnel Relay — Autonomous Advertorial Funnel Builder

Point at a product page. Walk away. Come back to a complete advertorial funnel — market research, locked segment, full avatar document, locked strategy, headline, page-one education copy, page-two offer copy, editorial imagery, and a passed QA gate.

Nine legs run autonomously: market research → segment scoring → avatar building → strategy lock → headline writing → page one (presell) → page two (offer) → image generation → QA. Each leg writes its output to a file; the next fresh Claude instance picks it up and runs its leg.

**The strategy lock:** Legs 2, 3, and 4 lock the segment, the avatar, and four strategic decisions (awareness level, opening violation, metaphor system, framing) before any copy gets written. Every downstream leg orbits these decisions. Without them, the relay produces generic five-reasons-your-X-is-bad slop.

**The voice constraint (locked at leg 4):** Every line on the page is checked against the writing guide at L9. Quiet, not warm. No exclamation marks. No transformation language. No future-pacing paradise. Reading level sixth grade. Product arrives at 75–80% of page one. Use the avatar's verbatim language, not brand language.

**The hole-and-fill structure (locked at leg 6):** Each of the 5 reasons on page one is engineered as a hole the product fills. The bridge on page one is the sum of holes filled. Reason structure is enforced at L6 generation and re-checked at L9 QA.

## Trigger Phrases

"/funnel-relay", "run the funnel relay", "run a funnel relay on", "launch the funnel relay", "build me a funnel for", "build an advertorial for"

## Intake

Use AskUserQuestion to collect exactly two inputs before doing anything else:

1. **Product page URL** — the live product/PDP page. The relay reads this in full plus the Amazon listing (if linked) plus existing reviews to infer everything about the product. You do **not** tell it who to target — leg 2 picks the segment.
2. **Existing funnel template (optional)** — path to an existing offer page to adapt L7 from. If none provided, L7 builds from scratch using the offer skill defaults.

Do **not** ask for the segment or the avatar. The relay decides.

## Steps

### Step 1 — Intake

Ask both questions in a single AskUserQuestion call. Use free-text "Other" for the URL and template path. The template is optional; default empty string means L7 builds fresh.

### Step 2 — Set up the relay directory

1. Create a slug from the product page domain (e.g. `examplebrand`)
2. Create the relay directory: `funnel-relays/[slug]-[YYYY-MM-DD]/` inside the working directory
3. Create subdirectories: `artifacts/`, `images/`, `research/`
4. Copy `funnel-relay.sh` from `scripts/`:
   ```bash
   cp scripts/funnel-relay.sh [relay-dir]/funnel-relay.sh
   chmod +x [relay-dir]/funnel-relay.sh
   ```
5. Copy `FUNNEL-RELAY.md` from `scripts/`:
   ```bash
   cp scripts/FUNNEL-RELAY.md [relay-dir]/FUNNEL-RELAY.md
   ```
6. Copy `generate_funnel_images.py` from `scripts/`:
   ```bash
   cp scripts/generate_funnel_images.py [relay-dir]/generate_funnel_images.py
   ```

### Step 3 — Write funnel-relay.json

Write `funnel-relay.json` to the relay directory using `scripts/funnel-relay.template.json` as the structural reference. Substitute:
- `productUrl`: the URL from intake
- `templatePath`: the optional offer template path (empty string if none)
- `outputDir`: the relay directory path (absolute)
- `slug`: the slug
- All artifact file paths must point to the new relay directory

Do not modify leg acceptance criteria — they are tuned to enforce the strategy lock and the voice constraint.

### Step 4 — Launch

```bash
cd [relay-dir] && bash funnel-relay.sh 12 2>&1 | tee funnel-relay-output.log
```

Tell the user:
- The relay directory path
- Expected legs: 9
- Approx runtime: 2.5–3.5 hours (longest legs are L1 market research, L3 avatar building, and L6 page-one writing)
- How to check artifacts as they appear: open `[relay-dir]/artifacts/`
- How to open the final output: `open -a "Google Chrome" [relay-dir]/artifacts/page-1.html` and `open -a "Google Chrome" [relay-dir]/artifacts/page-2.html`

## The Nine Legs

| Leg | Name | Skill | Output Artifact |
|-----|------|-------|-----------------|
| L1 | Market researcher | inline (4 parallel sub-agents) | `research/market-intelligence.md` |
| L2 | Segment scorer | `/segment-score` | `research/segment-score.md` |
| L3 | Avatar builder | `/funnel-thesis` (avatar phases only) | `research/avatar-document.md` + `research/avatar-cheatsheet.md` |
| L4 | Strategist | `/funnel-thesis` (strategy phases only) | `artifacts/strategic-decisions.md` |
| L5 | Headline writer | inline | `artifacts/headline-candidates.md` (with one locked) |
| L6 | Page-one writer | `/advertorial-presell` | `artifacts/page-1-draft.md` + `artifacts/page-1.html` |
| L7 | Page-two writer | `/advertorial-offer` | `artifacts/page-2-draft.md` + `artifacts/page-2.html` |
| L8 | Image generator | `/funnel-images` | `images/r1.png`–`r5.png` |
| L9 | QA gate | `/funnel-qa` + voice audit | `artifacts/qa-report.md` (PASS / FAIL with line-by-line) |

## Strategy Lock — Enforced Across L4 → L9

L4 produces a `strategic-decisions.md` with four locked values:
- **Awareness level** — problem-aware / solution-aware / product-aware
- **Opening violation** — the belief being contradicted (one sentence)
- **Metaphor system** — the central image everything orbits
- **Framing** — permission-based / blame-the-system / clinical-evidence / etc.

L5–L9 each open `strategic-decisions.md` as their first action. Any leg whose output drifts from these four values fails the QA gate at L9 and gets sent back.

## Voice Constraint — Enforced at L9

The voice check is the failure mode most AI funnel tools skip. L9 runs every line of page one and page two against:

- No exclamation marks
- No "amazing," "transform," "revolutionary," "game-changing," or future-pacing paradise language
- Reading level: sixth grade (Flesch-Kincaid)
- Product arrives at 75–80% of page one
- Avatar's verbatim language used (not brand language) — checked against the language bank in `avatar-cheatsheet.md`
- Quiet, matter-of-fact, slightly clinical tone

Any line that fails gets flagged with the rule it violated. L9 returns `qa-report.md`. If FAIL, the relay re-runs L6 and/or L7 with the failure list as additional context. Up to 2 retry passes before halting and waiting for human review.

## Notes

- The relay runs fully autonomously once launched — no further interaction needed
- Each leg takes 5–30 minutes depending on the leg. Full run ~2.5–3.5 hours
- If a leg fails, check `baton.txt` in the relay directory for the blocker
- The image generator (L8) requires `FAL_KEY` in the environment — set it before launching or L8 fails. Cost is roughly $0.04–$0.10 per image, so a full 5-image run is roughly $0.20–$0.50.
- Page HTML files use relative image paths — open them in Chrome directly from the relay directory
- The relay does NOT publish the funnel — it produces the artifacts. Pushing live is a manual step: copy the HTML files to your hosting / store front and deploy through your normal process

## Failure Modes

1. **L1 market research returns thin data.** If search volume / Reddit / community data comes back too sparse, L2 will refuse to score and halt. Re-run L1 with broader search terms.

2. **L2 segment scorer locks the wrong segment.** Rare but possible. If you suspect this happened, check `segment-score.md` rationale. Override is a manual step — pass the segment to L3 directly via the baton and skip L2 on the re-run.

3. **L4 strategy lock contradicts the brand's existing positioning.** This is sometimes correct (the existing positioning is wrong) and sometimes a relay mistake. Human review is warranted before continuing past L4 if the brand has paid customers on the existing positioning.

4. **L9 voice failures keep recurring after 2 retry passes.** Halt and ask for human review. Don't let the relay loop indefinitely.
