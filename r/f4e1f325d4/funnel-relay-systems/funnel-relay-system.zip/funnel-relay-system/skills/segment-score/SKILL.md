---
name: Segment Score
description: "Pick the segment worth building for. Scores every viable customer segment on TAM × convertibility. Trigger phrases: '/segment-score', 'score the segments', 'pick the segment'."
---

# /segment-score — Pick the Segment Worth Building For

This is the leg that decides whether the rest of the funnel run is worth doing.

It runs after market research and before avatar building. It identifies every viable customer segment in the category, scores each one on **current TAM** × **ease of conversion**, and locks the segment with the best combination — biggest current opportunity that's also easiest to actually convert.

This skill exists because the most expensive failure mode in advertorial funnel building is shipping a beautiful funnel for the wrong segment. A 4,000-word page-one, an offer page, custom imagery, QA — all wasted because the segment was too small, too saturated, too price-sensitive, or too hard to reach with paid traffic.

---

## Position in the Chain

`/funnel-relay` (orchestrator)
→ Leg 1: market researcher (4-agent parallel)
→ **Leg 2: `/segment-score`** ← this skill
→ Leg 3: `/funnel-thesis` avatar builder (3-agent parallel, runs on locked segment only)
→ Leg 4: strategist
→ Leg 5: headline writer
→ Leg 6: `/advertorial-presell`
→ Leg 7: `/advertorial-offer`
→ Leg 8: `/funnel-images`
→ Leg 9: `/funnel-qa`

---

## Required Inputs

From leg 1 (market research):
- Category trend data — search volume, Google Trends direction, ignition points
- Demographic and psychographic clusters identified in cold research
- Reddit / community sentiment data
- Competitive landscape — who's running funnels for whom, where the whitespace is
- Pricing data — what the category sells for, AOV ranges

From the user / orchestrator:
- Product page URL
- Optional: existing brand context (current customer base, prior winning angles, ad account constraints)

---

## What This Produces

One artifact: `segment-score.md`

Contents:
1. **Segment inventory** — every viable segment found in market research, with a one-line description
2. **Scoring table** — each segment scored on the 8 sub-axes (4 TAM, 4 convertibility) with sources
3. **Written rationale** — narrative argument for the winner, including why the runner-up was rejected
4. **The locked segment** — one segment, with enough detail for the avatar builder to go deep on
5. **What we're NOT building this run** — the 1–2 segments we're explicitly skipping, and the conditions under which we'd come back to them

---

## The Two Axes

### Axis 1: Current TAM

How big is this segment **right now**, and is it growing or shrinking. Not theoretical TAM — current addressable demand you can reach with paid traffic this month.

Sub-axes:

- **Search volume** — monthly searches for the segment's primary terms (Google Keyword Planner, SEMrush, Ahrefs). Anchor on the top 3–5 terms.
- **Community size** — subreddit subscribers, Facebook group counts, niche forum activity. Active commenters matter more than passive subs.
- **Category trend direction** — Google Trends slope over the last 24 months. Rising / flat / declining.
- **Reachability via paid** — does Meta have audiences that map to this segment, or are we reliant on broad targeting + creative-as-targeting. Some segments are huge but un-targetable, which compresses effective TAM.

Score each sub-axis 1–5. Average → TAM score.

### Axis 2: Ease of conversion

How likely is this segment to actually buy if we put a well-built funnel in front of them.

Sub-axes:

- **Awareness level** — problem-aware / solution-aware / product-aware. Solution-aware converts fastest on advertorials (they already know a category exists, we just need to reframe it). Product-aware converts even faster but needs different copy. Problem-aware needs more belief work — convertible but slower.
- **Trust gate height** — what does this segment require to believe a claim. Clinical evidence + third-party testing? Peer rec from someone like them? Influencer endorsement? Higher trust gates = harder conversion.
- **Prior-solution fatigue** — have they tried 3 things or 30. Moderate fatigue is ideal: high enough that "finally something that works" is a real conversion event, low enough that they haven't given up. Both extremes hurt.
- **Price sensitivity** — does this segment pay for quality without flinching, or do they comparison-shop. Influences AOV ceiling and bundle uptake.

Score each sub-axis 1–5. Average → convertibility score.

### Combined score

`(TAM score × Convertibility score)` — multiplicative, not additive. A segment that's huge but un-convertible is not worth building for. A segment that's hyper-convertible but tiny doesn't move the needle.

The winner is the segment with the highest combined score, **with one tiebreaker rule:** if two segments are within 10% of each other, prefer the one with higher convertibility. A funnel for an easier-to-convert segment beats a funnel for a marginally bigger but harder-to-convert segment, because the converted segment funds the next swing.

---

## Process

### Phase 1 — Inventory

Read the market research output. List every viable segment. A segment is viable if:
- It has identifiable demographic + psychographic markers
- It has a community footprint (you can find them online)
- It has spending behavior consistent with the product price point
- It is differentiated from other segments (don't list overly broad descriptions as a segment)

Aim for 2–5 segments. More than 5 means the inventory wasn't crisp; combine or drop.

### Phase 2 — Score

For each segment, fill the scoring table. Every score must cite a source — search volume from Keyword Planner, community size from the actual subreddit, trend slope from Google Trends, etc. No vibes scores. If you don't have data for a sub-axis, mark it "unknown" and lower the confidence on the segment's overall score.

### Phase 3 — Rationale

Write a one-paragraph narrative for each segment explaining the score. Then write the verdict: which segment wins, and what the runner-up was, and why we're skipping the bottom segment(s) for now.

### Phase 4 — Lock

Output `segment-score.md` with the locked segment at the top. Hand off to the avatar builder.

---

## Output Format

```markdown
# Segment Score — [Brand]

**Date:** [YYYY-MM-DD]
**Market research source:** [path to leg 1 output]

## Locked Segment

**[Segment name]** — [one-line description]

Combined score: [X.XX] (TAM [X.X] × Convertibility [X.X])

**Why this one:** [3–5 sentences]

## All Segments Considered

| Segment | TAM Score | Convertibility | Combined | Verdict |
|---------|-----------|----------------|----------|---------|
| A | X.X | X.X | X.X | LOCKED / RUNNER-UP / SKIP |
| B | X.X | X.X | X.X | LOCKED / RUNNER-UP / SKIP |
| C | X.X | X.X | X.X | LOCKED / RUNNER-UP / SKIP |

## TAM Sub-Scores

| Segment | Search Vol | Community | Trend | Reachability | Avg |
|---------|-----------|-----------|-------|--------------|-----|
| A | X (source) | X (source) | X (source) | X (source) | X.X |
...

## Convertibility Sub-Scores

| Segment | Awareness | Trust Gate | Prior-Soln Fatigue | Price Sensitivity | Avg |
|---------|-----------|------------|---------------------|-------------------|-----|
| A | X (source) | X (source) | X (source) | X (source) | X.X |
...

## Rationale

### Segment A — [Name]
[paragraph]

### Segment B — [Name]
[paragraph]

### Segment C — [Name]
[paragraph]

## What We're NOT Building This Run

[Segment X]: skipped because [reason]. Revisit when [condition].

## Hand-off to Avatar Builder

The avatar builder should go deep on **[locked segment]** only. Do not build avatars for the runner-up or skipped segments — that's wasted context window. If [locked segment] fails to convert in market, re-run /segment-score with new data, not re-score from this artifact.
```

---

## Failure Modes to Avoid

1. **Vibes scoring.** Every sub-axis score must cite a source. If you can't find data, mark "unknown" — don't guess.

2. **Picking the segment you find most interesting.** The score is the score. If the top-ranked segment isn't the one you'd have picked, the bias is yours, not the score's. Trust the rank.

3. **Listing too many segments.** More than 5 means the inventory wasn't crisp. Combine or drop. The point is to lock one, not to be exhaustive.

4. **Conflating TAM with brand fit.** This skill scores raw market opportunity. Brand-fit considerations (does this segment match your existing customer base, do you have ad account history with them, etc.) belong in a separate review by the human, not in the score.

5. **Re-scoring mid-run.** Once locked, the segment is locked for the run. If it fails downstream, the next run starts fresh with new market data — don't try to swap segments mid-funnel.

---

## When to Skip This Skill

You can skip `/segment-score` and pass a segment directly to the avatar builder if:
- The brand has an established customer base and you're explicitly building a funnel for that base (not a new-segment expansion)
- You're testing a specific hypothesis about a segment and want to bypass scoring
- You're rebuilding an existing funnel for a known segment that's already been validated

In those cases, document the segment skip in the relay baton so future runs know this decision was deliberate.

---

## Hand-off

After this skill completes, `/funnel-thesis` runs next (avatar building) using the locked segment as input.
