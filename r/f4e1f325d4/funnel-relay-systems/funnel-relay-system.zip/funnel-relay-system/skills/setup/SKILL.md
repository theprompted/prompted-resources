---
name: Setup Funnel Relay System
description: "Install all prerequisites for the funnel relay system. Trigger phrases: 'set up the funnel relay system', 'install the funnel relay', 'set up this project', 'get me ready to run the funnel relay'."
---

# Setup the Funnel Relay System

Claude Code uses this skill to install every dependency the user needs to run the funnel relay end to end. Run this once per machine. After it succeeds, the user runs `/funnel-relay` whenever they want to build a complete advertorial funnel from a product URL.

The user has already:
- Installed Claude Code (we're running inside it)
- Downloaded the bundle zip
- Unzipped it
- Opened Claude Code in the unzipped folder

The user has NOT necessarily:
- Installed Python 3.9+
- Installed `fal-client` (the only Python dependency)
- Set their `FAL_KEY` environment variable
- Copied the 7 skills into `.claude/skills/`
- Copied the relay scripts into a working location

This skill walks through every one of those, in order, with clear progress messages.

## Critical: ask before installing each major thing

Don't `pip install` without telling the user what's about to happen and why. Each install needs a one-line "I'm about to install X because Y."

## Critical: the FAL_KEY question

`fal.ai` is the image-generation provider. The relay calls it once per image at L8 (5 images per funnel). The user needs to:
1. Sign up at https://fal.ai (free)
2. Get an API key from their dashboard at https://fal.ai/dashboard/keys
3. Paste it into a `.env` file when this skill prompts them

Cost is roughly $0.04–$0.10 per image at current fal pricing — a full funnel run is roughly $0.20–$0.50 in fal credits. Tell the user this so they're not surprised.

## Detection order

Run these checks first, all in parallel via Bash, before installing anything.

```bash
# OS detection
uname -s        # Darwin = Mac, Linux = Linux, MINGW/MSYS = Windows
uname -m        # arm64 = Apple Silicon, x86_64 = Intel

# Python
python3 --version 2>&1     # need 3.9+
which python3

# Homebrew (Mac only — only needed if Python is missing)
which brew

# Already-installed Python packages
python3 -c "import fal_client; print(fal_client.__version__)" 2>&1

# FAL_KEY env var
echo "FAL_KEY is ${FAL_KEY:+set}${FAL_KEY:-NOT SET}"
```

Based on the results, decide the install plan. Tell the user the plan in plain English before executing.

Example:

> Here's what I'll install and configure:
> - `fal-client` (Python library — talks to fal.ai for image generation)
> - A `.env` file with your `FAL_KEY` (I'll prompt you for the key)
> - Copy the 7 funnel-relay skills into `.claude/skills/` so you can call `/funnel-relay`
>
> You'll need a free fal.ai account. If you don't have a key yet:
> 1. Go to https://fal.ai and sign up
> 2. Open your dashboard → API Keys
> 3. Create a key and copy it
> 4. Paste it when I ask
>
> Should I proceed?

## Install steps

### Step 1 — Python (only if missing or < 3.9)

If `python3 --version` fails or returns < 3.9:

**Mac:** install Homebrew first if missing (`/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`), then `brew install python@3.12`.

**Windows:** stop and ask the user to install from https://www.python.org/downloads/ (and check "Add to PATH"). Don't proceed automatically — Windows Python installs need a GUI installer.

**Linux:** `sudo apt install python3 python3-pip` (Debian/Ubuntu) or equivalent.

### Step 2 — Install fal-client

```bash
pip install fal-client
```

If pip errors with PEP 668 ("externally-managed-environment"), retry with:

```bash
pip install --break-system-packages fal-client
```

Verify:

```bash
python3 -c "import fal_client; print('OK', fal_client.__version__)"
```

### Step 3 — Configure FAL_KEY

Ask the user for their fal.ai key. Use AskUserQuestion or a plain prompt.

Write it to `.env` in the project root:

```bash
cat > .env <<EOF
FAL_KEY=$THE_KEY_THE_USER_PASTED
EOF
```

Then verify by sourcing it and checking:

```bash
set -a; source .env; set +a
echo "FAL_KEY ends with ...${FAL_KEY: -6}"
```

Tell the user: *"To use this every new terminal session, add `set -a; source .env; set +a` to your shell startup, or use a tool like direnv. For now, the key is loaded for this session."*

### Step 4 — Install the seven skills into `.claude/skills/`

The bundle ships seven skills at `skills/`. Copy each one into the user's `.claude/skills/` directory.

Ask the user first: global (`~/.claude/skills/`) or project-local (`./.claude/skills/`)? Global is easier; project-local keeps things isolated to this folder.

Global install:

```bash
mkdir -p ~/.claude/skills/funnel-relay
mkdir -p ~/.claude/skills/segment-score
mkdir -p ~/.claude/skills/funnel-thesis
mkdir -p ~/.claude/skills/advertorial-presell
mkdir -p ~/.claude/skills/advertorial-offer
mkdir -p ~/.claude/skills/funnel-images
mkdir -p ~/.claude/skills/funnel-qa

cp skills/funnel-relay/SKILL.md       ~/.claude/skills/funnel-relay/SKILL.md
cp skills/segment-score/SKILL.md      ~/.claude/skills/segment-score/SKILL.md
cp skills/funnel-thesis/SKILL.md      ~/.claude/skills/funnel-thesis/SKILL.md
cp skills/advertorial-presell/SKILL.md ~/.claude/skills/advertorial-presell/SKILL.md
cp skills/advertorial-offer/SKILL.md  ~/.claude/skills/advertorial-offer/SKILL.md
cp skills/funnel-images/SKILL.md      ~/.claude/skills/funnel-images/SKILL.md
cp skills/funnel-qa/SKILL.md          ~/.claude/skills/funnel-qa/SKILL.md
```

Project-local install: replace `~/.claude` with `.claude` throughout.

### Step 5 — Verify scripts are present and executable

The bundle ships the orchestration scripts at `scripts/`. Make sure `funnel-relay.sh` is executable:

```bash
chmod +x scripts/funnel-relay.sh
```

Verify all four files are present:

```bash
ls -la scripts/funnel-relay.sh scripts/funnel-relay.template.json scripts/generate_funnel_images.py scripts/FUNNEL-RELAY.md
```

### Step 6 — Smoke test

Run a tiny syntax check on `generate_funnel_images.py`:

```bash
python3 -c "import py_compile; py_compile.compile('scripts/generate_funnel_images.py'); print('OK')"
```

If this passes, the system is ready.

## Final message to the user

After all steps succeed, tell the user:

> Setup is complete. To run the relay:
>
> 1. In Claude Code, say: **"run the funnel relay on [product URL]"**
> 2. Answer the intake question (the product page URL)
> 3. The relay creates `funnel-relays/<slug>-<date>/` and runs 9 legs autonomously
> 4. ~2.5–3.5 hours later, open `funnel-relays/<slug>-<date>/artifacts/page-1.html` and `page-2.html` in Chrome
>
> Each run costs roughly $0.20–$0.50 in fal credits.
>
> You can leave it running and come back later — the bash loop spawns a fresh Claude instance for each leg and hands off via a baton file. Check `funnel-relays/<slug>-<date>/baton.txt` any time to see what's done.

## When the user reports an issue

1. **"fal-client not found"** — pip install didn't take. Try `pip3 install --user fal-client` or `pip install --break-system-packages fal-client`.
2. **"FAL_KEY not set"** — they opened a new terminal without sourcing `.env`. Run `set -a; source .env; set +a` and retry.
3. **"image generation failed with 401"** — bad key. Have them regenerate at https://fal.ai/dashboard/keys.
4. **"image generation failed with 402"** — out of credits. Have them top up at https://fal.ai/dashboard/billing.
5. **A leg hangs** — there's usually a stale `tail -f` on a finished log. Have them check `ps aux | grep tail` and kill the process; the next leg will pick up.
6. **"L9 failing repeatedly"** — the voice/strategy QA gate isn't passing after 2 retries. The relay halts and waits for human review. Open `qa-report.md` and read the failure list; usually the L6 page-one draft is using transformation language or drifting off the locked strategy. Have the user fix the draft manually or restart with a different segment.
