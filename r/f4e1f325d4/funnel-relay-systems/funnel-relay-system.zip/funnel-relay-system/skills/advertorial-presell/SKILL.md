---
name: Advertorial Presell
description: "Education page (page 1) of the advertorial funnel. Trigger phrases: '/advertorial-presell', 'build the presell page', 'write the advertorial', 'build page one of the funnel'. Requires completed /funnel-thesis output first."
---

# /advertorial-presell — Education Page (Page 1)

This is Step 2 of the 3-skill advertorial chain:

`/funnel-thesis` → **`/advertorial-presell`** → `/advertorial-offer`

**Requires from `/funnel-thesis`:** villain, thesis, headline, coined term, 5 reasons, primary avatar.

---

## What This Page Does

The presell page educates. It does not sell. The reader arrives skeptical and leaves convinced — not convinced to buy, but convinced that the problem is real, the villain is real, and that a solution with specific properties exists.

**No promo banners. No price. No product name until the bridge section.**

---

## Page Structure

### 1. Header
- Kicker: "Consumer Guide · [Category]"
- H1: The listicle headline from `/funnel-thesis`
- First line: the thesis in one italic sentence (the most heretical claim, stated plainly)

### 2. Intro block
Paint the "before" state in specific physical moments — not emotions, not generalizations. The reader should recognize their own life in 4–6 short paragraphs. No product mention. End with a bridge: "here are the 5 reasons X is designed to fail you."

### 3. Five reason sections
For each reason:
- **H3:** "Reason [N]: [Specific Named Mechanism]" — written like a newspaper subhead, not a benefit
- **Image:** immediately after the H3, before body copy (see Image Rules below)
- **Body copy:** mechanism first, consequence second, reframe third. End each with a 1-line italic forward tease to the next reason.

**Each reason must:**
- Name a specific physical mechanism (not "it wears out" — describe what is actually happening at the material/biological/behavioral level)
- Connect back to the headline
- Match the avatar's actual experience — if they don't recognize it, it's the wrong reason

### 4. Bridge section — The Coined Term
This is the pivot from problem to solution. It introduces the coined term and makes it feel like a discovered principle, not a marketing position.

Structure:
- Open with the villain's appeal ("the reason you buy X is Y — that's exactly the problem")
- The natural parallel that makes the coined term feel real
- The coined term definition box (teal left-border callout, equation format)
- 2–3 sentences connecting the term to what the label needs to show

### 5. "What to look for before you buy" section
5 items. Plain language labels ("Thing to check #1", "Thing to check #2", etc. — not "Criterion"). Each has:
- A plain-language H4 heading (what it is + the target range/value)
- Body copy explaining why the range matters
- A teal callout box with the specific number/threshold

### 6. "Does a [product] like this exist?" bridge
2–3 short paragraphs. Confirm it exists. Give one or two credibility anchors (reviews, customer count). Do not name the product. End on intrigue, not instruction.

### 7. Final CTA section
Pattern:
- One paragraph acknowledging reader state ("you now know what X is")
- Teal button: "See the [Thing] That Gets It Right →"
- One reassurance line below the button (shipping, returns, made-in)

**CTA link** should point at the offer page filename in the relay artifacts directory (e.g. `page-2.html`). If the relay is being served from a file browser, the orchestrator will rewrite to a `/view/` path at QA time — leave relative paths in the draft.

---

## Image Rules

Images go **immediately after the H3 reason headline**, before body copy. Never at the top of the section, never at the bottom.

**Image brief criteria:**
- Editorial product photography — clean, controlled lighting, sharp focus
- No lifestyle. No aspirational. No conceptual.
- The image must help the reader understand the mechanism named in the reason
- Avatar fit: match the register of the avatar (e.g. clinical/practical avatars get clinical/practical imagery; wellness avatars get warmer light — but never aspirational)
- Each image must pass: would this image be in a consumer watchdog article? If yes, it's right. If it looks like an ad, it's wrong.

**Aspect ratio:** 3:2 horizontal — shows better on mobile

**Prompt structure:** JSON-schema format. Fields: style, lighting, scene, primary_object (with material_detail, position, condition_detail as relevant), energy, constraints. The `/funnel-images` skill consumes these briefs and runs generation.

**Image path in HTML:** relative path inside the relay directory (`images/r1.png`). Do not use absolute filesystem paths.

---

## HTML Standards

- **Font:** Assistant (Google Fonts) or system sans-serif
- **Primary color:** `#108474` (teal) — or override to match the brand if there's a stronger brand color already in use
- **Max content width:** 760px (presell is narrow — reading width)
- **No promo banner** — this is an education page, not a sales page
- **Reading level:** sixth grade. No academic vocabulary as labels. See `/funnel-thesis` banned words list.

---

## Self-Audit Before Handing Off

Run these checks before calling this page done:

- [ ] Every reason aligns with the headline
- [ ] No product name or price on this page
- [ ] No promo banner
- [ ] Images placed after H3, before body copy — not at section bottom
- [ ] Coined term appears in bridge section with its natural parallel
- [ ] CTA link points to the offer page
- [ ] Reading level: no "criterion", "structural anchor", "engineering target" as labels
- [ ] Screenshot the page at 375px mobile — confirm images, CTA button, layout render correctly

---

## Next Step

Hand off to `/advertorial-offer` with:
- Path to `page-1.html` (the presell)
- The coined term
- The 5 "things to check" (spec items that the offer page will prove the product meets)
- Product page URL for offer CTAs
