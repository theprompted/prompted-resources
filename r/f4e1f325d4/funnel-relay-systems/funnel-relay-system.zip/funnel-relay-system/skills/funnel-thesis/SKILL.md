---
name: Funnel Thesis
description: "Funnel angle + thesis before writing anything. Trigger phrases: '/funnel-thesis', 'build the funnel thesis', 'start the funnel for [brand]', 'what's the angle for [product]'."
---

# /funnel-thesis — Funnel Angle + Thesis Before Writing Anything

This is Step 1 of the 3-skill advertorial chain:

**`/funnel-thesis`** → `/advertorial-presell` → `/advertorial-offer`

Do not write any copy until this skill completes. The thesis, headline, and coined term are the load-bearing decisions everything else builds on.

---

## What This Produces

1. **The villain** — the thing the avatar blames (or should blame) for their problem
2. **The thesis** — one sentence: what the product does that nothing else does, mechanistically
3. **The headline** — the advertorial title (listicle format, specific named problem, aligns with avatar)
4. **The coined term** — a name for the product's mechanism that makes it feel official (e.g. "The 90-Night Reset", "The Recovery Window")
5. **The 5 reasons** — the listicle structure, each reason evaluated against headline + avatar alignment

---

## Phase 1 — Market Research (do not skip)

### The advertorial buyer is not the same as the Amazon/retail buyer

The advertorial buyer is in active tension — carrying a specific frustration and open to re-evaluating their current solution. The Amazon buyer is in replenishment mode. Research for the advertorial buyer specifically.

**Run these in parallel:**

1. **Competitor ad library scan** — go to `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=[country code]&q=[keyword]&search_type=keyword_unordered` and screenshot. Identify who is running advertorial funnels vs. brand awareness vs. product ads. Note: angles used, villains named, formats running.

2. **Amazon review mining** — find the product's Amazon listing (or a leading competitor's). Read the AI-generated review summary and individual reviews. Capture verbatim language — the exact words customers use to describe the problem and the before/after.

3. **Avatar segmentation** — based on what you find, identify 2–3 distinct buyer types. For each: who they are, what they believe before purchase, what has to happen for them to buy. Identify which one is in the most active tension and best suited for a paid advertorial funnel.

---

## Phase 2 — Thesis Development

### The villain comes first

The villain is not a product category. It is a specific mechanism, material, or behavior that the avatar has been trusting that is actually causing their problem.

**Good villain:** a specific material, ingredient, or design choice that sounds trustworthy on the label but is the actual root cause of the problem the avatar feels every day.

**Bad villain:** "cheap [category]" — not specific enough, implies the solution is just spending more.

### Belief contradiction test

The thesis must directly contradict a belief the avatar holds with confidence right now. If the avatar has no prior belief to violate, the thesis has no friction — and no conversion.

Ask: what does the avatar currently believe that is wrong? The thesis is the correction.

### The listicle headline

Format: **"[Number] Reasons [Thing They Trust] Is [Doing Bad Thing] to [Specific Pain Body Part/Context]"**

- Each reason must be a specific, named mechanism — not a vague benefit
- All 5 reasons must align with the headline (if the headline names a body part or outcome, every reason must connect to it)
- Evaluate every reason against the headline before writing copy

### The coined term

Every great advertorial funnel has a name for the mechanism. This is not a product name — it is a name for the principle that explains why the product works.

Criteria:
- Has a parallel in something universal the avatar already knows (nature, physics, famous ratios/rules)
- Sounds official — like it was discovered, not invented
- Bridges from the villain (what's wrong) to the solution (what the product does right)
- Is short enough to say in a single breath

Search for: natural systems, scientific ratios, famous engineering principles, anything that maps to the product's actual spec or mechanism.

---

## Phase 3 — Deliverables Checklist

Before handing off to `/advertorial-presell`, confirm:

- [ ] **Villain named** — specific, not categorical
- [ ] **Thesis written** — one sentence, mechanistic, contradicts a held belief
- [ ] **Headline finalized** — listicle format, 5 reasons, sixth-grade reading level
- [ ] **Coined term confirmed** — has a natural parallel, sounds official
- [ ] **5 reasons listed** — each evaluated against headline alignment + avatar relevance
- [ ] **Primary avatar defined** — name, before-state, what has to happen to buy
- [ ] **Consumer mapping saved** — to a file the next leg can read (default: `research/consumer-mapping.md` in the relay directory)

---

## Reading Level Standard

All copy in this funnel runs at approximately sixth-grade reading level. Plain language. No academic vocabulary, no engineering jargon used as a label.

**Banned as visible labels:** criterion/criteria, structural anchor, engineering target, specification (as a heading — fine in body when explained), composition (use "blend" or "the recipe" or the product's actual word)

**Fine in body copy when immediately explained:** any material, ingredient, or technical term — as long as it gets defined the first time it appears.

---

## Next Step

Hand off to `/advertorial-presell` with:
- Villain
- Thesis
- Headline
- Coined term
- 5 reasons
- Primary avatar
- Path to consumer mapping file
