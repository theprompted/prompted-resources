---
name: Funnel Images
description: "Generate editorial illustrations for advertorial funnel pages. Trigger phrases: '/funnel-images', 'generate funnel images', 'make the presell images', 'illustrate the funnel'. Requires page-1-draft.md with IMAGE_BRIEF blocks."
---

# /funnel-images — Editorial Illustration Generator for Funnels

This skill generates the 5 illustrations the presell page needs (one per "Reason" section), plus any additional editorial scenes the funnel calls for. It is invoked by the relay at L8, after page-1-draft.md has been written with IMAGE_BRIEF JSON blocks under each Reason H3.

It assumes you have:
- A page-1 draft file with IMAGE_BRIEF blocks under each Reason heading
- `fal-client` installed and `FAL_KEY` set in the environment
- The `generate_funnel_images.py` script next to the draft

---

## Step 1: Load All Context

**CRITICAL: Do ALL of these before any other work.**

### 1.1 Read the Funnel HTML

Read the entire page-1 HTML or draft file that this skill is being asked to illustrate.

Extract:
- **All section headlines** (H2s and H3s that have images or should have images)
- **CSS color variables** from `:root` or inline styles — look for hex codes, `--color-*` variables

### 1.2 Sample Colors from the Actual Product Image

**CRITICAL: Do this BEFORE writing any prompts.** Never guess hex codes.

If the funnel has a product image (jar, bottle, packaging), sample its actual colors using PIL:

```python
from PIL import Image
import colorsys

img = Image.open("product-image.jpg")
w, h = img.size
# Sample across label area, filter by hue/saturation to find brand colors
for x in range(w//4, 3*w//4, w//20):
    for y in range(h//4, 3*h//4, h//20):
        r, g, b = img.getpixel((x, y))[:3]
        h_val, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        # Filter for saturated, non-gray pixels
```

The product IS the palette source. Guessing from memory produces illustrations that look like a different brand.

### 1.3 Check Existing Images

```bash
ls -la [funnel-folder]/images/ 2>/dev/null
```

If the folder exists, get dimensions of each image:
```bash
cd [funnel-folder]/images && for f in *.png; do echo "$f:"; sips -g pixelWidth -g pixelHeight "$f" 2>/dev/null | grep pixel; done
```

### 1.4 Map Images to Sections

Search the HTML for all `<img` tags referencing the images folder:
```
Grep for: <img.*images/
```

Note which sections have images and which don't.

---

## Step 2: Assess Current State

After loading context, determine the funnel's image state:

### State A: No Images Yet
- `images/` folder doesn't exist or is empty
- Need to identify all sections that should have images
- Need full concept → prompt → generate workflow

### State B: Has Images, Needs Audit
- Images exist but may have issues:
  - Wrong dimensions (square instead of horizontal)
  - Missing sections
  - Wrong style (photos instead of illustrations)
- List all issues found

### State C: Has Images, Needs Specific Regeneration
- Most images are fine
- Specific images need replacement (wrong content, wrong dimensions, etc.)

---

## Step 3: Present Situation

Output a clear summary:

```
## Funnel Image Assessment

**Funnel:** [name]
**Path:** [path]

### Color Palette (from CSS)
| Color | Hex | Usage |
|-------|-----|-------|
| [name] | #XXXXXX | [variable name] |
...

### Current State: [A/B/C]

### Sections Needing Images
| Section | Headline | Current Image | Status |
|---------|----------|---------------|--------|
| 1 | "..." | r1.png (1500x1000) | ✓ Good |
| 2 | "..." | r2.png (1024x1024) | ⚠️ Square - needs horizontal |
| 3 | "..." | (none) | ❌ Missing |
...

### Summary
- Total sections: X
- Images present: X
- Images missing: X
- Images needing regeneration: X (list reasons)

### Recommended Action
[What to do next based on state]
```

---

## Step 4: Write Prompts (When Ready to Generate)

For each image to generate:

### 4.1 Get the Exact Headline

The image MUST illustrate the headline. Not the body copy. The HEADLINE.

### 4.2 Apply the Prompt Template

Use funnel CSS colors, not generic defaults:

```
Soft editorial illustration style. Muted color palette using [PRIMARY COLOR] ([HEX]), [SECONDARY COLOR] ([HEX]), [ACCENT COLOR] ([HEX]), [BACKGROUND COLOR] ([HEX]).

[SPECIFIC SCENE: What does this headline look like as a picture?]

[EMOTIONAL CORE: What feeling should the viewer immediately get?]

Simplified stylized figure, minimal facial detail, emotion through body language. Warm and sophisticated, not cartoonish. [Text instruction if needed, otherwise "No text."]
```

### 4.3 Quality Checklist

Before finalizing any prompt, verify:
- [ ] Illustrates the HEADLINE, not body copy
- [ ] Single clear concept (not multiple competing elements)
- [ ] Concrete enough to be visualized (no pure abstractions)
- [ ] No visual metaphors that require interpretation (avoid colanders, piggy banks, scales)
- [ ] If showing a person: matches the avatar's actual demographics
- [ ] Uses the funnel's CSS colors, not a generic palette

---

## Step 5: Generate Images

Use the bundled script:

```bash
python3 generate_funnel_images.py --ids all
```

Or for specific images:

```bash
python3 generate_funnel_images.py --ids r1,r3
python3 generate_funnel_images.py --ids r2 --regenerate
```

The script:
- Reads `IMAGE_BRIEF` JSON blocks from `artifacts/page-1-draft.md`
- Generates one image per brief via fal.ai Nano Banana 2
- Saves to `images/r1.png` through `images/r5.png`
- At 3:2 horizontal (1500×1000 pixels)

### Verify Results

After generation:
1. Check dimensions are correct
2. Open images for visual review
3. Update HTML if filenames changed

---

## Quality Checks

Before marking any image work complete:

- [ ] All images are horizontal 3:2 (1500×1000 or similar)
- [ ] All images are illustration style (not photos, not UGC)
- [ ] All images use the funnel's CSS color palette
- [ ] Each image illustrates its section's HEADLINE
- [ ] No sections are missing images that should have them
- [ ] HTML `<img>` src paths are correct (relative paths, not absolute filesystem paths)

---

## Common Mistakes to Avoid

1. **Using generic colors** — Extract colors from THIS funnel's CSS
2. **Guessing product colors** — Always sample actual product image with PIL, never eyeball hex codes
3. **Illustrating body copy** — The image IS the HEADLINE made visual
4. **Wrong dimensions** — Must be horizontal 3:2, not square
5. **Abstract concepts** — If you have to explain it, it's too abstract
6. **Visual metaphors** — Colanders, piggy banks, scales rarely work
7. **max-width: 500px on images** — Images should span full container width (`width: 100%`), not be capped smaller than copy
8. **Absolute paths** — Use relative paths (`images/r1.png`) so the HTML works no matter where it's opened
