#!/usr/bin/env python3
"""
Funnel Relay — image generation for the presell page (5 hell-island scenes, one per reason).

Reads image briefs from artifacts/page-1-draft.md (looks for IMAGE_BRIEF blocks
after each reason H3) and generates editorial-photography images via fal.ai
Nano Banana 2. Saves to images/r1.png through images/r5.png.

Usage:
    python3 generate_funnel_images.py --ids all
    python3 generate_funnel_images.py --ids r1,r3
    python3 generate_funnel_images.py --ids r2 --regenerate

Requires: FAL_KEY env var.
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path

try:
    import fal_client
except ImportError:
    sys.stderr.write("ERROR: fal_client not installed. Run: pip install fal-client\n")
    sys.exit(2)


SCRIPT_DIR = Path(__file__).resolve().parent
DRAFT_PATH = SCRIPT_DIR / "artifacts" / "page-1-draft.md"
IMAGES_DIR = SCRIPT_DIR / "images"
IMAGES_DIR.mkdir(exist_ok=True)


def parse_briefs(draft_text: str) -> dict[str, dict]:
    """
    Extract image briefs from the page-1 draft.

    Expects blocks like:
        ### Reason 1: ...
        IMAGE_BRIEF:
        ```json
        { "scene": "...", "lighting": "...", ... }
        ```
    """
    pattern = re.compile(
        r"###\s+Reason\s+(\d+).*?IMAGE_BRIEF:\s*```json\s*(\{.*?\})\s*```",
        re.DOTALL | re.IGNORECASE,
    )
    briefs: dict[str, dict] = {}
    for match in pattern.finditer(draft_text):
        idx = match.group(1)
        try:
            brief = json.loads(match.group(2))
        except json.JSONDecodeError as exc:
            sys.stderr.write(f"WARN: brief r{idx} failed to parse: {exc}\n")
            continue
        briefs[f"r{idx}"] = brief
    return briefs


def brief_to_prompt(brief: dict) -> str:
    """Render a JSON brief into a text prompt for NB2."""
    parts = [
        "Editorial product photography for a consumer-watchdog article.",
        "Clean, controlled lighting. Sharp focus. Documentary register.",
        "No lifestyle. No aspirational mood. No models posing.",
    ]
    for key in ("scene", "primary_object", "lighting", "energy", "constraints"):
        value = brief.get(key)
        if value:
            if isinstance(value, dict):
                inner = ", ".join(f"{k}: {v}" for k, v in value.items())
                parts.append(f"{key}: {inner}")
            else:
                parts.append(f"{key}: {value}")
    return ". ".join(parts)


def generate_one(image_id: str, brief: dict, regenerate: bool) -> Path | None:
    out_path = IMAGES_DIR / f"{image_id}.png"
    if out_path.exists() and not regenerate:
        print(f"[skip] {image_id} — already exists ({out_path}). Pass --regenerate to overwrite.")
        return out_path

    prompt = brief_to_prompt(brief)
    print(f"[gen ] {image_id} — {prompt[:120]}...")

    handler = fal_client.submit(
        "fal-ai/nano-banana/v2",
        arguments={
            "prompt": prompt,
            "image_size": {"width": 1500, "height": 1000},  # 3:2 horizontal
            "num_inference_steps": 28,
            "num_images": 1,
        },
    )
    result = handler.get()
    url = result["images"][0]["url"]

    import urllib.request
    urllib.request.urlretrieve(url, out_path)
    print(f"[save] {out_path}")
    return out_path


def main() -> int:
    if not os.environ.get("FAL_KEY"):
        sys.stderr.write("ERROR: FAL_KEY env var is required.\n")
        return 2

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ids", default="all",
                        help="Comma-separated image ids (e.g. r1,r3) or 'all'.")
    parser.add_argument("--regenerate", action="store_true",
                        help="Overwrite existing images.")
    args = parser.parse_args()

    if not DRAFT_PATH.exists():
        sys.stderr.write(f"ERROR: {DRAFT_PATH} not found. L6 must complete before L8.\n")
        return 1

    draft_text = DRAFT_PATH.read_text(encoding="utf-8")
    briefs = parse_briefs(draft_text)
    if not briefs:
        sys.stderr.write("ERROR: no IMAGE_BRIEF blocks found in page-1-draft.md.\n")
        return 1

    if args.ids == "all":
        targets = sorted(briefs.keys())
    else:
        targets = [t.strip() for t in args.ids.split(",") if t.strip()]

    missing = [t for t in targets if t not in briefs]
    if missing:
        sys.stderr.write(f"WARN: no brief for {missing}. Skipping.\n")

    for image_id in targets:
        if image_id not in briefs:
            continue
        try:
            generate_one(image_id, briefs[image_id], args.regenerate)
        except Exception as exc:  # noqa: BLE001 — log and continue across the batch
            sys.stderr.write(f"ERROR: {image_id} generation failed: {exc}\n")

    return 0


if __name__ == "__main__":
    sys.exit(main())
