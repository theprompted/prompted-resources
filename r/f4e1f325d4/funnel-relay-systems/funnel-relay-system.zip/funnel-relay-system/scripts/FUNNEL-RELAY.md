# FUNNEL-RELAY — Per-Leg Orchestration Prompt

You are a fresh Claude Code instance. You will run exactly ONE leg of the funnel relay, write your output, hand off, and exit.

Read `funnel-relay.json` and `baton.txt` to determine which leg is next. Execute only that leg. Write your output to the artifact path specified in `funnel-relay.json`. Append a hand-off block to `baton.txt`. Then exit.

If `baton.txt` shows leg L9 has completed with PASS, output `RELAY_COMPLETE` and exit.

## Determine the Next Leg

Read `baton.txt`. Count the completed `## Leg N — DONE` blocks. The next leg is N+1.

If the most recent leg is L9 with status FAIL and retry count < 2, re-run the leg L9 flagged for retry (typically L6 or L7) with the failure list as additional context. Increment the retry counter in `baton.txt`.

If retry count >= 2 on L9 failure, output `RELAY_HALTED — manual review required` and exit. Do not loop indefinitely.

## Leg Definitions

### L1 — Market Researcher

**Action:** Spawn 4 parallel sub-agents using the Agent tool with subagent_type=Explore. Each one runs a focused research task:

1. **Why is this category trending?** — Google Trends, recent press, ignition events, viral moments. Output a short brief.
2. **Who is searching for it?** — Demographic + psychographic clusters, search volume by term, community footprint (subreddits, FB groups). Cite sources.
3. **What does Reddit / community sentiment say?** — Top discussion threads, dominant pain points, brand mentions, skepticism patterns. Quote verbatim.
4. **Who's competing?** — DTC brands, Amazon leaders, retail players, pricing data. Identify whitespace.

**Synthesize** the four sub-agent outputs into ONE document at `research/market-intelligence.md`. Lead with the One Insight — the category-defining frame that will inform every downstream leg.

**Hand off:** Append `## Leg 1 — DONE` block to `baton.txt` with summary and pointer to `research/market-intelligence.md`. Exit.

### L2 — Segment Scorer

**Action:** Read `research/market-intelligence.md`. Invoke the `/segment-score` skill. Follow its full process — inventory, score, rationale, lock.

**Output:** `research/segment-score.md` with the locked segment at the top, full scoring tables, and "what we're NOT building" section.

**Hand off:** Append `## Leg 2 — DONE` block to `baton.txt` with the locked segment name and combined score. Exit.

### L3 — Avatar Builder

**Action:** Read `research/market-intelligence.md` and `research/segment-score.md`. Spawn 3 parallel sub-agents on the locked segment ONLY:

1. **Identity mining** — Reddit, Amazon, TikTok, Mayo Clinic Connect, FB groups. Find IDENTITY STATEMENTS (not use cases). Quote verbatim with sources.
2. **Emotion mapping** — Drill from top-level emotions down to micro-emotions. Three primary emotions with copy examples for each.
3. **Generation + culture** — Generational consumption behaviors, cultural movements with overlap, content angles by community.

**Synthesize** into TWO documents:
- `research/avatar-document.md` — full five-pillar avatar (identity, emotion, generation, language banks, buying model)
- `research/avatar-cheatsheet.md` — operational reference for downstream legs (the avatar's three emotions, hell-island scenes, heaven-island scenes, language bank, what-not-to-do)

**Hand off:** Append `## Leg 3 — DONE` block to `baton.txt` with the avatar's name and one-line identity. Exit.

### L4 — Strategist

**Action:** Read `research/avatar-cheatsheet.md`. Lock four decisions and write to `artifacts/strategic-decisions.md`:

- **Awareness level:** problem-aware / solution-aware / product-aware (with rationale)
- **Opening violation:** the belief being contradicted, in one sentence
- **Metaphor system:** the central image everything orbits
- **Framing:** permission-based / blame-the-system / clinical-evidence / etc.

The opening violation must directly contradict a belief held with confidence by the locked avatar. If no belief-contradiction is identifiable, halt and output `STRATEGY_LOCK_FAILED` to baton — manual review required.

**Hand off:** Append `## Leg 4 — DONE` block with the four locked values. Exit.

### L5 — Headline Writer

**Action:** Read `artifacts/strategic-decisions.md` and `research/avatar-cheatsheet.md`. Generate 8–12 candidate listicle headlines following the format:

`[Number] Reasons [Thing They Trust] [Is Doing Bad Thing] to [Specific Pain Body Part / Context]`

Score each candidate on the alignment test:
- Self-selects the right reader (avatar specificity)
- Rides the trend (uses solution-aware language if locked at L4)
- Contradiction sharpness (does it violate the locked belief)

Lock the highest-scoring candidate. Write all candidates + the locked headline to `artifacts/headline-candidates.md`.

**Hand off:** Append `## Leg 5 — DONE` block with the locked headline. Exit.

### L6 — Page-One Writer

**Action:** Read `artifacts/strategic-decisions.md`, `artifacts/headline-candidates.md`, and `research/avatar-cheatsheet.md`. Invoke `/advertorial-presell`.

**Constraints (enforced in the leg, re-checked at L9):**
- 3,500–4,000 words
- Each of the 5 reasons engineered as a HOLE the product fills (absorption / tolerance / depletion / mechanism / explanation pattern, adapted to the product)
- The bridge fills every hole and names the product mechanism by name (coined term)
- Product arrives at 75–80% of the page
- Voice: quiet, matter-of-fact, slightly clinical. No exclamation marks. No transformation language. Use avatar's verbatim language from the language bank.
- Image placeholders: one per reason, after H3 / before body copy. Each must include an `IMAGE_BRIEF` JSON block that `/funnel-images` can parse at L8.

**Output:** `artifacts/page-1-draft.md` (markdown) AND `artifacts/page-1.html` (rendered HTML).

**Hand off:** Append `## Leg 6 — DONE` block with word count and the bridge headline. Exit.

### L7 — Page-Two Writer

**Action:** Read `artifacts/strategic-decisions.md`, `artifacts/page-1-draft.md`, and the optional `templatePath` from `funnel-relay.json`. Invoke `/advertorial-offer`.

If `templatePath` is set, adapt structure from that template. If empty, build from scratch using the offer skill defaults (15 sections).

**Hero headline must pay off the listicle** from page one. The bundle logic must be set up by one of the reasons on page one (typically the depletion / restoration logic).

**Output:** `artifacts/page-2-draft.md` AND `artifacts/page-2.html`.

**Hand off:** Append `## Leg 7 — DONE` block with the hero headline. Exit.

### L8 — Image Generator

**Action:** Read `artifacts/page-1-draft.md` and `research/avatar-cheatsheet.md`. Identify the 5 hell-island scenes from the cheatsheet that map to the 5 reasons. Invoke `/funnel-images` with editorial-photography briefs (no lifestyle, no aspirational — scenes the avatar recognizes).

Run `python3 generate_funnel_images.py --ids all` to generate. Save to `images/r1.png` through `images/r5.png`.

Update `artifacts/page-1.html` to reference the generated images via relative paths.

**Hand off:** Append `## Leg 8 — DONE` block with the 5 image filenames. Exit.

### L9 — QA Gate

**Action:** Invoke `/funnel-qa` plus the voice audit. Check:

**Strategy lock fidelity:**
- Every section of page-1 and page-2 orbits the four locked decisions in `strategic-decisions.md`
- The hero of page-2 pays off the listicle of page-1

**Voice constraint (line by line):**
- No exclamation marks in body copy
- No banned words: amazing / transform / revolutionary / game-changing / breakthrough / paradise language
- Reading level: sixth grade (run Flesch-Kincaid programmatically or estimate)
- Product arrives at 75–80% of page-1 word count
- Avatar's language bank used (cross-reference at least 5 verbatim phrases from `avatar-cheatsheet.md`)

**Structural:**
- Image placement: after H3, before body copy on page-1
- CTA paths: relative, working, point to the right page
- Mobile rendering: screenshot at 375px (use any available browser automation; otherwise open in Chrome and resize)

**Output:** `artifacts/qa-report.md` with PASS or FAIL plus line-by-line failures.

**If PASS:** Append `## Leg 9 — DONE — PASS` to baton. Output `RELAY_COMPLETE`. Exit.

**If FAIL:** Append `## Leg 9 — FAIL` block with the leg to retry (L6 or L7) and the failure list. Exit. The next iteration will re-run the flagged leg.

## Hand-Off Block Format

Append to `baton.txt`:

```
## Leg N — DONE
Completed: [timestamp]
Artifact: [path]
Summary: [one sentence]
Next leg: [N+1 or RELAY_COMPLETE]
---
```
