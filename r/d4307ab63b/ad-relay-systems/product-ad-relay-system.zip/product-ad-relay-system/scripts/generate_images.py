#!/usr/bin/env python3
"""
Product Ad Relay Image Generator — fal.ai nano-banana-2 /edit endpoint
using the swipe-schema-adapt pattern.

Pattern:
  - Parse L3-approved-concepts.md
  - For each brief, extract: BRIEF_ID, REFERENCE_IMAGE, the ADAPTED_SCHEMA fenced JSON block, NEGATIVE_PROMPT_EXTRA
  - Build prompt as: json.dumps(adapted_schema, indent=2) + reference instruction
  - Submit to fal-ai/nano-banana-2/edit with image_urls=[reference data URL]
  - Output: 1024x1024 PNG per brief

This is the ONLY pattern that reproduces swipe-format DNA. Prose prompts produce
generic "box on background" output. Do not flatten the schema or extract individual
fields — submit the whole adapted JSON as text.

Usage:
    python generate_images.py
"""

import os
import time
import re
import json
import base64
import urllib.request
from pathlib import Path
from datetime import datetime

import fal_client

BASE_DIR = Path(__file__).parent
REFERENCES_DIR = BASE_DIR / "references"
APPROVED_CONCEPTS_PATH = BASE_DIR / "artifacts" / "L3-approved-concepts.md"
L0_PROFILE_PATH = BASE_DIR / "artifacts" / "L0-product-profile.md"
OUTPUT_DIR = BASE_DIR / "images"
LOG_PATH = BASE_DIR / "artifacts" / "L4-generation-log.md"

OUTPUT_DIR.mkdir(exist_ok=True)

# Load FAL key from environment or .env file at bundle root
ENV_PATH = Path(__file__).parent.parent / ".env"
if ENV_PATH.exists():
    for line in ENV_PATH.read_text().splitlines():
        if line.startswith('FAL_KEY='):
            os.environ['FAL_KEY'] = line.split('=', 1)[1].strip().strip('"').strip("'")
            break
if 'FAL_KEY' not in os.environ:
    raise RuntimeError("FAL_KEY not set. Add it to .env at the bundle root, or export it in your shell.")

# Verified-working negative prompt base (from tool-sheet-nanobananav2.md)
NEGATIVE_BASE = (
    "collage, grid, multiple panels, multiple images, split image, "
    "extra fingers, six fingers, deformed hands, extra arms, "
    "hands on chest, arms crossed, object blocking product, "
    "plastic skin, bokeh, beauty filter, studio lighting, stock photo"
)


def read_product_name():
    """Pull the product name from L0-product-profile.md Section 1."""
    if not L0_PROFILE_PATH.exists():
        return "the product"
    text = L0_PROFILE_PATH.read_text()
    # Look for "product name:" patterns in Section 1
    m = re.search(r'(?:product name|Product Name|PRODUCT NAME)[:\s]+([^\n]+)', text)
    if m:
        return m.group(1).strip().strip('*').strip()
    return "the product"


def parse_briefs(md_path):
    """Parse approved briefs from L3-approved-concepts.md.

    Expected structure per brief:
      ### Brief NN — Format [FORMAT_ID]
      - **ASSIGNED_VALUE_PROP:** ...
      - **REFERENCE_IMAGE:** filename or NONE
      - **ADAPTED_SCHEMA:**
      ```json
      { ... }
      ```
      - **NEGATIVE_PROMPT_EXTRA:** ... (optional)
    """
    text = md_path.read_text()
    briefs = []
    # Split on "### Brief" headers
    blocks = re.split(r'\n###\s+Brief\s+', text)
    for block in blocks[1:]:
        first_line = block.split('\n', 1)[0]
        brief_id_match = re.match(r'(\d+)', first_line)
        if not brief_id_match:
            continue
        brief_id = brief_id_match.group(1)
        format_match = re.search(r'Format\s+\[?(\w+)\]?', first_line)
        format_id = format_match.group(1) if format_match else "unknown"

        ref_match = re.search(r'\*\*REFERENCE_IMAGE:\*\*\s*([^\n]+)', block)
        reference = ref_match.group(1).strip().strip('`').strip() if ref_match else ""
        if reference.upper() == "NONE":
            reference = ""

        # Extract the ADAPTED_SCHEMA fenced JSON block
        schema_match = re.search(
            r'\*\*ADAPTED_SCHEMA:\*\*\s*\n```json\s*\n(.*?)\n```',
            block,
            re.DOTALL,
        )
        if not schema_match:
            print(f"  WARN: brief {brief_id} has no ADAPTED_SCHEMA block — skipping")
            continue
        schema_text = schema_match.group(1)
        try:
            schema = json.loads(schema_text)
        except json.JSONDecodeError as e:
            print(f"  WARN: brief {brief_id} ADAPTED_SCHEMA is not valid JSON: {e} — skipping")
            continue

        neg_match = re.search(r'\*\*NEGATIVE_PROMPT_EXTRA:\*\*\s*([^\n]*)', block)
        negative_extra = neg_match.group(1).strip() if neg_match else ""

        briefs.append({
            "brief_id": brief_id,
            "format_id": format_id,
            "reference": reference,
            "schema": schema,
            "negative_extra": negative_extra,
        })
    return briefs


def reference_to_data_url(ref_filename):
    """Convert reference image filename to base64 data URL for fal /edit endpoint."""
    ref_path = REFERENCES_DIR / ref_filename
    if not ref_path.exists():
        return None
    ext = ref_path.suffix.lower()
    mime = {'.jpg': 'jpeg', '.jpeg': 'jpeg', '.png': 'png', '.webp': 'webp'}.get(ext, 'jpeg')
    with open(ref_path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode('utf-8')
    return f'data:image/{mime};base64,{b64}'


def build_prompt(brief, product_name):
    """The swipe-schema-adapt prompt: full JSON as text + reference instruction."""
    schema_text = json.dumps(brief['schema'], indent=2)
    instruction = (
        f"\n\nUse the {product_name} from the attached reference image exactly as shown. "
        f"Preserve every distinctive feature of the packaging — base color, wordmark, "
        f"iconography, badges, callouts, subhead text. Do not redesign, simplify, "
        f"restyle, or substitute a clean DTC version. Do not render any text on the "
        f"product itself other than what is shown in the reference. Square 1:1 composition, "
        f"single photo, one frame only, no collage, no grid, no multiple panels."
    )
    return schema_text + instruction


def build_negative_prompt(extra=""):
    if extra:
        return f"{extra}, {NEGATIVE_BASE}"
    return NEGATIVE_BASE


def generate_with_reference(brief, product_name):
    """fal-ai/nano-banana-2/edit with adapted-schema-as-text prompt + product reference."""
    ref_url = reference_to_data_url(brief['reference'])
    if not ref_url:
        raise RuntimeError(f"Reference image missing: {REFERENCES_DIR / brief['reference']}")

    result = fal_client.subscribe(
        "fal-ai/nano-banana-2/edit",
        arguments={
            "image_urls": [ref_url],
            "prompt": build_prompt(brief, product_name),
            "negative_prompt": build_negative_prompt(brief['negative_extra']),
            "image_size": {"width": 1024, "height": 1024},
            "num_images": 1,
        },
    )
    return result


def generate_without_reference(brief, product_name):
    """fal-ai/nano-banana-2 base text-to-image — only for briefs where REFERENCE_IMAGE = NONE."""
    result = fal_client.subscribe(
        "fal-ai/nano-banana-2",
        arguments={
            "prompt": build_prompt(brief, product_name),
            "negative_prompt": build_negative_prompt(brief['negative_extra']),
            "aspect_ratio": "1:1",
            "num_images": 1,
        },
    )
    return result


def extract_url(result):
    if hasattr(result, 'images') and result.images:
        return result.images[0].url
    if isinstance(result, dict):
        if 'images' in result and result['images']:
            item = result['images'][0]
            if isinstance(item, dict):
                return item.get('url')
            return getattr(item, 'url', None)
        if 'image' in result:
            item = result['image']
            if isinstance(item, dict):
                return item.get('url')
            return getattr(item, 'url', None)
    return None


def main():
    if not APPROVED_CONCEPTS_PATH.exists():
        raise RuntimeError(f"L3-approved-concepts.md not found at {APPROVED_CONCEPTS_PATH}")

    product_name = read_product_name()
    briefs = parse_briefs(APPROVED_CONCEPTS_PATH)

    print(f"Source: {APPROVED_CONCEPTS_PATH.name}")
    print(f"Product name: {product_name}")
    print(f"Parsed {len(briefs)} briefs with valid ADAPTED_SCHEMA blocks")
    print(f"References dir: {REFERENCES_DIR}")
    if REFERENCES_DIR.exists():
        refs = sorted(REFERENCES_DIR.iterdir())
        print(f"Reference images available: {len(refs)}")
        for r in refs:
            print(f"  - {r.name}")
    else:
        print("  WARN: references dir missing — briefs requiring references will fail")

    # Pre-flight: verify every brief's reference file exists
    missing_refs = []
    for b in briefs:
        if b['reference']:
            if not (REFERENCES_DIR / b['reference']).exists():
                missing_refs.append((b['brief_id'], b['reference']))
    if missing_refs:
        print(f"\n{len(missing_refs)} briefs reference missing files:")
        for bid, fn in missing_refs:
            print(f"  - Brief {bid}: references/{fn}")
        print("Aborting. Fix L0/L2 reference assignments or download the missing files.")
        return

    log_lines = [
        "# L4 — Image Generation Log",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "Model: fal-ai/nano-banana-2/edit (swipe-schema-adapt: ADAPTED_SCHEMA submitted as JSON text)",
        f"Product: {product_name}",
        f"Briefs: {len(briefs)}",
        "---\n",
    ]

    success_count = 0
    failed = []

    for i, brief in enumerate(briefs, 1):
        output_path = OUTPUT_DIR / f"brief-{brief['brief_id']}-format-{brief['format_id']}.png"
        print(f"\n[{i}/{len(briefs)}] Brief {brief['brief_id']} — Format {brief['format_id']}")
        print(f"  Reference: {brief['reference'] or '(NONE — base text-to-image)'}")
        print(f"  Schema keys: {list(brief['schema'].keys())[:8]}{'...' if len(brief['schema']) > 8 else ''}")

        attempts = 0
        max_attempts = 3
        last_error = None
        while attempts < max_attempts:
            attempts += 1
            try:
                if brief['reference']:
                    result = generate_with_reference(brief, product_name)
                    mode = "edit (with reference)"
                else:
                    result = generate_without_reference(brief, product_name)
                    mode = "base text-to-image"

                img_url = extract_url(result)
                if not img_url:
                    raise RuntimeError(
                        f"No image URL in result keys: {list(result.keys()) if isinstance(result, dict) else type(result)}"
                    )

                urllib.request.urlretrieve(img_url, output_path)
                print(f"  Saved: {output_path.name} [{mode}] (attempt {attempts})")
                log_lines.append(f"## Brief {brief['brief_id']} — Format {brief['format_id']}")
                log_lines.append("**Status:** GENERATED")
                log_lines.append(f"**Mode:** {mode}")
                log_lines.append(f"**Reference:** {brief['reference'] or 'NONE'}")
                log_lines.append(f"**Attempts:** {attempts}")
                log_lines.append(f"**File:** {output_path.name}")
                log_lines.append("")
                success_count += 1
                break

            except Exception as e:
                last_error = str(e)
                print(f"  ERROR (attempt {attempts}/{max_attempts}): {e}")
                if attempts < max_attempts:
                    time.sleep(3)
                    continue

        else:
            # Loop exhausted without break
            failed.append({"brief_id": brief['brief_id'], "error": last_error})
            log_lines.append(f"## Brief {brief['brief_id']} — Format {brief['format_id']}")
            log_lines.append("**Status:** FAILED")
            log_lines.append(f"**Attempts:** {max_attempts}")
            log_lines.append(f"**Last error:** {last_error}")
            log_lines.append("")

        time.sleep(2)  # rate-limit cushion

    log_lines.append("---")
    log_lines.append("## Summary")
    log_lines.append(f"**Generated:** {success_count}/{len(briefs)}")
    if failed:
        log_lines.append(f"**Failed:** {len(failed)}")
        for f in failed:
            log_lines.append(f"  - Brief {f['brief_id']}: {f['error']}")

    LOG_PATH.write_text('\n'.join(log_lines))

    print(f"\n{'='*50}")
    print(f"Done. {success_count}/{len(briefs)} images generated.")
    print(f"Images: {OUTPUT_DIR}")
    print(f"Log: {LOG_PATH}")


if __name__ == "__main__":
    main()
