# The Product Ad Relay — Agent Instructions

You are one leg of a relay race. Your job is to run your leg, save your output, update the baton, and hand off. A fresh instance handles the next leg — you will never see what comes after you.

## How The Relay Works (READ THIS FIRST)

**You are ONE leg of an autonomous relay.**

Architecture:
- `ad-relay.sh` spawns a FRESH Claude instance for each leg
- Each instance: reads relay.json → finds the next incomplete leg → runs it → updates state → EXITS
- The next leg starts a NEW session with clean context
- State persists via files: `relay.json`, `baton.txt`, `artifacts/`

**Your job this session:** Complete exactly ONE leg, then EXIT.
Do NOT continue to the next leg — a fresh instance handles that.

---

## Your Workflow

### Step 1 — Read the relay state

1. Read `relay.json` — understand the legs, their status, and all config (brand, funnel URL, output dir, methodology, etc.)
2. Read `baton.txt` — read what previous legs decided. This is your memory. Do not re-litigate decisions already made.
3. Note: this is the PRODUCT relay (different model from advertorial /ad-relay). Read the methodology field in relay.json — it describes the swipe-schema-adapt pattern. Internalize this before running any leg.

### Step 2 — Find your leg

Pick the **highest-priority incomplete leg** where `handed_off: false`.

Legs are sequential. Do not skip ahead. Each leg depends on artifacts saved by the previous leg.

### Step 3 — Run your leg

1. Read any artifact files from previous legs (check `[outputDir]/artifacts/`)
2. Read the funnel URL specified in relay.json (fetch the live page — skim is not acceptable)
3. Complete the leg fully — follow the acceptance criteria for this specific leg
4. Run ALL self-checks specified in the acceptance criteria. Write them out in full. Do not summarize or skip. Self-checks are the quality gate.
5. Save all output to the artifact file specified for this leg

### Step 4 — Verify acceptance criteria

Go through EVERY acceptance criterion line by line. Each must verifiably pass before you update state.

If a self-check fails — fix it before updating state. Do not mark a leg as handed_off until it passes.

### Step 5 — Update the baton and hand off

1. **Update relay.json** — set `handed_off: true` for the completed leg
2. **Append to baton.txt** using this format:

```
## [Date] — Leg [ID]: [Leg Title]

**Completed:**
- What was produced
- Key decisions made (which formats picked, which value props covered, which reference images chosen)
- Artifact files saved

**Handoff notes for the next leg:**
- What the next leg needs to know
- Decisions that should not be revisited
- Any constraints discovered during this leg

---
```

3. **Update the Decisions block** at the top of baton.txt if you made decisions the next leg needs (e.g. which concepts were selected, which concepts passed the gate, which references were downloaded)

### Step 6 — Check completion

After updating relay.json, check if ALL legs have `handed_off: true`.

**If ALL complete:** Output exactly this on its own line:
```
RELAY_COMPLETE
```

**If legs remain:** STOP. Do not continue to the next leg. Exit now. A fresh instance handles it.

---

## Critical Rules (Product Relay Specific)

1. **One leg per instance** — Complete ONE leg, then EXIT.
2. **Read baton.txt first** — All prior decisions live there. Do not redo them.
3. **Read artifact files** — Each leg builds on what the previous leg left.
4. **Self-checks are mandatory** — Write them out fully. They are not optional.
5. **Save artifacts** — Every leg saves its output to a file. If the session ends, the next instance picks up from the artifact.

6. **Swipe-schema-adapt is the only working pattern.** Earlier iterations of this relay tried prose-paragraph prompts and substring substitution; both failed. Prose prompts produced generic "box on background" output. Substring substitution leaked source brand copy through (text fields from the swipe file's original ads bled into the generated images). The only pattern that works is:
   - L1 captures the FULL swipe-file JSON record (every key) for each selected format ID
   - L2 produces an ADAPTED_SCHEMA per concept — deep copy of the source record, with text/subject/product fields HARD-REWRITTEN by key (never substring-replaced)
   - L4 submits `json.dumps(adapted_schema, indent=2)` + reference instruction as the fal prompt string
   Preserved verbatim across the adaptation: typography, photography, color_story, layout_structure, psychological_mechanics, constraints, negative_prompt. Rewritten by key: concept/description, subject/product, every text_overlay entry, headline, subhead, hero_stat, callouts, cta_text, pull_quote, person/model descriptions.

7. **No flattening, no prose, no substring substitution.** Future contributors will be tempted to "simplify" the schema by pulling fields out and writing a paragraph. Don't. The whole JSON is the prompt. The model uses the structure.

8. **Diversity across value props, not framings of a hook.** This is the product relay. Each concept expresses a DIFFERENT value prop from the L0 product profile. Don't repeat the same value prop across multiple concepts unless L0 §8 DIVERSITY_ALLOCATION calls for it.

9. **Product preservation via /edit reference.** Every brief should have a REFERENCE_IMAGE pointing to a real product photo in `references/`. The fal `/edit` endpoint uses this to preserve product accuracy. Only set REFERENCE_IMAGE = NONE for rare pure-scene compositions where the product is genuinely not in frame.

10. **Pre-flight before generation.** L4 must verify every REFERENCE_IMAGE file exists in `references/` before calling fal. Generating without a reference (when one was specified) wastes API calls and produces a redesigned product.

## When You're Stuck

1. Document the blocker in baton.txt under "Blockers"
2. Try the escalation path: re-read L0/L1/L2 — most leg failures come from upstream gaps
3. If truly blocked after 2-3 attempts, document and move on — the next instance will have fresh context

Do not spin. If a self-check keeps failing on the same issue, document the pattern and move on.

---

**Start now.** Read relay.json and baton.txt, then begin.
