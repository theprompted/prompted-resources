# The Product Ad Relay — Autonomous Product-Driven Image Ad Relay

disable-model-invocation: true

Point at a **product detail page (PDP)** or any other bottom-of-funnel product page. Walk away. Come back to a folder of product-driven ads and a Facebook feed preview — every ad modeled on a real swipe-file format, every ad tied to a real value prop the product page surfaces.

This is the **product-led sibling** to `/ad-relay`. Use this for PDPs, shop pages, product collection pages. Use `/ad-relay` for advertorial / native / idea-driven funnels.

Seven legs run autonomously: product extraction → concept selection → image briefs → quality gate → image generation → ad copy → Facebook feed preview HTML. The first leg builds a **product profile** — name, hero, value props, social proof, differentiators — and downstream legs allocate concepts across those value props so the ad batch covers the product's surface area, not one repeated headline.

## The pattern that works — swipe-schema-adapt (READ THIS BEFORE TOUCHING THIS SKILL)

Earlier runs of this relay produced generic "box on background" images because L2/L4 collapsed the swipe file's structured composition data into prose paragraphs. Prose prompts feed mood and atmosphere; they do not reproduce typography, layout zones, photography register, or psychological mechanics. The proven fix is:

1. **L1 captures the full swipe-file JSON record** for each selected format ID — every key, not just FORMAT_ID + a base-composition summary.
2. **L2 produces an ADAPTED_SCHEMA** — a deep copy of that swipe record with only the subject/product/copy fields explicitly rebuilt for this product. Typography, photography, color_story, layout_structure, psychological_mechanics, constraints, and negative_prompt are PRESERVED verbatim. Text-bearing fields are HARD-WRITTEN — never substring-substituted (the substring approach leaks source brand copy from the swipe file's original ads through into the generated images).
3. **L4 submits the ADAPTED_SCHEMA as text** — `json.dumps(schema, indent=2) + "\n\nUse the [product] from the attached reference image exactly as shown..."` is passed to fal as the `prompt` string. No flattening, no labeled fields pulled out, no prose paragraph.

This is the only pattern that actually reproduces swipe-format DNA. Future edits to this skill MUST preserve it.

**Key difference vs. `/ad-relay`:**

| | `/ad-relay` (advertorial) | `/product-ad-relay` (product) |
|---|---|---|
| L0 output | One locked headline + mechanism + visual obligation | Product profile: name, hero, 3-7 value props with weights, social proof, differentiators |
| Image text constraint | One verbatim headline on every image | Contextual text per ad — driven by the adapted swipe schema's text_overlays / headline / callout fields |
| Visual obligation | LITERAL_SUBJECT_LOCK / NUMBER_DRAMATIZATION / etc. (mechanism-driven) | Full swipe-schema composition preserved; product replaced via /edit reference image |
| Diversity quota | Across framings of ONE headline | Across distinct value props from the product profile |
| Format families preferred | Native advertorial, problem-agitate, founder-letter, drugstore-print, document-editorial | Product-hero, product-grid-lookbook, before-after-product, ugc-with-product, authority-endorsement, social-proof-stat, lifestyle-with-product, comparison-with-product |
| Ad copy register | Hook-driven, single angle echoed across batch | Bottom-of-funnel, value-prop specific, can include price/social-proof/CTA hooks |

**Swipe-file inheritance:** Same bundled `references/ad-formats.json` library. L1 filters to product-shaped format families instead of advertorial-shaped ones.

## Trigger Phrases

"/product-ad-relay", "run the product ad relay", "run product ads", "run an ad relay on this product page", "generate product ads from this PDP", "launch the product ad relay"

## Intake

Use AskUserQuestion to collect exactly three inputs before doing anything else:

1. **PDP / product page URL** — the bottom-of-funnel page the ads will drive traffic to. The relay reads this page in full to extract product profile.
2. **Unique concepts** — how many distinct ad concepts to generate (default: 20)
3. **Variations per concept** — how many image generations per concept (default: 1). Total ads = concepts × variations.

## Steps

### Step 1 — Intake

Ask all three questions in a single AskUserQuestion call. Use free-text "Other" for the URL. Use preset options for concepts and variations.

### Step 2 — Set up the relay directory

1. Create a slug from the funnel URL domain + a `-pdp` suffix to differentiate from advertorial runs (e.g. `brand-pdp-product-name`)
2. Create the relay directory: `ad-relays/[slug]-[YYYY-MM-DD]/`
3. Create subdirectories: `artifacts/`, `images/`, and `references/` (the references dir holds product photos downloaded from the PDP — used by L4 as reference images for the fal /edit endpoint)
4. Copy `generate_images.py` from `scripts/`:
   ```bash
   cp scripts/generate_images.py [relay-dir]/generate_images.py
   ```
5. Copy `AD-RELAY.md` from `scripts/`:
   ```bash
   cp scripts/AD-RELAY.md [relay-dir]/AD-RELAY.md
   ```
6. Copy `ad-relay.sh` from `scripts/`:
   ```bash
   cp scripts/ad-relay.sh [relay-dir]/ad-relay.sh
   chmod +x [relay-dir]/ad-relay.sh
   ```

### Step 3 — Write relay.json

Write `relay.json` to the relay directory using the inputs from intake. Use `scripts/relay.template.json` as the structural reference and substitute all values. Key fields to set:
- `funnel`: the URL from intake
- `adCount`: concepts × variations
- `outputDir`: the relay directory path (absolute)
- All artifact file paths must point to the new relay directory
- Update L1 to select exactly [concepts] concepts
- Update L3 target to pass all [concepts] concepts
- Update L4 to generate [variations] images per concept if variations > 1

### Step 4 — Launch

```bash
cd [relay-dir] && bash ad-relay.sh 10 2>&1 | tee ad-relay-output.log
```

Tell the user:
- The relay directory path
- Expected legs: 7
- How to check artifacts as they appear: open `[relay-dir]/artifacts/`
- How to open the final output: `open -a "Google Chrome" [relay-dir]/artifacts/L6-feed-preview.html`

## Notes

- Each leg takes 2-5 minutes. Full run ~15-30 minutes depending on concept count
- The relay runs fully autonomously once launched
- If a leg fails, check `baton.txt` in the relay directory for the blocker
- Images saved to `[relay-dir]/images/` as they generate
- Feed preview HTML uses root-relative image paths — open via local server or Chrome directly

## When to use this skill vs. /ad-relay

**Use `/product-ad-relay` when:**
- The funnel URL is a product detail page (PDP) — has price, ATC button, product specs, social proof badges
- The page is a Shopify/WooCommerce product page or any classic ecom product page
- The page leads with the product itself, not with a hook or story
- You want bottom-of-funnel ads — product-hero, before-after, social proof, lifestyle, comparison shots

**Use `/ad-relay` when:**
- The funnel URL is an advertorial / listicle / native-article-style page
- The page leads with a hook or story before naming the product
- You want top/mid-funnel native-style ads where one headline carries every image

If you're unsure, look at the URL: `/products/...` or `/collections/...` → `/product-ad-relay`. `/pages/...` or `/blog/...` or `/articles/...` → `/ad-relay`.
