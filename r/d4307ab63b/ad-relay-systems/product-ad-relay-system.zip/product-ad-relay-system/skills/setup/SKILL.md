---
name: Setup Product Ad Relay System
description: "Install all prerequisites for the product ad relay system. Trigger phrases: 'set up the product ad relay system', 'install the product ad relay', 'set up this project', 'get me ready to run the product relay'."
---

# Setup the Product Ad Relay System

Claude Code uses this skill to install every dependency the user needs to run the product ad relay end to end. Run this once per machine. After it succeeds, the user runs `product-ad-relay` whenever they want a fresh batch of product-driven ads from a PDP.

The user has already:
- Installed Claude Code (we're running inside it)
- Downloaded the bundle zip
- Unzipped it
- Opened Claude Code in the unzipped folder

The user has NOT necessarily:
- Installed Python 3.9+
- Installed `fal-client` (the only Python dep)
- Set their `FAL_KEY` environment variable
- Copied the relay skill into `.claude/skills/`
- Copied the relay scripts and swipe file into a working location

This skill walks through every one of those, in order, with clear progress messages.

## Critical: ask before installing each major thing

Don't `pip install` without telling the user what's about to happen and why. Each install needs a one-line "I'm about to install X because Y."

## Critical: the FAL_KEY question

`fal.ai` is the image-generation provider. The product relay uses the `/edit` endpoint with a reference product image so the generated ads preserve the actual product accurately. The user needs to:

1. Sign up at https://fal.ai (free)
2. Get an API key from their dashboard
3. Paste it into a `.env` file when this skill prompts them

Cost is roughly $0.05-$0.10 per image at current fal `/edit` pricing — a 20-concept run is around $2-$3. Tell the user this so they're not surprised.

## What makes this skill different from `/ad-relay`

This skill installs the **product** relay — bottom-of-funnel ads driven off a PDP. It uses fal's `/edit` endpoint with a reference product image to keep the actual product visually accurate. The advertorial `/ad-relay` skill is a separate bundle.

If the user is unsure which to install:
- PDP / Shopify product page / shop page → this one (`/product-ad-relay`)
- Advertorial / native article / listicle page → the `/ad-relay` bundle

## Detection order

Run these checks first, all in parallel via Bash, before installing anything.

```bash
# OS detection
uname -s        # Darwin = Mac, Linux = Linux, MINGW/MSYS = Windows
uname -m        # arm64 = Apple Silicon, x86_64 = Intel

# Python
python3 --version 2>&1     # need 3.9+
which python3

# Homebrew (Mac only — only needed if Python is missing)
which brew

# Already-installed Python packages
python3 -c "import fal_client; print(fal_client.__version__)" 2>&1

# FAL_KEY env var
echo "FAL_KEY is ${FAL_KEY:+set}${FAL_KEY:-NOT SET}"
```

Based on the results, decide the install plan. Tell the user the plan in plain English before executing.

Example:

> Here's what I'll install and configure:
> - `fal-client` (Python library — talks to fal.ai for image generation)
> - A `.env` file with your `FAL_KEY` (I'll prompt you for the key)
> - Copy the product-ad-relay skill into `.claude/skills/` so you can call `/product-ad-relay`
>
> You'll need a free fal.ai account. If you don't have a key yet:
> 1. Go to https://fal.ai and sign up
> 2. Open your dashboard → API Keys
> 3. Create a key and copy it
> 4. Paste it when I ask
>
> Should I proceed?

## Install steps

### Step 1 — Python (only if missing or < 3.9)

If `python3 --version` fails or returns < 3.9:

**Mac:** install Homebrew first if missing (`/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`), then `brew install python@3.12`.

**Windows:** stop and ask the user to install from https://www.python.org/downloads/ (and check "Add to PATH"). Don't proceed automatically — Windows Python installs need a GUI installer.

**Linux:** `sudo apt install python3 python3-pip` (Debian/Ubuntu) or equivalent.

### Step 2 — Install fal-client

```bash
pip install fal-client
```

If pip errors with PEP 668 ("externally-managed-environment"), retry with:

```bash
pip install --break-system-packages fal-client
```

Verify:

```bash
python3 -c "import fal_client; print('OK', fal_client.__version__)"
```

### Step 3 — Configure FAL_KEY

Ask the user for their fal.ai key. Use AskUserQuestion or a plain prompt.

Write it to `.env` in the project root:

```bash
cat > .env <<EOF
FAL_KEY=$THE_KEY_THE_USER_PASTED
EOF
```

Then verify by sourcing it and checking:

```bash
set -a; source .env; set +a
echo "FAL_KEY ends with ...${FAL_KEY: -6}"
```

Tell the user: *"To use this every new terminal session, add `set -a; source .env; set +a` to your shell startup, or use a tool like direnv. For now, the key is loaded for this session."*

### Step 4 — Install the relay skill into `.claude/skills/`

The bundle ships the skill at `skills/product-ad-relay/SKILL.md`. Copy it where Claude Code will discover it.

```bash
mkdir -p ~/.claude/skills/product-ad-relay
cp skills/product-ad-relay/SKILL.md ~/.claude/skills/product-ad-relay/SKILL.md
```

Or if the user wants project-local instead of global:

```bash
mkdir -p .claude/skills/product-ad-relay
cp skills/product-ad-relay/SKILL.md .claude/skills/product-ad-relay/SKILL.md
```

Ask which they prefer. Global is easier, project-local keeps things isolated.

### Step 5 — Verify scripts are present and executable

The bundle ships the scripts at `scripts/`. Make sure `ad-relay.sh` is executable:

```bash
chmod +x scripts/ad-relay.sh
```

Verify all four files are present:

```bash
ls -la scripts/ad-relay.sh scripts/relay.template.json scripts/generate_images.py scripts/AD-RELAY.md
ls -la references/ad-formats.json
```

### Step 6 — Smoke test

Run a tiny syntax check on `generate_images.py`:

```bash
python3 -c "import py_compile; py_compile.compile('scripts/generate_images.py'); print('OK')"
```

If this passes, the system is ready.

## Final message to the user

After all steps succeed, tell the user:

> Setup is complete. To run the product relay:
>
> 1. In Claude Code, say: **"run the product ad relay on [PDP URL]"**
> 2. Answer the intake questions (URL, number of concepts, variations per concept)
> 3. The relay creates `ad-relays/<slug>-pdp-<date>/` and runs 7 legs autonomously
> 4. ~15-30 minutes later, open `ad-relays/<slug>-pdp-<date>/artifacts/L6-feed-preview.html` in Chrome
>
> Each run costs roughly $1-$3 in fal credits depending on concept count (uses fal `/edit` which is slightly more expensive than text-to-image).

## When the user reports an issue

1. **"fal-client not found"** — pip install didn't take. Try `pip3 install --user fal-client` or `pip install --break-system-packages fal-client`.
2. **"FAL_KEY not set"** — they opened a new terminal without sourcing `.env`. Run `set -a; source .env; set +a` and retry.
3. **"image generation failed with 401"** — bad key. Have them regenerate at https://fal.ai/dashboard/keys.
4. **"image generation failed with 402"** — out of credits. Have them top up at https://fal.ai/dashboard/billing.
5. **"REFERENCE_IMAGE not found"** — L1 didn't download a product photo from the PDP, or downloaded one is missing. Check `references/` in the relay directory and re-run L1 if needed.
6. **A leg hangs** — the relay caller may have a stale `tail -f` on a completed log. Have them check `ps aux | grep tail` and kill the process; the next leg will pick up.
