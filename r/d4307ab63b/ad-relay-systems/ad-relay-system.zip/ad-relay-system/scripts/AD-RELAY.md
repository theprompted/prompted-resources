# The Relay — Agent Instructions

You are one leg of a relay race. Your job is to run your leg, save your output, update the baton, and hand off. A fresh instance handles the next leg — you will never see what comes after you.

## How The Relay Works (READ THIS FIRST)

**You are ONE leg of an autonomous relay.**

Architecture:
- `relay.sh` spawns a FRESH Claude instance for each leg
- Each instance: reads relay.json → finds the next incomplete leg → runs it → updates state → EXITS
- The next leg starts a NEW session with clean context
- State persists via files: `relay.json`, `baton.txt`, `artifacts/`

**Your job this session:** Complete exactly ONE leg, then EXIT.
Do NOT continue to the next leg — a fresh instance handles that.

---

## Your Workflow

### Step 1 — Read the relay state

1. Read `relay.json` — understand the legs, their status, and all config (brand, funnel path, output dir, methodology paths, etc.)
2. Read `baton.txt` — read what previous legs decided. This is your memory. Do not re-litigate decisions already made.
3. Load the methodology file referenced in relay.json under `methodology`

### Step 2 — Find your leg

Pick the **highest-priority incomplete leg** where `handed_off: false`.

Legs are sequential. Do not skip ahead. Each leg depends on artifacts saved by the previous leg.

### Step 3 — Run your leg

1. Read any artifact files from previous legs (check `[outputDir]/artifacts/`)
2. Read the funnel file specified in relay.json
3. Complete the leg fully — follow the methodology for this specific leg
4. Run ALL self-checks specified in the acceptance criteria. Write them out in full. Do not summarize or skip. Self-checks are the quality gate.
5. Save all output to the artifact file specified for this leg

### Step 4 — Verify acceptance criteria

Go through EVERY acceptance criterion line by line. Each must verifiably pass before you update state.

If a self-check fails — fix it before updating state. Do not mark a leg as handed_off until it passes.

### Step 5 — Update the baton and hand off

1. **Update relay.json** — set `handed_off: true` for the completed leg
2. **Append to baton.txt** using this format:

```
## [Date] — Leg [ID]: [Leg Title]

**Completed:**
- What was produced
- Key creative decisions made
- Artifact files saved

**Handoff notes for the next leg:**
- What the next leg needs to know
- Decisions that should not be revisited
- Any constraints discovered during this leg

---
```

3. **Update the Creative Decisions block** at the top of baton.txt if you made decisions the next leg needs (e.g. which concepts were selected, which concepts passed the gate)

### Step 6 — Check completion

After updating relay.json, check if ALL legs have `handed_off: true`.

**If ALL complete:** Output exactly this on its own line:
```
RELAY_COMPLETE
```

**If legs remain:** STOP. Do not continue to the next leg. Exit now. A fresh instance handles it.

---

## Critical Rules

1. **One leg per instance** — Complete ONE leg, then EXIT.
2. **Read baton.txt first** — All prior decisions live there. Do not redo them.
3. **Read artifact files** — Each leg builds on what the previous leg left.
4. **Self-checks are mandatory** — Write them out fully. They are not optional.
5. **Save artifacts** — Every leg saves its output to a file. If the session ends, the next instance picks up from the artifact.
6. **The ad sells the click, the funnel sells the product** — Never name the product or brand in ad copy. Never use selling language in the ad itself.
7. **Images must carry their own contradiction** — If an image concept requires reading the copy to be interesting, it fails. If it would make someone pause with no text at all, it passes.
8. **Hook congruence is the prime directive** — L0 extracts the funnel's locked hook (the literal headline, opening copy, central big idea). Every downstream leg's output MUST orbit that hook. If a concept, image, or ad could fit a different funnel — it fails. If clicking the ad and reading the funnel's first sentence feels like a topic change rather than a continuation — it fails. Never let avatar-derived angles or offer details substitute for the locked hook.
9. **One text element on the image: the locked headline, verbatim** — Every generated image carries EXACTLY ONE text element, and that text is the funnel's locked headline from L0, character-for-character. No subheadlines. No body copy. No labels. No captions. No badges. No price tags. No watermarks. No fake logos. No arrows-with-words. No 'before / after' tags. The visual must be strong enough to stop a scroll on its own; the headline is the cognitive payoff once attention is captured. Image generation prompts in L4 must explicitly instruct the model to render the locked headline verbatim and add NO other text. Post-generation, every image is checked: (a) is the headline rendered correctly, (b) is there ANY other text on the image — if either fails, regenerate.
10. **Visual obligation lock — every image must satisfy the obligation declared in L0 §4** — The obligation is mechanism-conditional. L0 picks ONE of four modes: (a) LITERAL_SUBJECT_LOCK for curiosity-instruction and warning headlines (the noun + action must appear — e.g. 'Put A Dry Towel In The Dryer' = towel + dryer + wet clothes); (b) NUMBER_DRAMATIZATION for stat-reveal headlines (a visual making the scale concrete — e.g. '80% water' = a translucent jug showing the water level); (c) RECONTEXTUALIZED_OBJECT for reframe headlines (the familiar object in the new framing — e.g. 'paying for water' = the jug shown as water); (d) IDENTITY_OR_BEHAVIOR_SCENE for social-proof and confession headlines (the named person/group/moment — e.g. 'I stopped using detergent' = first-person domestic scene). Every L1 selection, every L2 brief, every L4 image must satisfy the chosen mode's OBLIGATORY_ON_IMAGE elements. Body-of-funnel claims are SUPPORTING_ANGLES that decorate the obligated scene — they NEVER replace it. Diversity is in HOW the obligated scene is framed (POV, mid-action, side-angle, macro, handwritten-on-subject, etc.), NOT in which topic is shown. L3 Gate 2 enforces this.
11. **Swipe-file inheritance — L1 picks the format ID, L2 fetches the actual record** — Concept formats live in ad-formats.json with rich composition data (scene_composition, subject, pose, layout, photography). L1 cites the three-digit format ID. L2 MUST fetch that record from the JSON and inherit the composition (camera angle, framing, layout zones), substituting the original subject with the OBLIGATORY_ON_IMAGE elements from L0. Picking the format NAME and writing a free-form scene without consulting the swipe-file record produces generic output that doesn't actually express the format's visual DNA. L3 Gate 2b enforces this.

## When You're Stuck

1. Document the blocker in baton.txt under "Blockers"
2. Try the escalation path in the methodology for this leg
3. If truly blocked after 2-3 attempts, document and move on — the next instance will have fresh context

Do not spin. If a self-check keeps failing on the same issue, document the pattern and move on.

---

**Start now.** Read relay.json and baton.txt, then begin.
