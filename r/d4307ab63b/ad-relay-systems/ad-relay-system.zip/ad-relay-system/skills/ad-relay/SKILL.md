# The Ad Relay — Autonomous Image Ad Relay

disable-model-invocation: true

Point at a funnel. Walk away. Come back to a folder of ads and a Facebook feed preview — every ad congruent with the funnel's locked hook.

Seven legs run autonomously: hook extraction → concept selection → image briefs → quality gate → image generation → ad copy → Facebook feed preview HTML. The first leg locks the funnel's headline and big idea; every downstream leg must orbit it.

**The image format constraint:** Every generated image renders EXACTLY ONE text element — the funnel's locked headline, verbatim. No subheadlines, no body copy, no labels, no badges. The visual carries the scroll-stop; the headline is the payoff. This is enforced at L2 (briefs), L3 (gate), and L4 (generation prompt + post-gen check).

**The visual obligation (mechanism-conditional):** L0 picks one of four obligation modes based on the headline's mechanism, and every image must satisfy that obligation: (a) LITERAL_SUBJECT_LOCK for curiosity-instruction or warning headlines (the noun + action must appear); (b) NUMBER_DRAMATIZATION for stat-reveal (a visual that makes the number's scale concrete); (c) RECONTEXTUALIZED_OBJECT for reframe (the familiar object shown in the new framing); (d) IDENTITY_OR_BEHAVIOR_SCENE for social-proof or confession (the named person/group/moment). Body-of-funnel claims become SUPPORTING_ANGLES that decorate the obligated scene — never replace it. Diversity is in HOW the obligated scene is framed (POV, mid-action, side-angle, macro, etc.) — NOT in which topic is shown. L3 Gate 2 enforces.

**Swipe-file inheritance:** L1 picks format IDs from the bundled `references/ad-formats.json` swipe file. L2 fetches the actual swipe-file record by ID and inherits the composition (camera angle, framing, layout zones, lighting register), substituting the original subject with the headline's literal subject. The format's visual DNA flows into the brief — naming the format alone is not enough.

## Trigger Phrases

"/ad-relay", "run the ad relay", "run an ad relay on", "launch the ad relay", "start the ad relay for"

## Intake

Use AskUserQuestion to collect exactly three inputs before doing anything else:

1. **Funnel URL** — the landing page or advertorial the ads will drive traffic to. The relay reads this page in full to infer the avatar, the angle, and what makes someone click.
2. **Unique concepts** — how many distinct image concepts to generate (default: 20)
3. **Variations per concept** — how many image generations per concept (default: 1). Total ads = concepts × variations.

## Steps

### Step 1 — Intake

Ask all three questions in a single AskUserQuestion call. Use free-text "Other" for the URL. Use preset options for concepts and variations.

### Step 2 — Set up the relay directory

1. Create a slug from the funnel URL domain (e.g. `brand`, `product`, `client`)
2. Create the relay directory: `ad-relays/[slug]-[YYYY-MM-DD]/` inside the working directory
3. Create subdirectories: `artifacts/` and `images/`
4. Copy `generate_images.py` from `scripts/`:
   ```bash
   cp scripts/generate_images.py [relay-dir]/generate_images.py
   ```
5. Copy `AD-RELAY.md` from `scripts/`:
   ```bash
   cp scripts/AD-RELAY.md [relay-dir]/AD-RELAY.md
   ```
6. Copy `ad-relay.sh` from `scripts/`:
   ```bash
   cp scripts/ad-relay.sh [relay-dir]/ad-relay.sh
   chmod +x [relay-dir]/ad-relay.sh
   ```

### Step 3 — Write ad-relay.json

Write `ad-relay.json` to the relay directory using the inputs from intake. Use `scripts/ad-relay.template.json` as the structural reference and substitute all values. Key fields to set:
- `funnel`: the URL from intake
- `adCount`: concepts × variations
- `outputDir`: the relay directory path (absolute)
- All artifact file paths must point to the new relay directory (replace `[outputDir]` and `[funnel path]` everywhere)
- L0 extracts the locked hook from the funnel — do not modify its acceptance criteria
- Update L1 to select exactly [concepts] concepts (the template uses `[adCount]` as a placeholder)
- Update L3 target to pass all [concepts] concepts
- Update L4 to generate [variations] images per concept if variations > 1

### Step 4 — Launch

```bash
cd [relay-dir] && bash ad-relay.sh 10 2>&1 | tee ad-relay-output.log
```

Tell the user:
- The relay directory path
- Expected legs: 6
- How to check artifacts as they appear: open `[relay-dir]/artifacts/`
- How to open the final output: `open -a "Google Chrome" [relay-dir]/artifacts/L6-feed-preview.html`

## Notes

- The relay runs fully autonomously once launched — no further interaction needed
- Each leg takes 2-5 minutes. Full run ~15-30 minutes depending on concept count
- If a leg fails, check `baton.txt` in the relay directory for the blocker
- Images are saved to `[relay-dir]/images/` as they generate
- The feed preview HTML uses root-relative image paths — open it via a local server or Chrome directly from the relay directory
