# /find-angles — Find Winning Cold-Traffic Ad Angles (The Contradiction Engine)

The front door to the Contradiction Engine. The user enters **one thing — their own product URL** — and the skill maps their market, surfaces the beliefs ripe to contradict, and then works WITH them to find the winning angle.

This is the **full ("shebang") version** that the YouTube video demos. The light/lead-magnet version is a stripped subset (see `find-angles-public`, built after this).

> CORE TRUTH (read before running): **the angle — what you say, the belief you flip — is what makes a cold-traffic ad convert, not the format or the creative.** This skill finds the angle. It does NOT one-shot it. Research is delegated (one-shot, autonomous); the winning angle is a DIALOGUE (collaborative, back-and-forth). Honest framing for the user: *AI won't hand you a million-dollar idea from a single prompt yet — but it gets you close, fast. The idea you'd stumble on once a year, you can now find once a week. That's the 10×-faster-without-10×-harder bet.*

## ★★★ READ THIS TO THE USER FIRST — what this skill does and does NOT do (set the expectation)
This skill does the heavy lifting that used to cost you a consulting firm: it researches the market, decodes the buyer, surfaces the accepted beliefs, and lays out the Swiss Army knife with starter swings. **But it will NOT hand you a finished, million-dollar angle.** It hands you exceptionally good, organized FODDER — and one or two non-obvious sparks. **YOU connect the invisible dots. YOU come up with the idea.** That's not a flaw — it's the design, and it's the most valuable part:
- **In the past:** you paid a firm to do all of it — research, synthesis, AND the connecting. **Now:** the AI does the research and synthesis; you do the one thing that was always worth the most — connecting the invisible dots. That's what you get paid the big bucks for now. The AI doesn't replace the thinker; it clears everything off the thinker's plate EXCEPT the thinking.
- **It's hard, and that's GOOD news.** Connecting the dots is non-linear and unpredictable — you absorb the output and wait to see what surfaces. Because it's hard, your competitors won't do it. If you do it even once a week while they do it zero, you pull ahead by a mile.
- **The speed is the whole point.** You're still in it, but you move ~12–200× faster than you used to. (Real example: the "12-Hour Athlete" angle for Kane Footwear — built by molding this skill's fodder — took ~15 minutes.)
- **So, posture matters:** approach the output with *"let's make what's here work,"* not *"is this perfect?"* The win is SWINGING at the fodder. The skill is the caddie; you take the shot.

---

## When To Use
- "find angles for [url]" · "run the contradiction engine on [product]" · "what ad angle should [brand] run" · "find a winning angle for [my product]"
- The user is usually a **challenger** — a newer/smaller product positioning against an established leader. (Challenger-first is the locked mode; see `contradiction-engine`.)

## Input
**One URL** — the user's own product/website. Nothing else. They do NOT name competitors or pick a villain — the skill maps the landscape itself.

---

## THE MACRO (what the user experiences)

```
/find-angles [their url]
   │
   ├─ STAGE 1 · THE CADDIE READ  [DELEGATE — runs /belief-mapper]
   │     → SCAN: 5 buyer archetypes, scored → STOP, user picks one
   │     → FULL DECODE of the pick: all 10 psychology sections
   │       + media diet + vocab/hooks (full decode depth)
   │     → ANGLE LAYERS: accepted beliefs (ranked) + contradiction
   │       fuel (felt pain + want-vs-actually-want) + guardrails
   │     → THE SWISS ARMY KNIFE SPELLED OUT: which blades fit, a
   │       worked swing for each → the user can SEE the angles
   │
   ├─ STAGE 2 · ANGLES          [DIALOGUE — collaborative loop]
   │     → runs /contradiction-engine on the dossier
   │     → finds the belief that leaves the CHALLENGER standing
   │     → SMART-SELECTS the fitting blades (skips the rest, says why)
   │     → proposes angles → user reacts → refine → re-propose
   │
   └─ STAGE 3 · EVIDENCE        [contextual]
         → health/problem-solving spaces: gather the receipts
         → pure-taste spaces: skip
```

**The 3 D's of working with AI** (the model behind the macro — and a video beat):
- **DELEGATE** the research (hand it off, walk away).
- **DIRECT** the setup (which belief, the guardrails, the brief).
- **DIALOGUE** the winning angle (back-and-forth; neither of you has the answer alone).

The skill is built around this: it does NOT pretend to one-shot the angle. It delivers research autonomously, then explicitly enters a dialogue for the angles.

---

## HOW TO RUN IT

### STAGE 1 — RESEARCH (delegate)
1. Take the user's URL. Invoke the **`belief-mapper`** skill on it (read `.claude/skills/belief-mapper/SKILL.md`).
2. `belief-mapper` produces the research dossier HTML + a structured belief map. It does the eavesdrop+immerse sweep, lays out the market's accepted beliefs, and FLAGS the contradictable fodder.
3. **Present the dossier to the user.** Walk the highlights: their real customer, what that customer consumes, the accepted beliefs, and — most important — the flagged beliefs ripe to flip. Then say, in substance: *"Here's everything I found. You're now one step from the angle. The only question left is: how do we go the opposite direction?"*
4. **Do NOT auto-proceed to angles.** This is a deliberate stop — the hand-off into dialogue.

### STAGE 2 — ANGLES (dialogue)
1. Invoke the **`contradiction-engine`** skill (read `.claude/skills/contradiction-engine/SKILL.md`), feeding it the belief map from Stage 1.
2. It will: find the belief that leaves the user's product standing → smart-select the fitting blades of the Swiss Army knife → propose a small set of sharp angles → and then LOOP with the user (react → refine → re-propose). Stay in that loop until the user has angles they'd actually run.
3. Honesty rule: if the research was thin/empty (a source tier failed, no real customer language found), say so LOUDLY and do not paper over it with plausible-sounding angles. Thin research → weak angles, every time. (See the hard laws in `contradiction-engine`.)

### STAGE 3 — EVIDENCE (contextual)
- If the space is health / wellness / problem-solving (claims that need backing): for the chosen angle, gather the supporting receipts (research, mechanism, the "why red, not just red"). 
- If the space is pure taste/opinion (fashion, aesthetics): skip — it's a stance, not a claim.

---

## SAVED ARTIFACTS (so the angle dialogue can re-run on cached research)
- `[slug]-belief-map.html` — the research dossier (from Stage 1)
- `[slug]-angle-candidates.html` — the angle set (from Stage 2, updated as the dialogue iterates)

Re-running Stage 2 reads the saved belief map — no need to redo the slow research sweep.

---

## THE ARCHITECTURE IS THE POINT (for the demo + the user)
This is THREE composable skills working together, each doing a real job — not one magic prompt:
- **`belief-mapper`** (research) → **`contradiction-engine`** (the 6-blade playbook + dialogue) → evidence.
On camera and for the user, name this: *"this isn't one prompt — it's three skills that hand off to each other."* That's the AI/engineering sophistication to appreciate, alongside the marketing sophistication.

## Reference
- `contradiction-engine/SKILL.md` — the 6 blades, smart-select rule, the dialogue loop, the hard laws.
- `belief-mapper/SKILL.md` — the research sweep + the flagged belief map.
