# /belief-mapper — The Caddie Read (research → decode → tee up the angle)

Stage 1 of the Contradiction Engine (the research half — the DELEGATE step). From **one product URL**, produce the **complete caddie read**: a market scan of buyer archetypes → a full identity-decode of the ONE the user picks → the angle layers (accepted beliefs, contradiction fuel, guardrails) → the Swiss Army knife spelled out. The output gets the user to where **swinging at an angle is easy** — they react to organized fodder, they don't start from a blank page.

> The flow that works (the proven flow): **SCAN → user PICKS → FULL DECODE + ANGLE LAYERS + KNIFE.** Do NOT skip the scan. Do NOT summarize the decode. The #1 failure mode is going thin — producing a light avatar + a flat belief table instead of the full psychological depth. (That exact mistake was caught and rejected mid-build.) This skill = a full-fidelity decode + four angle layers on top.

---

## ★★★ WHAT THE USER MUST UNDERSTAND (the skill's honest promise — surface this)
This does the heavy lifting that used to cost a consulting firm — research, decode, the organized fodder, the starter swings. **It will NOT hand over a finished angle.** It hands over fodder + non-obvious sparks; **the USER connects the invisible dots and makes the idea.** That's the design, and it's the high-value part now: the AI does research + synthesis, the human does the connecting — the thing they're paid the big bucks for. It's hard and non-linear (that's why competitors won't do it = the edge). Approach with "let's make what's here work," not "is this perfect?" (Full framing in `find-angles/SKILL.md`.)

## When To Use
- "map the beliefs for [url]" · "research the buyer for [product]" · "run the caddie read on [brand]" · invoked by `find-angles` as Stage 1.

## Input
**One URL** — the user's own product/site. The skill self-maps competitors; the user names none.

## Output (saved artifacts — copy the canonical template VERBATIM)
- `[slug]-identity-scan.html` — the 5 scored archetypes (STEP A)
- `[slug]-decode-[archetype].html` — the full decode + angle layers + knife for the chosen one (STEPS C–D)

> ★ STYLING IS NOT OPTIONAL. Build BOTH files from the bundled `reference/output-template.html` — copy its `<style>` block VERBATIM and follow its section structure. It follows a clean, consistent design system (`#F8F8F7` bg · 2px black borders · hard `#383838` offset shadows · monospace headers · teal `#53DBC9` · **no rounded corners**) on the proven layout. Do NOT invent ad-hoc CSS or drift into a one-off look (cream bg / rounded cards / soft shadows) — that's a FAIL even if it renders clean. The full and lite versions must produce visually identical output.

---

## STEP A — THE SCAN (5 archetypes, scored) → then STOP and let the user pick
**The market-scan pass.** First do light research (read the user's site + a quick eavesdrop pass to learn who actually buys). Then generate **exactly 5 distinct buyer archetypes**, each scored:
- `name` (evocative — "The All-Day Sufferer", "The Quiet-Vanity Man")
- `identity` — 3 visceral lines (who + surface situation · what they run FROM · what they secretly run TOWARD), grounded in real found language
- `marketLevel` (large 30%+ / moderate 10-30% / niche <10%) + `marketValue` + `marketEvidence` (show the math) + `captureScenario` (1% $ figure)
- `conversionScore` 1-10 + `conversionRationale`
- `whyThisRanking`

Score = `(marketWeight×0.4) + (conversionScore×0.6)`, marketWeight large→10/moderate→6/niche→3. Sort desc, ⭐ top pick. Present a comparison table + the 5 profiles, then **STOP and ask which archetype to decode.** Do NOT auto-pick. (This is the hand-holding moment — the whole point of scan-then-pick.)

## STEP B — DEEP RESEARCH on the CHOSEN archetype (before decoding)
Once the user picks ONE, do the deep eavesdrop+immerse sweep on THAT archetype specifically (not the whole market). See "RESEARCH — the hard laws" below. Pull real, verbatim language for that person's pains, workarounds, desires, doubts.

## STEP C — THE FULL DECODE (all 10 psychology sections — every one, every time)
**This is the DECODE at full fidelity. Producing only the "obvious" 4-5 sections is the #1 failure mode.** All 10, each = its hardcoded "wise preface" (the timeless principle line — the canonical texts are in `reference/principle-texts.md`) + an archetype-specific preface + the findings:

| # | Section | findings |
|---|---|---|
| 1 | Trigger Moments | 5-8 |
| 2 | Limiting Beliefs | 3-6 |
| 3 | Private Shame / Frustration | 3-6 |
| 4 | Current Workarounds | 5-8 |
| 5 | Aspirational Identity | 3-6 |
| 6 | Hidden Risks | 3-6 |
| 7 | Tiny Wins | 5-8 |
| 8 | Moment of Triumph | 3-6 |
| 9 | Identity Contradiction | preface + **tension** ("I want X, but Y") + **sharp** (visceral version) |
| 10 | Avoidance Identity | 3-6 |

Then the **media diet**: Image Content (4-6 categories × examples × whyEngage) · Video Content (4-6, same) · **Words & Hooks** (vocabulary 6-12 verbatim phrases + hooks 3-6 in their voice). Each finding 1-2 sentences, raw ammunition not essays; stay in-character (pronouns, not the archetype name).

## STEP D — THE ANGLE LAYERS (what makes this a caddie, not just a decode)
On top of the decode, add the four layers that tee up the swing. (These are the net-new value over a plain buyer decode.)

**Layer A — Accepted Beliefs.** The market's "everybody knows" gospel FOR THIS ARCHETYPE (not the buyer's private psychology — the market's accepted narrative), each: `statement` (market's words) · `foundQuote`+source · `loadBearing` 1-10 · `freshness` (SOLID = voltage / CRACKING = decaying). Sort by load × freshness.

**Layer B — Contradiction Fuel.** For the top 2-3 beliefs: the **felt pain when it fails** (grounded quote — the "that's literally me" moment) + **want → actually-want** ("they think they want X, they actually want Y" — the deep desire, the richest fuel).

**Layer C — Guardrails.** Who-owns-what (which competitor owns which belief = the moats to avoid) + **what the user MUST NOT attack** (the belief their own product depends on — leave-the-challenger-standing).

**Layer D — ★ THE SWISS ARMY KNIFE, SPELLED OUT (do NOT skip — this is what makes the swing visible).**
Read `.claude/skills/contradiction-engine/reference/blades.md`. Then build a table: all 6 blades, each with its move, and a clear verdict for THIS archetype:
- **✅ FITS** → hand over the worked swing: the belief it flips + the fuel behind it + a 💡 example line in the buyer's voice.
- **⚠️ SKIP** → state WHY it doesn't fit (no two camps / no real mechanism / nothing declared-dead / would torch the user).
End with: "your shortlist is [the fitting blades], [X] is the sharpest because [identity-defense reason]. Pick the one that feels truest — that's where Stage 2 starts."
> WHY this is mandatory: without it, the user has to assemble the angle from scattered layers themselves — without it the swing is hard to see even for experienced strategists. The knife section turns "here are ingredients" into "here are swings on the tee."

---

## RESEARCH — THE HARD LAWS (non-negotiable — earned painfully)
1. **Research IS the skill.** Thin/skipped/fabricated research → confident, plausible, COMPLETELY WRONG output. No decode/angle quality compensates.
2. **Every finding grounded in a REAL FOUND quote/behavior** — reviews (esp 1-3★), forums, competitor copy, expert/creator content. NEVER armchair invention. (A grid/decode full of confident cells built from thin research is the worst failure — it LAUNDERS fabrication into something that looks rigorous.)
3. **FAIL LOUDLY on empty research.** Name failed source tiers in the output; never paper over with a "typical findings" summary. If a section can't be grounded, mark it EMPTY/"needs research" — do not fill it from imagination.
4. **For known clients, check internal research FIRST** (QMD `mcp__qmd__query`) before re-researching.
5. **Mine competitor ADS + the category's experts**, not just reviews — the sharpest installed beliefs live there.

### ★ RESEARCH CHANNELS — what actually works
WebFetch dies on 403/503 on review aggregators. The reliable channels:
- **An authenticated browser** (real Chrome via automation) reaches OPEN sources (Reddit threads, Google review snippets, expert content, blogs, forums) where Trustpilot/Amazon are gated. **This is the primary eavesdrop channel** — far more reliable than plain page-fetching on review aggregators.
- **`yt-dlp`** transcripts — high-signal critic/review videos (the immerse layer).
- **Apify MCP** (`apify/rag-web-browser` free; dedicated paid scrapers for Trustpilot/Amazon — ASK before spending).
- KNOWN GATES (route around, don't fight): Trustpilot reCAPTCHAs even authenticated; Amazon review TEXT is JS-lazy-loaded / login-gated; Reddit legacy full-text SEARCH is unreliable (go to specific subreddits/threads, or Google `site:reddit.com`). Name these as gaps when they block you; pull the eavesdrop from the open sources instead (Reddit threads, Google snippets, expert content).

---

## VERIFY BEFORE DONE — gates (a clean render is NOT enough)
1. **Scan gate:** exactly 5 archetypes, scored, ⭐ top pick, and you STOPPED for the user to pick (didn't auto-proceed).
2. **Depth gate (the one runs skip):** all **10** psychology sections present (not 5, not 8 — incl. aspirationalIdentity, hiddenRisks, tinyWins, momentOfTriumph, identityContradiction with tension+sharp, avoidanceIdentity) at minimum finding counts + full media diet + vocab/hooks. State the counts explicitly ("10/10 sections, image 5 cats, video 4, 9 vocab, 6 hooks"). A light decode = FAIL even if clean.
3. **Angle-layers gate:** Accepted Beliefs (ranked, with quotes) + Contradiction Fuel (felt pain + want-vs-actually-want) + Guardrails + **the Swiss Army knife SPELLED OUT** (every blade fits/skips with a reason, worked swing per fit). If the knife section is missing, the caddie is incomplete.
4. **Grounding gate:** every finding traces to a real found quote/behavior; failed source tiers named; nothing fabricated to fill space.
5. **Styling gate:** the `<style>` block matches `winning-angles-public/reference/output-template.html` (`#F8F8F7` bg, 2px black borders, `#383838` hard offset shadows, monospace headers, `#53DBC9` teal, no rounded corners). Ad-hoc CSS = FAIL; rebuild from the template.
6. **Render gate:** screenshot the HTML (agent-browser `screenshot --full`) and confirm it renders clean AND matches the template look before declaring done.

## Reference
- Principle/wise-preface texts: `reference/principle-texts.md` (bundled).
- The blades (for Layer D): `.claude/skills/contradiction-engine/reference/blades.md`
- Feeds Stage 2: `.claude/skills/contradiction-engine/SKILL.md`. Orchestrated by `.claude/skills/find-angles/SKILL.md`.
- A gold-standard example output ships alongside this bundle (see the member page sample).
