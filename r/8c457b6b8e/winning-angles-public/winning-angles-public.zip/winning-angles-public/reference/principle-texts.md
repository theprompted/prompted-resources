# Principle Texts — the italic intro line under each decode section

> Use these as the "principle"/"wise preface" line for each matching section in the decode. They're the timeless idea each section is built on. (Referenced by belief-mapper Step C.)

- **Trigger Moments** — People don't go from zero to purchase because of an ad. Something was already brewing—a doubt they couldn't shake. Your ad doesn't create the desire; it meets them when it's already forming.
- **Limiting Beliefs** — What stops them isn't price. It's a story they've told themselves so often it feels like fact. Name the belief out loud and something shifts.
- **Private Shame / Frustration** — What they complain about publicly is rarely what keeps them up at night. The real friction lives in what they'd never post.
- **Current Workarounds** — Before they find you, they're already solving the problem badly. What they're cobbling together is what they're ready to replace.
- **Aspirational Identity** — People buy the version of themselves they're trying to become. Reflect that future self back clearly and you're helping them become who they already want to be.
- **Hidden Risks** — Every purchase carries an unspoken fear. These aren't typed objections—they're the quiet hesitations that close the tab. Remove the fear and the decision unblocks.
- **Tiny Wins** — Transformation is a series of small signals that something is working. Name the small wins and the big promise becomes believable.
- **Moment of Triumph** — There's a scene they've imagined where the struggle is behind them. Put them in it, viscerally and specifically, and you're showing them what's possible.
- **Identity Contradiction** — They hold two beliefs at once: who they think they should be, and who they secretly are. The most resonant marketing lives in that tension.
- **Avoidance Identity** — The other half of the story is who they're terrified of becoming—and that fear often drives behavior more than aspiration does.
- **Image Content** — Your ad drops into a feed already full of content that shaped their taste. Ads that mirror that visual diet feel native; ads that ignore it feel like interruptions.
- **Video Content** — The reels they watch reveal their emotional priorities. Match that rhythm and your ad inherits the permission they've already granted.
- **Words & Hooks** — Words are the last thing they process but the first thing they remember. The right phrase names what they've felt but never articulated.

---
