# /contradiction-engine — Turn a Belief Map Into Winning Angles (The Swiss Army Knife)

Stage 2 of the Contradiction Engine — the core. Takes a **belief map** (from `belief-mapper`), finds the belief worth attacking, and runs it through the **Swiss Army knife**: 6 contradiction plays (blades), each a DISTINCT move. Then it **dialogues** with the user to massage the candidates into angles they'd actually run.

> This is the DIALOGUE half — NOT a one-shot generator. It proposes; the user reacts; it refines. (The DELEGATE half — research — is `belief-mapper`.)

---

## When To Use
- "run the plays on [belief]" · "generate angles from the belief map" · "what's the contradiction angle here" · invoked by `find-angles` as Stage 2.

## Input
The belief map from `belief-mapper` (`[slug]-belief-map.html` + its structured beliefs, each with a found quote, load-bearing score, freshness, felt pain).

## Output
`[slug]-angle-candidates.html` — the angle set, tagged by blade, updated as the dialogue iterates.

---

## ★★★ THE THREE LAWS (read before generating — all earned painfully)

1. **THE SPINE — contradict for a REASON, never for its own sake.** Every blade is the same move: the market's HERO is actually the VILLAIN (or vice versa). "If they say blue, the answer is red — and red FOR A REASON." The reason is a real philosophy / science / experience / mechanism. Contrarianism without a reason is noise.

2. **THE SWISS-ARMY-KNIFE RULE — select the fitting blade, SKIP the rest, say why.** A Swiss Army knife has many blades, each for a different job. A craftsman picks the ONE that fits — never forces all of them, never puts a corkscrew on a rope. So: judge which blades genuinely fit the chosen belief, generate only from those, and SKIP the rest WITH A STATED REASON. **Skipping is the skill, not a gap.** (The #1 failure mode: one idea wearing all 6 blade-costumes. If your candidates all reduce to the same idea, you forced the blades — start over.)

3. **THE BELIEF MUST LEAVE THE CHALLENGER STANDING.** The belief you attack must NOT undercut the user's own product. (Canonical lesson: IM8 IS a one-scoop all-in-one, so it cannot attack "one scoop can't replace nutrition" — that torches IM8. The fitting belief was "the FAMOUS scoop is just an incomplete base," which leaves IM8 standing as the TRUE all-in-one.) **The dialogue's FIRST job is finding the belief that contradicts the category while leaving the user as the hero.**

Plus, inherited from `belief-mapper` (still binding): every angle roots in a **REAL FOUND quote / felt pain** (never armchair); **FAIL LOUDLY** if the research was thin — do not generate confident angles on fabricated pain.

---

## HOW TO RUN IT (the dialogue loop)

### Step 1 — Pick the belief (leave the challenger standing)
From the flagged fodder in the belief map, choose the belief to attack. Apply Law 3: it must contradict the category WHILE leaving the user's product as the hero. If the obvious biggest belief would torch the user, find the version that doesn't (often: attack the LEADER'S specific version of the gospel, not the shared premise the user also relies on). **State the chosen belief and why it leaves the user standing — and invite the user to confirm or redirect.** (This is the first dialogue beat.)

### Step 1.5 — Choose the POSTURE (ask BEFORE selecting blades)
> Posture is NOT a late styling choice — it changes which blades even FIT, so ask it up front. The same belief generates different angles (and a different blade-select) depending on the emotional register.
Ask the user which posture the angles should take:
- **EXPOSÉ** ("you got played") — lead with the betrayal; the leader hid it on purpose. Sharper, scroll-stopping, rides live category anger. Risk: negative/attacky; names or implicates the competitor.
- **CONFIDENCE** ("nothing to hide") — lead with the user's poise; we do X because we can, they won't because they can't. The contrast is IMPLIED, never thrown — a philosophy that manifests in the product, not a stone cast at others. Calmer, premium, on-brand for an aspirational label.
- (or a blend — exposé hook → confidence close.)
Why it matters: a CONFIDENCE/implied posture changes blade fit (e.g. it favors stating a mechanism as physics/law rather than accusation — "a fixed scoop is zero-sum" is a confident math truth, not an attack). State the chosen posture and carry it into blade-select + every expression. (e.g. choosing a confidence/implied-contrast posture can re-promote a mechanism/math blade under a frame that isn't an attack on anyone.)

### Step 2 — Smart-select the blades (through the posture lens)
Read `reference/blades.md` (the full canonical definitions + approved examples). For the chosen belief AND posture, judge which blades FIT. For each:
- **FITS** → generate a candidate (next step).
- **DOESN'T FIT** → skip it, and write one line on WHY (e.g. "The 180 doesn't fit — running to the opposite pole here = 'ditch the category', which torches the user").
Aim for the 2-4 blades that genuinely fit. Fewer sharp > six forced.

### Step 3 — Generate one DISTINCT candidate per fitting blade
Each blade must make ITS OWN move (per `reference/blades.md`) — a different idea, not a re-skin. Each candidate:
- `angle` — the contradicting claim in one sharp line.
- `blade` — which of the 6, and the distinct move it made.
- `belief` — the belief it attacks.
- `reason` — the philosophy/science/experience that backs it (Law 1). 
- `feltPain` — the real buyer pain it lands on (grounded in the found quote — the "that's literally me" test).
- `bakedInOrWrapper` — does running this need a product change (baked-in) or just a reframe (wrapper)? Tells the user: product job or marketing job.
- `voltage` (1-10) — most TRUE × most SURPRISING right now (uses freshness; a cracking/old belief = low voltage).

### Step 4 — Make it GREAT, not just right (the quality layer)
Raw contradiction is "right." These make it GREAT (from comparing to real winning funnels). Apply where they fit:
- **A MATH / specificity play** — hunt for the killer STAT (e.g. "$10 of ingredients sold for $99" / "€50 ÷ €3 = it'd have to be 17× better"). A concrete-number contradiction is sharper than a qualitative one.
- **COIN a sticky name** for each attack (Taki's name-the-move, applied to angles — "The Washing Machine Test", "Count the Bottles"). Ownable > generic.
- **DEFEND the buyer's identity** — contradict the belief WHILE protecting the buyer's ego (blame the industry/the leader, not the buyer — "you weren't stupid, you were sold a base and told it was complete").
- **WITHHOLD the resolution** — the angle sets up the belief-break; it doesn't hand over the full answer. (The ad creates the tension; the funnel resolves it.)

### Step 5 — DIALOGUE (the loop — this is the point)
Present the small set of candidates (ranked by voltage). Then GO BACK AND FORTH:
- Ask which land and which don't, and why.
- Refine the winners; kill the duds; re-express the best (ONE belief, MANY expressions — the volume comes from re-expressing the winner, not scattering across invented beliefs).
- Re-propose. Loop until the user has angles they'd actually run.
- Be honest: if nothing's landing, the belief may be wrong (back to Step 1) or the research thin (back to `belief-mapper`) — say so, don't force.

> ★ ONE BELIEF, MANY EXPRESSIONS: the winning method is NOT "6 angles via 6 blades." It's: find THE load-bearing belief → attack it → then express that ONE attack N ways (× evidence × image). The blades are ways to FIND/frame the attack; the volume comes from re-expressing the winner.

---

## OUTPUT — HTML
Write `[slug]-angle-candidates.html` using the bundled `reference/output-template.html` styling (teal / offset-shadow / mono). Structure:
- **The chosen belief** + why it leaves the user standing.
- **Blade select** — which blades fit (✓) and which were skipped (with the one-line reason). Show the skips — the smart-select is part of the value.
- **The candidates** — cards: angle · blade+move · reason · felt pain · baked-in/wrapper · voltage · (coined name). Ranked by voltage.
- **The winner + its expressions** — once the dialogue lands one, the master attack + its N expressions.

## VERIFY BEFORE DONE
1. **Distinctness gate (the one runs skip):** confirm each candidate makes a GENUINELY DIFFERENT move — they do NOT all reduce to one idea. If they do, you forced the blades; redo Step 2-3. State which blades fit and which you skipped + why.
2. **Grounding gate:** every angle traces to a real found quote / felt pain (not armchair). The belief leaves the user standing.
3. **Render gate:** screenshot the HTML (agent-browser) clean before done.

## Reference
- `reference/blades.md` — the 6 canonical blades: each blade's MOVE + verified examples + disqualifiers. READ THIS before generating.
- Feeds from: `.claude/skills/belief-mapper/SKILL.md`. Orchestrated by: `.claude/skills/find-angles/SKILL.md`.
