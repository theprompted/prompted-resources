# The Swiss Army Knife — The 6 Blades (canonical)

> READ THIS before generating any angle. Each blade is a tool for a DIFFERENT job. A craftsman selects the blade that fits the belief in front of them and leaves the rest folded — never forces all 6, never puts a corkscrew on a rope. Skipping the non-fitting blades (with a stated reason) IS the skill.
>
> THE SPINE (every blade shares it): contradict the commonly-accepted narrative — the market's HERO is actually the VILLAIN, or vice versa — ALWAYS for a real reason (philosophy / science / experience / mechanism). Never contradiction for its own sake.
>
> THE AXIS (every blade executes 2 ways): BAKED-IN (a real product change backs it) vs WRAPPER (same product, reframe only). Tell the user which — it's a product job or a marketing job.

---

## 🔪 1. THE 180 — run to the OPPOSITE POLE of the category's core virtue
**The move:** take the category's sacred VIRTUE and run to the extreme opposite — a whole opposite philosophy, not "we do it better." For a real reason.
**Approved examples:**
- **Death Wish Coffee** — coffee chased smooth/mellow/balanced → they ran to the pole: "the world's strongest coffee."
- **Tabasco / extreme-heat sauces** — sauces sold flavor → they sell pain/heat.
- **Brooklinen** — the category worshipped high thread-count = quality → they posted "high thread count does NOT equal better sheets" (their own sheets are 270/480, below competitors); reason = long-staple cotton matters, not the number.
**The test / guardrail:** flip the category's VIRTUE with a stance behind it. NOT opposite-for-shock. If running to the opposite pole = "abandon the category" and that torches the user's own product, this blade DOESN'T fit — skip it.
**Naming register:** positional/spatial ("The 180").

## 🔪 2. THE THIRD DOOR — refuse two NAMED camps, claim the better middle/fusion
**The move:** two camps are at war; you refuse both and claim a third position that FUSES them — the ground nobody's standing on.
**Approved examples:**
- **HexClad** — nonstick OR cast iron → a hybrid that's both.
- **Tesla (early)** — eco-but-slow (Prius) OR fast-but-gas (sportscar) → electric AND faster than a Ferrari.
- **AG1 (originally)** — take 12 separate supplements OR take nothing → one scoop instead.
- **Dollar Shave Club** — expensive premium blades OR cheap disposable Bic → good price AND good quality, the middle nobody held.
**The test / guardrail:** name BOTH camps out loud, then claim the fused third position that beats both. If there aren't two genuine named camps to split, this blade DOESN'T fit — skip it.
**Naming register:** positional/spatial ("The Third Door").

## 🔪 3. THE CURE IS THE CAUSE — the TRUSTED FIX is mechanically CAUSING the problem
**The move:** the exact thing they rely on to SOLVE the problem is what's CREATING it. A specific mechanism betrayal — not "you're doing it wrong," but "the remedy IS the disease."
**Approved examples:**
- **Hairstory / New Wash** — the shampoo you trust strips + dries your hair, creating the need for conditioner; they sell a detergent-free wash.
- **Lume** — the deodorant you use feeds the bacteria that cause the smell.
- **daily moisturizer** — applying it daily trains your skin to stop producing its own oils → drier.
- **melatonin** — the sleep aid is why you can't sleep without it (dependency).
**The test / guardrail:** you must be able to name a REAL MECHANISM by which the trusted fix causes the problem. If the leader merely FAILS to cover something (a gap), that is NOT this blade — claiming a false mechanism = fabrication, forbidden. Skip it if there's no true causal mechanism.
**Naming register:** the reveal ("The Cure Is the Cause" / alt "The Medicine Is the Poison").

## 🔪 4. THE INNOCENT SUSPECT — we DEMONIZED THE WRONG THING; defend the falsely-accused, with a reason
**The move:** NOT about exonerating the buyer. The market has VILLAINIZED something that's actually your friend — you DEFEND it, backed by a real reason (science / experience / philosophy). (Listerine was WRONG here — it CREATES a villain; that's the opposite move. Do not use Listerine.)
**Approved examples:**
- **Carbs** — "carbs aren't the enemy; no-carb is why you're sick, tired, low-energy. Carbs are your friend."
- **Fat** (the keto argument) — demonized for decades, but fat keeps you satiated and your hormones normal.
- **Red meat** (the carnivore argument) — demonized, but here are the real reasons it's good for you.
**The test / guardrail:** find the thing the category made the villain → defend it as actually beneficial → back the defense with a real reason, never bare contrarianism. The power is the DEFENSE + the reason, not just naming a new culprit.
**Naming register:** the reveal ("The Innocent Suspect").

## 🔪 5. THE WRONG BATTLEFIELD — declare the METRIC everyone competes on WRONG, install a new axis you win on
**The move:** everyone's competing on one axis (size, speed, price, ingredient-count, calories). You declare that axis IRRELEVANT and change what the competition is even about — out loud.
**Approved examples:**
- **Volvo** — everyone fought on speed/style/luxury → Volvo declared the axis SAFETY and owned it for 70 years.
- **Weight Watchers** — the whole diet world counted CALORIES → WW said that's the wrong metric, count POINTS ("one number tells you more than a calorie ever could").
**The test / guardrail:** the brand must PUBLICLY declare the old metric wrong and name a new one. (Apple was REJECTED here — it never publicly said "performance doesn't matter," so it fails the must-declare-it test. Patagonia rejected — didn't resonate.) Name the axis everyone fights on → declare it wrong → introduce the new axis YOU win on.
**Naming register:** positional/spatial ("The Wrong Battlefield").

## 🔪 6. THE COMEBACK THAT NEVER LEFT — declared-dead thing never stopped working, AND you can PROVE WHY
**The move:** the market keeps declaring something dead/antiquated; you reveal it never stopped working — it was quietly winning the whole time. Swap: assumed has-been → evergreen.
**Approved examples:**
- **Email** — "email is dead" → it's the highest-ROI channel there is ($36 per $1).
- **Beef tallow** — "saturated fat is bad" → the wellness hero that matches your skin's own oils; real DTC brands built on it.
**THE DISQUALIFIER (the guardrail):** if the only reason it's "back" is NOSTALGIA / a TREND (vinyl, flip phones, the Stanley cup), it does NOT qualify. The blade REQUIRES a DEFENSIBLE REASON it was always superior. No defensible reason = not this blade.
**Note:** tallow sits on the seam between Comeback and Innocent Suspect ("demonized fat is actually good for you" = both). In health/DTC these two blades are neighbors; an angle can satisfy both. This blade only FIRES when research found a genuine "the market thinks X is dead/antiquated" belief — otherwise skip it (don't force a revival that isn't there).
**Naming register:** the reveal / positional ("The Comeback That Never Left").

---

## SMART-SELECT — how to choose which blades fit
For the chosen belief, walk each blade and ask "does the MOVE apply, with a real reason, AND does it leave the user standing?" Generate only from the blades that pass. For each blade you skip, write ONE line on why (this is shown to the user — the skip-reasoning is part of the value). Typical run: 2-4 blades fit. Fewer, sharper, distinct > six forced costumes on one idea.

## NAMING REGISTERS (for coining angle names)
REJECT verb-command names (Crown/Burn/Free/Resurrect). Use one of two registers:
- **Positional/spatial** — a place/direction you stand (The 180, The Third Door, The Wrong Battlefield).
- **The reveal** — "X is actually Y" (The Medicine Is the Poison).
