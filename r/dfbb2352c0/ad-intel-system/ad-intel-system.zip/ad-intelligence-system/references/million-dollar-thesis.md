# The Six-Card Thesis Framework

A structured way to extract the brand's core point of view from their ad library.

Every brand running serious ad volume has a consistent worldview baked into the ads. You won't see it in one ad. You'll see it when you look at a hundred of them together. This is the framework for naming it.

## The six cards

### 1. Core belief
The one thing the brand believes is true about the customer's problem that competitors don't believe (or don't dare say).

Look for: a claim that recurs in different words across the top 30 ads. The phrasing changes; the underlying assertion doesn't. That's the core belief.

### 2. Contrast
What is the brand arguing **against** — and what are they arguing **for**?

Brands with a real thesis are always taking a side. "Sleep is broken because of *X*, not because of *Y*." Identify both ends.

If you can't name a clear contrast after reading 30 ads, the brand probably doesn't have a thesis — they have a product description. Note that.

### 3. The big idea
The reframe that makes the brand's solution feel inevitable once you accept their belief.

Format: "If [core belief is true], then the only sensible response is [the brand's product / approach]."

### 4. Unique mechanism
The specific *thing* the product does that competitors don't — and that ties back to the core belief.

Mechanism is concrete. "Adapts to your sleep position" isn't a mechanism — it's a claim. "A central column of memory foam that compresses under your jaw at 30% lower density than the side panels" is a mechanism.

If the brand isn't using a unique mechanism in their copy, name what they're substituting for it (testimonials, social proof, founder story, etc.).

### 5. The villain
Who or what is the brand blaming for the customer's problem?

Common villains:
- A whole category (e.g. "diet culture")
- A competitor type (e.g. "big pharma")
- An institution (e.g. "the cereal industry")
- An outdated belief (e.g. "cardio for fat loss")
- The customer's past self (rarely; harder to pull off)

Brands without a villain are doing softer marketing. Note that.

### 6. Strength assessment
How entrenched is this thesis across the ad library?

- **Strong:** all top 30 ads tie back to the same belief. The brand has conviction.
- **Mixed:** some ads on-message, others generic. The brand is still figuring it out, or testing.
- **Weak:** no consistent thesis. They're running ads, not building a worldview.

Strong-thesis brands are harder to compete with on positioning. Weak-thesis brands are vulnerable — there's room for someone with a clearer point of view to take the category.

## How to read for thesis

Read the **first sentence** of each top-30 ad's body copy. Cluster them by what assertion they make about the customer's problem. The assertion that recurs most across clusters is the core belief.

Then read the **last sentence** (or the CTA) — that's where the implied villain often lives. "Stop relying on [thing]" or "Don't let [thing] win" — the thing is the villain.

The unique mechanism is harder. Look for the technical-feeling language. If they say "memory foam," that's category. If they say "Cervical support core with 30%-density side wings," that's mechanism. Mechanism language tends to use specific numbers, named components, or invented terms.
