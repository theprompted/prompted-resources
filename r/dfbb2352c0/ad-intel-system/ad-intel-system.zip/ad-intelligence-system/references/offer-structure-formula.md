# Offer Structure — The Six Elements

Every successful e-commerce offer has six elements. The brief's Q6 reads them off the top-2 landing pages.

## 1. The stack
**What's in the box.** Products + roles. A bundle isn't a stack — a stack has a clear primary product and supporting elements that each play a role.

Look for:
- A primary product (the hero)
- A complementary product (the partner that increases use frequency or solves an adjacent problem)
- Disposable / consumable add-ons (drives repeat purchase)
- Educational content (deepens the customer's relationship with the brand)

Note: many brands have one product on the LP — that's a stack of one. Note it as such; don't invent a stack that isn't there.

## 2. Price psychology
**The anchoring ladder.** What's the customer comparing this to?

Look for:
- The first-purchase price (what they pay today)
- The "compare-at" price (what the brand says it's regularly worth — creates the deal feeling without "discount" language)
- The savings amount (often spelled out: "Save $X today")
- Per-use cost framing (e.g. "less than $1/night")
- Subscription vs one-time framing

Brands that don't show a compare-at are usually category-leading on price (and the customer doesn't need anchoring) or premium (anchoring against the customer's existing solution rather than another product).

## 3. Risk reversal
**What happens if it doesn't work?**

Hierarchy of risk reversal, weakest to strongest:
- "Money-back guarantee" (vague — what triggers it?)
- "30-day money-back guarantee" (specific window)
- "60- or 90-day guarantee" (longer = more confident brand)
- "100-night trial" (the customer keeps the product during the trial — strongest)
- "No questions asked" (removes friction)
- "Free return shipping" (removes the cost)
- Lifetime warranty on workmanship

Brands with no risk reversal are signaling either commodity confidence ("you'll just buy it again, no trial needed") or low operational maturity. Note which it is.

## 4. Urgency
**Why now?**

Common urgency moves:
- Countdown timer ("Sale ends in 2:14:33")
- Inventory countdown ("Only 7 left at this price")
- Date-bound deadline ("Through Sunday only")
- Implicit urgency in the copy ("Your sleep is bad. Right now.")
- Social urgency ("3,000 people bought this last week")

**Often, urgency is deliberately absent.** A premium brand may run ZERO urgency moves across 200 ads — that's a positioning choice. Note when urgency is missing and what that suggests about the buyer.

## 5. Bonuses
**What gets thrown in for free.**

The classic move: list 3–5 things, attach a "value of $X" to each, total it as $Y, then "free with your order today."

Look for:
- Physical bonuses (free pillowcase, free travel bag)
- Digital bonuses (sleep guide, course, app subscription)
- Service bonuses (free consultation, free fitting)
- Time-limited bonuses (the bonus has urgency even if the price doesn't)

Bonuses solve a different problem than discount: they preserve perceived value while still increasing conversion.

## 6. Funnel awareness
**Where in the awareness ladder is the ad sending traffic?**

The five awareness stages (Schwartz):
- **Unaware** — doesn't know there's a problem
- **Problem-aware** — knows the problem but not the solution
- **Solution-aware** — knows solutions exist but not your product
- **Product-aware** — knows your product but hasn't decided
- **Most aware** — ready to buy on price/availability

Brands with sophisticated funnels match the ad's awareness stage to the LP. A problem-aware ad goes to a problem-aware LP (heavy education, light "buy now"). A product-aware ad goes to a product page.

Brands with **mismatched awareness** — problem-aware ad → product-aware LP — leak conversion at the LP. Worth flagging in the brief.

## Reading the awareness mix

Across the top 30 ads, count how many open with:
- Pure problem language ("Tired of waking up with neck pain?") → problem-aware
- Solution language ("There's a new way to sleep") → solution-aware
- Product language ("Meet the [Product Name]") → product-aware
- Price/availability ("Save $50 on...") → most-aware

The split tells you the brand's awareness strategy. A brand running 70% problem-aware ads is in education mode. 70% product-aware is conversion mode. 50/50 is balanced.

This is what you put in **Q6's "Funnel awareness" section** at the bottom of the offer card.
