#!/usr/bin/env python3
"""
Extract frames from video ads using FFmpeg.

For each *.mp4 in the input directory, extracts frames at 10fps for the
first 15 seconds. This gives ~150 frames per video — enough granularity
to read the first 3 seconds (the hook) without being overwhelming.

10fps, NOT 1fps. 1fps misses fast-cut hooks that change every 2-3 frames.

Requires: ffmpeg installed and on PATH.
    Mac:     brew install ffmpeg
    Windows: download from ffmpeg.org and add to PATH

Usage:
    python3 extract-frames.py media/brand-slug/ --output frames/brand-slug/
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def check_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


def extract_frames(video_path: Path, out_dir: Path, fps: int = 10, duration: int = 15) -> bool:
    """Extract frames from one video. Returns True on success."""
    out_dir.mkdir(parents=True, exist_ok=True)
    base = video_path.stem
    pattern = out_dir / f"{base}_%04d.jpg"

    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path),
        "-vf", f"fps={fps}",
        "-t", str(duration),
        "-q:v", "3",
        str(pattern),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            print(f"  [fail] {video_path.name}: ffmpeg returned {result.returncode}", file=sys.stderr)
            print(f"  stderr: {result.stderr[-500:]}", file=sys.stderr)
            return False
        # Count produced frames
        produced = list(out_dir.glob(f"{base}_*.jpg"))
        print(f"  [ok] {video_path.name} → {len(produced)} frames")
        return True
    except subprocess.TimeoutExpired:
        print(f"  [fail] {video_path.name}: timeout after 120s", file=sys.stderr)
        return False
    except Exception as e:
        print(f"  [fail] {video_path.name}: {e}", file=sys.stderr)
        return False


def main():
    p = argparse.ArgumentParser(description="Extract frames from video ads")
    p.add_argument("input", help="Directory containing *.mp4 files")
    p.add_argument("--output", required=True, help="Output directory for frames")
    p.add_argument("--fps", type=int, default=10, help="Frames per second (default 10)")
    p.add_argument("--duration", type=int, default=15, help="Seconds to extract (default 15)")
    args = p.parse_args()

    if not check_ffmpeg():
        print(
            "ERROR: ffmpeg not found on PATH.\n"
            "  Mac:     brew install ffmpeg\n"
            "  Windows: https://ffmpeg.org/download.html",
            file=sys.stderr,
        )
        sys.exit(1)

    in_dir = Path(args.input)
    out_dir = Path(args.output)
    videos = sorted(in_dir.glob("*.mp4"))
    if not videos:
        print(f"ERROR: no .mp4 files in {in_dir}", file=sys.stderr)
        sys.exit(1)

    print(f"Extracting frames from {len(videos)} videos at {args.fps}fps, first {args.duration}s")
    ok = 0
    for v in videos:
        if extract_frames(v, out_dir, args.fps, args.duration):
            ok += 1
    print(f"\nDone. {ok}/{len(videos)} videos processed. Output: {out_dir}")


if __name__ == "__main__":
    main()
