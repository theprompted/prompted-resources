#!/usr/bin/env python3
"""
Identify the top 2 landing pages from a scraped ad JSON, then scrape each
one with Playwright and extract structured offer data (price, compare-at,
guarantee, urgency, bonuses, CTA structure).

Why top 2: most brands concentrate traffic on 1-3 LPs. Scraping all 175
destinations is expensive and mostly redundant. Top 2 captures the offer
picture.

Requires: playwright installed and browsers downloaded.
    pip install playwright
    playwright install chromium

Usage:
    python3 scrape-landing-pages.py scraped/brand-slug.json --output lps/brand-slug/
"""

import argparse
import asyncio
import json
import re
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse


PRICE_RX = re.compile(r"\$\s?\d{1,4}(?:,\d{3})*(?:\.\d{2})?")
COMPARE_AT_TEXTS = ["was", "msrp", "regularly", "compare at", "compare-at", "list price"]
GUARANTEE_KEYWORDS = ["guarantee", "money-back", "money back", "risk-free", "risk free", "satisfaction", "warranty"]
URGENCY_KEYWORDS = ["limited time", "only \\d+ left", "ends today", "ends tonight", "while supplies last", "today only", "last chance"]
TRIAL_KEYWORDS = ["free trial", "try it free", "30-day trial", "60-day trial", "90-day trial"]


def find_top_landing_pages(ads: list, n: int = 2) -> list[tuple[str, int]]:
    """Find the top N landing page URLs by ad-count pointing to them."""
    counts = Counter()
    for ad in ads:
        url = (
            ad.get("destinationUrl")
            or ad.get("landingPageUrl")
            or ad.get("snapshot_url")
            or ""
        )
        if not url:
            continue
        # Normalize: strip query strings and tracking params
        parsed = urlparse(url)
        clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
        if clean:
            counts[clean] += 1
    return counts.most_common(n)


async def scrape_one_page(url: str, out_dir: Path) -> dict:
    """Scrape one landing page with Playwright. Returns extracted data."""
    from playwright.async_api import async_playwright

    out_dir.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", urlparse(url).netloc.lower()).strip("-")

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
            )
        )
        page = await ctx.new_page()
        try:
            await page.goto(url, wait_until="networkidle", timeout=30000)
        except Exception:
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            except Exception as e:
                await browser.close()
                return {"url": url, "error": str(e)}

        # Save full HTML for downstream analysis
        html = await page.content()
        (out_dir / f"{slug}.html").write_text(html)

        # Save a screenshot
        await page.screenshot(path=str(out_dir / f"{slug}.png"), full_page=True)

        # Extract visible text for keyword scanning
        try:
            visible_text = await page.evaluate("() => document.body.innerText")
        except Exception:
            visible_text = ""

        await browser.close()

    text_lower = visible_text.lower() if visible_text else ""
    prices = PRICE_RX.findall(visible_text or "")[:20]

    return {
        "url": url,
        "html_file": f"{slug}.html",
        "screenshot_file": f"{slug}.png",
        "prices_found": prices,
        "has_guarantee_language": any(kw in text_lower for kw in GUARANTEE_KEYWORDS),
        "has_urgency_language": bool(re.search("|".join(URGENCY_KEYWORDS), text_lower)),
        "has_trial_language": any(kw in text_lower for kw in TRIAL_KEYWORDS),
        "has_compare_at_language": any(kw in text_lower for kw in COMPARE_AT_TEXTS),
        "text_length": len(visible_text or ""),
    }


async def run(input_path: Path, output_dir: Path, top_n: int):
    data = json.loads(input_path.read_text())
    ads = data.get("ads", [])
    top_lps = find_top_landing_pages(ads, n=top_n)

    if not top_lps:
        print("WARN: no landing page URLs found in scrape", file=sys.stderr)
        return

    print(f"Top {len(top_lps)} landing pages:")
    for url, count in top_lps:
        print(f"  {count:3d} ads → {url}")

    output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    for url, count in top_lps:
        print(f"\nScraping: {url}")
        try:
            result = await scrape_one_page(url, output_dir)
            result["ad_count"] = count
            results.append(result)
            if "error" in result:
                print(f"  [fail] {result['error']}")
            else:
                print(f"  [ok] saved → {result['html_file']}, {result['screenshot_file']}")
                print(f"       prices: {len(result['prices_found'])} found")
                print(
                    "       signals: "
                    f"guarantee={result['has_guarantee_language']} "
                    f"urgency={result['has_urgency_language']} "
                    f"trial={result['has_trial_language']} "
                    f"compare_at={result['has_compare_at_language']}"
                )
        except Exception as e:
            print(f"  [fail] {e}")
            results.append({"url": url, "ad_count": count, "error": str(e)})

    summary = {"top_landing_pages": results}
    (output_dir / "lp-summary.json").write_text(json.dumps(summary, indent=2))
    print(f"\nDone. Summary: {output_dir / 'lp-summary.json'}")


def main():
    p = argparse.ArgumentParser(description="Scrape top landing pages from a brand's ads")
    p.add_argument("input", help="Path to scraped ads JSON")
    p.add_argument("--top", type=int, default=2, help="How many top landing pages to scrape (default 2)")
    p.add_argument("--output", required=True, help="Output directory for HTML, screenshots, and summary")
    args = p.parse_args()

    asyncio.run(run(Path(args.input), Path(args.output), args.top))


if __name__ == "__main__":
    main()
