#!/usr/bin/env python3
"""
Transcribe audio from video ads using Whisper (local, no API key required).

For each *.mp4 in the input directory, transcribes the first 15 seconds of
audio and writes a *.txt file with the transcript next to each video.

Auto-detects the best Whisper backend:
  1. mlx-whisper (Apple Silicon, ~5-10x faster) — preferred on Mac
  2. openai-whisper (everywhere else)

Install:
    On Mac (Apple Silicon):  pip install mlx-whisper
    Everywhere else:         pip install openai-whisper

Usage:
    python3 transcribe-audio.py media/brand-slug/
"""

import argparse
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def detect_backend() -> str:
    """Return 'mlx', 'openai', or 'none'."""
    is_apple_silicon = (
        platform.system() == "Darwin" and platform.machine() == "arm64"
    )
    if is_apple_silicon:
        try:
            import mlx_whisper  # noqa: F401
            return "mlx"
        except ImportError:
            pass
    try:
        import whisper  # noqa: F401
        return "openai"
    except ImportError:
        return "none"


def extract_audio_clip(video_path: Path, max_seconds: int = 15) -> Path:
    """Extract audio from the first N seconds of video using ffmpeg.
    Returns path to a temporary wav file."""
    if shutil.which("ffmpeg") is None:
        raise RuntimeError(
            "ffmpeg not found on PATH. "
            "Install: brew install ffmpeg (Mac) or https://ffmpeg.org (Windows)"
        )
    tmp_audio = Path(tempfile.mkstemp(suffix=".wav")[1])
    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path),
        "-t", str(max_seconds),
        "-vn",  # no video
        "-ac", "1",  # mono
        "-ar", "16000",  # 16kHz
        str(tmp_audio),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg failed: {result.stderr[-500:]}")
    return tmp_audio


def transcribe_mlx(audio_path: Path) -> str:
    """Transcribe with mlx-whisper (Apple Silicon)."""
    import mlx_whisper

    result = mlx_whisper.transcribe(
        str(audio_path),
        path_or_hf_repo="mlx-community/whisper-base",
    )
    return result.get("text", "").strip()


def transcribe_openai(audio_path: Path, model_name: str = "base") -> str:
    """Transcribe with openai-whisper (any platform)."""
    import whisper

    model = whisper.load_model(model_name)
    result = model.transcribe(str(audio_path))
    return result.get("text", "").strip()


def main():
    p = argparse.ArgumentParser(description="Transcribe video ad audio")
    p.add_argument("input", help="Directory containing *.mp4 files")
    p.add_argument("--max-seconds", type=int, default=15, help="Max seconds to transcribe (default 15)")
    p.add_argument(
        "--model",
        default="base",
        help="Whisper model size for openai-whisper (tiny/base/small/medium). Default: base",
    )
    args = p.parse_args()

    backend = detect_backend()
    if backend == "none":
        print(
            "ERROR: no Whisper backend installed.\n"
            "  Mac (Apple Silicon):  pip install mlx-whisper\n"
            "  Everywhere else:      pip install openai-whisper",
            file=sys.stderr,
        )
        sys.exit(1)
    print(f"Using {backend} backend.")

    in_dir = Path(args.input)
    videos = sorted(in_dir.glob("*.mp4"))
    if not videos:
        print(f"ERROR: no .mp4 files in {in_dir}", file=sys.stderr)
        sys.exit(1)

    print(f"Transcribing first {args.max_seconds}s of {len(videos)} videos")
    ok = 0
    for i, v in enumerate(videos, 1):
        out_txt = v.with_suffix(".txt")
        print(f"  [{i}/{len(videos)}] {v.name}")
        try:
            audio = extract_audio_clip(v, args.max_seconds)
            text = transcribe_mlx(audio) if backend == "mlx" else transcribe_openai(audio, args.model)
            out_txt.write_text(text or "(no speech detected)")
            audio.unlink(missing_ok=True)
            ok += 1
        except Exception as e:
            print(f"    [fail] {e}", file=sys.stderr)

    print(f"\nDone. {ok}/{len(videos)} transcribed. Transcripts saved next to each video.")


if __name__ == "__main__":
    main()
