#!/usr/bin/env python3
"""
Download media for the top N ads from a scraped JSON file.

Pulls poster images and video files (mp4) from the CDN URLs in the scrape.

NOTE: Facebook CDN URLs expire within hours. Run this in the same session
as the scrape, or you'll get 404s on the videos.

Usage:
    python3 download-media.py scraped/brand-slug.json --top 10 --output media/brand-slug/
"""

import argparse
import json
import sys
from pathlib import Path
from urllib.parse import urlparse

import requests


def download_url(url: str, dest: Path, timeout: int = 30) -> bool:
    """Download a URL to dest. Returns True on success."""
    if not url:
        return False
    try:
        resp = requests.get(url, timeout=timeout, stream=True)
        if resp.status_code != 200:
            print(f"    [skip] {resp.status_code} for {url[:60]}...", file=sys.stderr)
            return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
        return True
    except Exception as e:
        print(f"    [skip] {e} for {url[:60]}...", file=sys.stderr)
        return False


def main():
    p = argparse.ArgumentParser(description="Download media for top ads")
    p.add_argument("input", help="Path to scraped JSON file")
    p.add_argument("--top", type=int, default=10, help="How many top ads to download (default 10)")
    p.add_argument("--output", required=True, help="Output directory")
    args = p.parse_args()

    in_path = Path(args.input)
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    data = json.loads(in_path.read_text())
    ads = data.get("ads", [])

    # Sort by combined signal: rank + score
    def sort_key(a):
        rank = a.get("impressionRank", 99999)
        score = a.get("aiScore", 0)
        return -((1 - rank / max(len(ads), 1)) * 50 + score * 0.5)

    ads_sorted = sorted(ads, key=sort_key)
    top_ads = ads_sorted[: args.top]

    print(f"Downloading media for top {len(top_ads)} ads → {out_dir}")
    successes = {"posters": 0, "videos": 0}

    for i, ad in enumerate(top_ads, 1):
        lib_id = ad.get("libId") or ad.get("id") or f"unknown-{i}"
        print(f"  [{i}/{len(top_ads)}] {lib_id}")

        # Poster
        poster_url = ad.get("posterUrl") or ad.get("imageUrl") or ad.get("image")
        if poster_url:
            poster_dest = out_dir / f"{lib_id}_poster.jpg"
            if download_url(poster_url, poster_dest):
                successes["posters"] += 1

        # Video
        video_url = ad.get("videoUrl") or ad.get("video_hd") or ad.get("video_sd")
        if video_url:
            video_dest = out_dir / f"{lib_id}_video.mp4"
            if download_url(video_url, video_dest):
                successes["videos"] += 1

    print(
        f"\nDone. {successes['posters']} posters, {successes['videos']} videos saved."
    )
    print(f"Output: {out_dir}")


if __name__ == "__main__":
    main()
