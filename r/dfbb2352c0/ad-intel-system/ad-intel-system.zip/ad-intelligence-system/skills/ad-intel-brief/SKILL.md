---
name: Ad Intelligence Brief
description: "Run the full competitive ad analysis pipeline on a brand's Facebook ads and produce an HTML strategic brief organized as seven questions. Trigger phrases: 'run an ad intel brief on [brand]', 'competitive analysis on [brand]', 'ad breakdown for [brand]', 'analyze [brand]'s ads', 'build a brief on [brand]'."
---

# Ad Intelligence Brief — Full Competitive Ad Analysis

Run the full analysis pipeline on any brand's Facebook ads and produce an HTML strategic brief organized as **seven questions** that an agent uses directly as creative production context.

The brief is not a dashboard. It is a document handed to an agent, structured around the questions a good ad practitioner already asks silently when they look at a competitor's ads. **The structure is fixed across brands. The answers change every time.**

## Inputs

1. **Brand name** — the brand to analyze
2. **Page ID** (optional) — Facebook page ID for precise results. If unknown, search the Ad Library by keyword.
3. **Scroll depth** — default 15 (gets ~100–175 ads). Keep conservative to avoid rate limits.

## Pipeline overview

The deterministic data-gathering steps run as Python scripts (no AI inside any of them). The judgment-required analysis steps are Claude Code's job, using the gathered data as context.

```
DETERMINISTIC (Python helpers, run via Bash)
  ┌─────────────────────────────────────────────┐
  │  1. Scrape ads + score 8 signals             │
  │  2. Download top-10 media (posters + videos) │
  │  3. Extract frames at 10fps for top videos   │
  │  4. Transcribe audio (Whisper, local)        │
  │  5. Identify + scrape top 2 landing pages    │
  └─────────────────────────────────────────────┘
                         │
                         ▼
JUDGMENT (Claude Code, this skill)
  ┌─────────────────────────────────────────────┐
  │  6. Q3 avatar (read from copy)               │
  │  7. Q4 thesis (six-card framework)           │
  │  8. Q5 hook patterns (from frames + audio)   │
  │  9. Q6 offer story (from LP scrape)          │
  │  10. Q7 DO vs DON'T (pattern across all ads) │
  │  11. Per-ad breakdown cards (top 10)         │
  │  12. Action templates (copy + contrast)      │
  │  13. Render the HTML brief                   │
  └─────────────────────────────────────────────┘
```

## Step 1 — Scrape ads via the Ad Library API

```bash
python3 scripts/scrape-ads.py "BRAND" --page-id PAGE_ID --max-scroll 15 --output scraped/SLUG.json --status active
```

Use sort `impressions_high_to_low` (the script does this by default). This is the critical differentiator — the consumer UI does not expose ad rank to a user scrolling, but the API returns the same data in **ranked order**. Agent access to the API is what gives us the ranked inventory.

If rate-limited (0 cards, "No ads match your search criteria"):
- Wait. FB rate limits lift in 12–24 hours. Don't retry immediately — it won't help.
- A residential proxy ($5-10/mo) bypasses this permanently if it becomes a regular issue.

**Critical:** Meta does not publish raw impression counts for commercial ads in non-EU markets. You only get **rank position**. Rank 1 is being shown more than rank 10 — but you cannot say "rank 1 has X million impressions." Be precise about this in the brief. Rank is a proxy for distribution, not a direct readout of impressions.

## Step 2 — Score every ad

The scrape script runs `score_ads()` on the data automatically. **Eight signals:**

1. Impression rank — position in Ad Library sort
2. Days running — longer = brand keeps paying
3. Variant count — more variants = active iteration
4. Copy duplication — same copy across many ads = proven message
5. Funnel commitment — how many ads point to the same LP
6. Cross-page deployment — running from multiple brand pages
7. Format distribution — matched to what's scoring highest
8. Recency weighting — fresh tests vs sustained bets

Grades: **A = 70+, B = 60–69, C = 50–59.**

**Engagement data (likes / comments / shares) is deliberately NOT a signal.** Engagement rewards entertainment and controversy, not conversion. Run time and variant count are more honest indicators of what the brand actually believes in.

## Step 3 — Download media for top 10 ads

```bash
python3 scripts/download-media.py scraped/SLUG.json --top 10 --output media/SLUG/
```

Pulls poster images for all top 10 plus video mp4s where available.

**CDN URLs from Facebook expire within hours.** Download in the same session as the scrape. If you come back later, the URLs will be dead — you'd need to re-scrape.

The `libId` field is what the helper scripts use to name files (e.g. `{libId}_video.mp4`, `{libId}_poster.jpg`). Don't rename these — downstream scripts depend on the naming.

## Step 4 — Extract frames from top-10 videos

```bash
python3 scripts/extract-frames.py media/SLUG/ --output frames/SLUG/
```

Extracts frames at **10fps for the first 15 seconds**. Produces ~150 frames per video.

**10fps, not 1fps.** 1fps misses fast-cut hooks that change every 2-3 frames. 10fps gives enough granularity to read the first 3 seconds accurately.

## Step 5 — Transcribe audio (top-10 videos only)

```bash
python3 scripts/transcribe-audio.py media/SLUG/
```

Auto-detects Whisper backend: `mlx-whisper` on Apple Silicon (5-10x faster), `openai-whisper` everywhere else. Both run locally, no API key required.

Writes `{libId}.txt` next to each video with the transcript of the first 15 seconds. If a video has no speech, the file will say "(no speech detected)".

## Step 6 — Identify and scrape the top 2 landing pages

```bash
python3 scripts/scrape-landing-pages.py scraped/SLUG.json --top 2 --output lps/SLUG/
```

Groups every ad by destination URL, finds the two landing pages absorbing the most ad traffic, and scrapes them with Playwright.

For each LP, the script produces:
- Full HTML (`{lp-slug}.html`)
- Full-page screenshot (`{lp-slug}.png`)
- Signal flags (has_guarantee_language, has_urgency_language, has_trial_language, has_compare_at_language)
- Up to 20 detected price strings

**You read the HTML/screenshot directly to extract the offer details for Q6** (price, compare-at, guarantee, urgency, bonuses, awareness). The script gives you the raw material, not the analysis.

## Step 7 — Read the avatar (Q3)

After all data is gathered, read the **ad copy across all scraped ads** and the **landing page text**. Reverse-engineer the customer:

- **Demographics** — who they are on paper (age, role, life stage)
- **Identity** — how they see themselves (the customer's self-image — this is what the copy is mirroring back)
- **Attention** — what gets them to stop scrolling (the hooks that recur)
- **Turn-offs** — what makes them scroll past (what the brand is *avoiding* in copy)

The copy reveals the avatar — not because the brand sat down and wrote a customer profile, but because successful ads are the brand's record of what worked on which person. Reverse-engineer it from the body copy of the top-10 ads.

Output a plain-text avatar prompt formatted for pasting directly into another agent's context.

## Step 8 — Extract the thesis (Q4)

Every brand running a lot of ads has a consistent point of view baked in. You don't see it in one ad. You see it when you look at a hundred of them together.

Six mini-cards:

- **Core belief** — the one thing the brand believes is true about the customer's problem
- **Contrast** — what they're arguing against / what they're arguing for
- **The big idea** — the reframe that makes the brand's solution feel inevitable
- **Unique mechanism** — what makes their product the logical answer given the belief
- **The villain** — what they're blaming for the customer's problem
- **Strength assessment** — how entrenched this thesis is (are all ads consistent, or is it mixed?)

Read across the top 30 ads minimum to spot the thesis. Don't synthesize from 5 ads — you'll catch noise instead of pattern.

## Step 9 — Classify hook patterns (Q5)

A hook is the **first 3 seconds of a video** — what's on screen before someone decides to keep watching. It is **not the caption**. The caption is what someone reads after they've already stopped scrolling.

For each top-10 video, you have:
- The frames (in `frames/SLUG/{libId}_*.jpg`)
- The transcript (in `media/SLUG/{libId}.txt`)
- The poster (in `media/SLUG/{libId}_poster.jpg`)

Read the first 30 frames (3 seconds at 10fps) plus the first sentence of the transcript. Classify the hook into a pattern:

- Question hook ("What if I told you...")
- Pattern interrupt (visually unexpected first frame)
- Contrarian claim ("Everyone's wrong about...")
- Demonstration ("Watch what happens when...")
- Authority/credential ("As a [profession], I...")
- Personal story ("I used to...")
- Statistic/specific number
- Comparison/before-after
- Plain product demo

Rank the hook patterns by **average impression rank** of ads using each pattern. The pattern with the lowest average rank (i.e., highest in the API sort) is what the brand believes works best.

Map each pattern to **awareness stage** (problem-aware, solution-aware, product-aware) — different hooks serve different stages.

## Step 10 — Synthesize the offer (Q6)

Open the LP HTML and screenshot. Extract:

- **Price** — what they're charging (first-purchase price)
- **Compare-at** — what they say it's "regularly" worth (creates the deal feeling without "discount" language)
- **Offer stack** — what's included (products + roles)
- **Risk reversal** — trial, guarantee, warranty
- **Urgency** — countdown timers, "only X left" — often **absent — deliberately**
- **Bonuses** — included extras
- **Funnel awareness** — what % of ads are problem-aware vs product-aware (read from ad copy)

Why **top 2 specifically**: most brands concentrate traffic on 1–3 LPs. Scraping all 175 destinations is expensive and mostly redundant. Top 2 captures the real offer picture.

## Step 11 — DO vs DON'T (Q7)

What a brand never does across hundreds of ads is a deliberate choice. A brand that never runs countdown timers in 200 ads isn't forgetting to — they know their buyer doesn't respond to pressure.

Two-column DO vs DON'T with **counts per line** (e.g. "No urgency language — 0 of 175 ads", "Lead with product-specific construction — 145 of 175 ads").

Buyer inference note below: what each zero reveals about the type of person they're selling to.

## Step 12 — Per-ad breakdown cards (top 10)

For each of the top 10 ads, produce a **one-screen breakdown card** (target ~80–100 words). Consistent shape across all 10 so the reading agent can pattern-match:

```
▸ Visual: [for video: 3-beat breakdown first3s/middle/close · for image: eye-path]
▸ Hook: [which Q5 hook pattern this uses — or blend]
▸ Copy: [what the body copy does beyond the hook — credentialing / social proof / objection-handling]
▸ Offer: [in-ad or LP-only]
▸ Awareness: [problem-aware / solution-aware / product-aware]

Hypothesis: [2–3 sentences naming the specific mechanism of why this is working —
hedged ("likely working because…" / "appears to…") — not generic]
```

The hypothesis is the **load-bearing piece**. Not "this ad works because it's video." Specific, mechanistic, hedged.

## Step 13 — Action templates

**Copy mode** — 4 fill-in-the-blank templates extracted from the top hooks. Black background, teal text, bracketed variables. Each includes:
- Hook pattern name and reference to the Q5 pattern
- Template with `[bracketed variables]` for the user's product
- One real example sentence from the brand

**Contrast mode** — 4 contrarian hooks. **NOT gap-filling** — saying the OPPOSITE of the brand's dominant message, then making it true. The hook violates expectations. The body resolves it credibly. Each includes:
- Which dominant move it inverts
- The template
- One-line note on when to use it

**Decision rule for the user:** same type of buyer as the brand you studied → copy mode. Real point of difference, or category has converged on the same angles → contrast mode.

## Step 14 — Render the HTML brief

Use the structural scaffold described below (consistent visual system across all sections — teal accent `#53DBC9`, monospace headers, offset shadows, 2px solid black borders).

**Required structure (this order, exactly):**

1. Header + "How to use this document" framing
2. Q1 — What are they running, and how much on each? (stats + top 10 ads inline)
3. Q2 — Where are they putting their money? (scoring methodology + pattern across top scoring)
4. Q3 — Who is the avatar? (4 mini-cards + agent prompt box)
5. Q4 — What do they believe? (6-card thesis)
6. Q5 — What hooks are working? (ranked patterns + awareness mapping)
7. Q6 — What's the actual offer? (LP-derived offer table + 6-element stack)
8. Q7 — What are they NOT doing? (DO vs DON'T + buyer inference)
9. Action: Copy mode (4 templates)
10. Action: Contrast mode (4 inverted hooks)
11. Footer + floating "Copy brief for your agent" button

**Embed all media as base64 data URIs.** The brief is delivered as a local HTML file (`file://`). Root-relative paths don't work from `file://` unless you run a server. Base64 embeds everything directly in the HTML — fully self-contained.

```python
import base64
with open(video_path, 'rb') as f:
    b64 = base64.b64encode(f.read()).decode('utf-8')
video_data_uri = f"data:video/mp4;base64,{b64}"
```

**Top 10 ads inline structure:**
- Grade/rank tags + "why this ad" callout (the combined signal reasoning) at the top of the entry
- The FB feed card with embedded media immediately below
- The breakdown card immediately below the feed card
- **Do not separate the ads and their hypotheses into different sections.** First mention = preview + hypothesis. Users get confused when the hypothesis lives anywhere other than next to the ad.

Output: `briefs/{brand-slug}-brief.html`

## Design principles

- **Impressive because it's useful, not because it's trying to be impressive**
- **Clarity → usefulness → impressive.** Never start with impressive. Impressive is a side effect of clear + useful.
- **Creatives embedded alongside every claim** — never analyze without showing the ad
- **Hedged language on hypotheses** — "this could mean…" / "likely working because…" / "we can't tell from the outside"
- **Fill-in-the-blank prompts** that translate patterns into actionable templates
- **No false confidence** — the worst thing this skill can do is sound certain about something it inferred
- **The brief is context for agents** — structured so the agent can use it to produce informed creative without the human having to interpret it first
- **Questions force a point of view.** Summaries describe. The seven-question structure is the point.

## What this skill does NOT cover

- TikTok, YouTube, Google, or other ad platforms — Meta only
- Email / SMS creative — not in the Ad Library
- Organic social — not in the Ad Library
- Paid search — would require a separate Google Ads Transparency skill
- Influencer / UGC outside of paid amplification — not detected

Name these explicitly in the brief's "how to use this document" framing if relevant, so the viewer doesn't overclaim what the system knows.

## Cost / runtime expectations

- Scrape: ~4 min for 175 ads
- Score: instant (deterministic Python)
- Top-2 LP scrape: ~30 sec each
- Frame extraction: ~1 min for top 10
- Audio transcription: ~10 min on Apple Silicon with mlx-whisper (slower without)
- Brief synthesis: depends on Claude Code session length

**Total wall-clock time:** ~20–30 minutes per brief on a typical Mac.
**API cost:** $0 (everything runs locally except your existing Claude Code subscription).
