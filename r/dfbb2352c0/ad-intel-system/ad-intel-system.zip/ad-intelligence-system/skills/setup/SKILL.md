---
name: Setup Ad Intel System
description: "Install all prerequisites for the ad intelligence system. Trigger phrases: 'set up the ad intel system', 'install dependencies', 'set up this project', 'get me ready to run briefs', 'install everything I need'."
---

# Setup the Ad Intelligence System

Claude Code uses this skill to install every dependency the user needs to run an ad intel brief end to end. Run this once per machine. After it succeeds, the user runs `ad-intel-brief` whenever they want a brief.

The user has already:
- Installed Claude Code (we're running inside it)
- Downloaded the bundle zip
- Unzipped it
- Opened Claude Code in the unzipped folder

The user has NOT necessarily:
- Installed Python
- Installed Homebrew (Mac) or any package manager (Windows)
- Installed FFmpeg
- Installed any Python libraries
- Installed Playwright browsers
- Installed Whisper
- Configured `.env`
- Copied the skill into `.claude/skills/`

This skill walks through every one of those, in order, with clear progress messages.

## Critical: ask before installing each major thing

Don't `brew install` or `pip install` without telling the user what's about to happen and why. The user expects pauses. Each install needs a one-line "I'm about to install X because Y."

## Critical: handle password prompts gracefully

When `sudo` or `brew install` requires a password, the user has to type it in Terminal directly. Claude Code can't pass the password through. When this happens, tell them clearly: *"You'll see a password prompt in Terminal — type your Mac password (you won't see characters as you type). Press Enter when done."*

## Detection order

Run these checks first, all in parallel via Bash, before installing anything. Use the results to decide what's actually needed.

```bash
# OS detection
uname -s        # Darwin = Mac, Linux = Linux, MINGW/MSYS = Windows
uname -m        # arm64 = Apple Silicon, x86_64 = Intel

# Python
python3 --version 2>&1     # need 3.11+
which python3

# Homebrew (Mac only)
which brew

# FFmpeg
which ffmpeg
ffmpeg -version 2>&1 | head -1

# Already-installed Python packages
python3 -c "import requests; print(requests.__version__)" 2>&1
python3 -c "import playwright; print(playwright.__version__)" 2>&1
python3 -c "import mlx_whisper" 2>&1
python3 -c "import whisper" 2>&1

# Playwright browsers
ls ~/Library/Caches/ms-playwright 2>&1 | head -5
```

Based on the results, decide the install plan. Tell the user the plan in plain English before executing it. Example:

> Here's what I'll install:
> - Homebrew (your Mac doesn't have it yet — needed for FFmpeg)
> - FFmpeg (extracts video frames and audio)
> - Python libraries: requests, playwright (for the scraper and landing page scraping)
> - mlx-whisper (Apple Silicon optimized speech-to-text — runs locally, no API)
> - Playwright's Chromium browser
>
> I'll also copy the ad-intel-brief skill into `.claude/skills/` so you can call it.
>
> You'll see a password prompt at least once — for the Homebrew install. Type your Mac password (you won't see characters) and press Enter.
>
> Should I proceed?

## Install steps

### Step 1: Python (only if missing)

If `python3 --version` fails or returns < 3.11:

**Mac:** install Homebrew first if missing (see step 2), then `brew install python@3.12`
**Windows:** stop and ask the user to install from https://www.python.org/downloads/ (and check "Add to PATH"). Don't proceed automatically — Windows Python installs need a GUI installer.
**Linux:** `apt install python3` or equivalent — usually already there.

After installing, **tell the user to close and reopen Claude Code** so it picks up the new PATH.

### Step 2: Homebrew (Mac only, only if missing)

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

This will prompt for the user's Mac password. Tell them in advance.

After install, on Apple Silicon Macs, also tell the user that the post-install message says to add Homebrew to PATH — Claude Code should run those commands too:
```bash
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
eval "$(/opt/homebrew/bin/brew shellenv)"
```

### Step 3: FFmpeg

**Mac:** `brew install ffmpeg`
**Windows:** download from https://www.gyan.dev/ffmpeg/builds/ — needs manual install. If we hit this branch, walk the user through downloading the "essentials" zip, extracting it, and adding `bin/` to PATH. This needs the user to act in File Explorer.
**Linux:** `apt install ffmpeg` or `dnf install ffmpeg`

Verify after: `ffmpeg -version | head -1`

### Step 4: Python libraries

```bash
pip3 install -r requirements.txt
```

If `pip3` complains about needing a virtual environment (PEP 668 on newer Python), use `pip3 install --break-system-packages -r requirements.txt` — it's fine for this use case.

### Step 5: Whisper (one or the other)

Detect Apple Silicon: `uname -m` → if `arm64` AND on Mac:
```bash
pip3 install mlx-whisper
```

Otherwise:
```bash
pip3 install openai-whisper
```

### Step 6: Playwright browsers

```bash
playwright install chromium
```

This downloads ~200 MB. Tell the user it'll take a minute.

### Step 7: Copy skills into `.claude/skills/`

```bash
mkdir -p .claude/skills
cp -r skills/ad-intel-brief .claude/skills/
cp -r skills/setup .claude/skills/
```

(Yes, copy this setup skill itself in too — so it persists for re-runs and for any future repair operations.)

### Step 8: Smoke test

Run a quick end-to-end check that everything imports cleanly:

```bash
python3 -c "
import requests
import playwright
print('OK: requests, playwright')
try:
    import mlx_whisper
    print('OK: mlx-whisper (Apple Silicon)')
except ImportError:
    import whisper
    print('OK: openai-whisper')
"

ffmpeg -version | head -1
```

Confirm Playwright's Chromium is actually installed:
```bash
python3 -c "
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser = p.chromium.launch()
    browser.close()
print('OK: Chromium launches cleanly')
"
```

## Final report to the user

After all steps pass:

> ✅ Setup complete.
>
> You're ready to run briefs. Try:
>
> *"Run an ad intel brief on Mixed by Nasrin"*
>
> First time you run a brief, Whisper will download its base model (~150 MB) automatically. After that, every brief takes about 20–30 minutes wall clock.
>
> If anything errors during a brief, just describe the error and I'll fix it.

## If anything fails

- Clearly identify which step failed.
- Show the user the actual error output.
- Either retry with a different approach, or stop cleanly and explain what they need to do manually.
- **Do not silently skip a failed step.** Many downstream features depend on these — better to halt and surface the problem.

## When the user runs this again

If they say "set up the ad intel system" twice (e.g. on a new project), this skill is idempotent: every check returns "already installed" and we skip it. Only re-run the smoke test and the skill copy.
