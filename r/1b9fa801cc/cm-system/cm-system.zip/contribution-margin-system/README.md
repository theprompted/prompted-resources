# Contribution Margin System — Setup Guide

This guide walks you through setting up a real-time contribution margin tracker for your Shopify store. By the end, you'll have:

- A dashboard you can open in your browser that updates every 15 minutes with your actual margin (not just revenue minus ad spend)
- Three "skills" you can ask Claude Code to use, like *"how much did we make yesterday"* or *"what hours are we losing money"*
- A log of every snapshot, so you can answer questions about your business going back days or weeks

This is the system from the YouTube video *"Recovering $1K/Day in Facebook Ads with Claude Code."*

**Time to set up:** about 60–90 minutes the first time, mostly waiting on accounts.
**Cost:** $0. Everything used is free.
**Technical level required:** if you've installed software before and can copy-paste a command into a terminal, you can do this.

---

## Table of contents

1. [What you need before you start](#1-what-you-need-before-you-start)
2. [Install the prerequisites](#2-install-the-prerequisites)
3. [Download and unzip the bundle](#3-download-and-unzip-the-bundle)
4. [Get your Shopify credentials](#4-get-your-shopify-credentials)
5. [Get your Meta (Facebook) credentials](#5-get-your-meta-facebook-credentials)
6. [Configure the `.env` file](#6-configure-the-env-file)
7. [Fill in your unit economics](#7-fill-in-your-unit-economics)
8. [Test that it works](#8-test-that-it-works)
9. [Schedule it to run every 15 minutes](#9-schedule-it-to-run-every-15-minutes)
10. [Use the skills inside Claude Code](#10-use-the-skills-inside-claude-code)
11. [If something goes wrong](#11-if-something-goes-wrong)
12. [What this bundle does NOT include](#12-what-this-bundle-does-not-include)

---

## 1. What you need before you start

Before you do anything, make sure you have the following. If you don't have something on this list, the rest of the guide won't work.

- [ ] **A Shopify store** that you own or have admin access to.
- [ ] **A Meta Ads account** running Facebook / Instagram ads, where you have admin access.
- [ ] **A computer** running macOS or Windows.
- [ ] **A Claude subscription** (Pro or Team) — needed to run Claude Code.
- [ ] **About 60–90 minutes** of focused time.

If any of those aren't true, stop here and come back when they are.

---

## 2. Install the prerequisites

You'll need three pieces of software:

1. **Python** — the language the cron script is written in
2. **Claude Code** — the AI tool that runs the skills
3. **A code editor** — to view and edit a couple of text files (`.env` and `unit-economics.json`)

### 2.1. Install Python

#### On Mac

1. Open the **Terminal** app. (Press `Cmd+Space` to open Spotlight, type `Terminal`, press Enter.)
2. Copy and paste this exactly, then press Enter:
   ```
   python3 --version
   ```
3. **If you see a number like `Python 3.11.x` or higher**, you already have Python and can skip to section 2.2.
4. **If you see `command not found` or a version below 3.11**, do this:
   - Go to [python.org/downloads](https://www.python.org/downloads/)
   - Click the big yellow "Download Python 3.x.x" button
   - Open the file you downloaded (it ends in `.pkg`) and follow the installer. Click "Continue" / "Agree" / "Install" through every prompt. You may need to enter your Mac password.
   - When it's done, **close Terminal completely** and reopen it.
   - Run `python3 --version` again to confirm. You should now see `Python 3.11.x` or higher.

#### On Windows

1. Open the **Command Prompt** app. (Press the Windows key, type `cmd`, press Enter.)
2. Copy and paste this exactly, then press Enter:
   ```
   python --version
   ```
3. **If you see a number like `Python 3.11.x` or higher**, you already have Python and can skip to section 2.2.
4. **If you see `'python' is not recognized` or a version below 3.11**, do this:
   - Go to [python.org/downloads](https://www.python.org/downloads/)
   - Click the big yellow "Download Python 3.x.x" button
   - Open the file you downloaded (it ends in `.exe`)
   - **Important:** on the first installer screen, **check the box that says "Add python.exe to PATH"** at the bottom. If you skip this, nothing will work.
   - Click "Install Now" and let it finish.
   - When it's done, **close Command Prompt completely** and reopen it.
   - Run `python --version` again to confirm. You should now see `Python 3.11.x` or higher.

### 2.2. Install the Python libraries this script needs

The script uses two small libraries: `requests` (for talking to Shopify and Meta) and `python-dotenv` (for reading your settings).

#### On Mac, in Terminal:

```
pip3 install requests python-dotenv
```

#### On Windows, in Command Prompt:

```
pip install requests python-dotenv
```

You should see a few lines of output ending with something like `Successfully installed requests-... python-dotenv-...`. If you see errors, see [section 11](#11-if-something-goes-wrong).

### 2.3. Install Claude Code

Claude Code is a free tool from Anthropic that runs in your terminal and uses your Claude subscription.

1. Go to the [Claude Code installation page](https://docs.claude.com/en/docs/claude-code/quickstart) and follow the instructions there. (They keep the install command up to date — anything I write here will go stale.)
2. Once installed, open a terminal in any folder and type `claude`. The first time you run it, it'll ask you to log in with your Claude account. Follow the prompts.
3. Once you see a `❯` prompt waiting for input, Claude Code is working. Type `/exit` or press `Ctrl+D` to exit for now.

### 2.4. Install a code editor

You only need a code editor to edit two text files. Any of these is fine — pick one:

- **Visual Studio Code** (free, popular) — [code.visualstudio.com](https://code.visualstudio.com/)
- **Sublime Text** (free to evaluate) — [sublimetext.com](https://www.sublimetext.com/)
- **TextEdit** (Mac, built-in) — works but you have to switch it to "plain text mode" via Format → Make Plain Text
- **Notepad** (Windows, built-in) — works fine for this

If you're not sure, install **Visual Studio Code**. It's the most common, and there are tons of tutorials if you ever get stuck.

---

## 3. Download and unzip the bundle

You've been given a zip file (e.g. `contribution-margin-system.zip`).

1. Move the zip file to a place you'll remember. **Recommended:** your **Desktop**.
2. Double-click the zip file to extract it. You should now see a folder called `contribution-margin-system` on your Desktop.
3. Open that folder. You should see the following structure inside:
   ```
   contribution-margin-system/
   ├── README.md                    ← this file
   ├── .env.example
   ├── skills/
   │   ├── cm-tracker/
   │   ├── cm-trends/
   │   └── hourly-analysis/
   ├── scripts/
   │   └── cm-tracker-cron.py
   └── references/
       ├── unit-economics.template.md
       └── unit-economics.template.json
   ```

> **Tip — making hidden files visible.** The file `.env.example` starts with a dot, which makes it hidden by default on Mac and Windows.
> - **On Mac:** in Finder, press `Cmd+Shift+.` (period) to toggle hidden files on and off.
> - **On Windows:** in File Explorer, click the "View" tab at the top, then check "Hidden items".

You now have all the code on your computer. The next sections walk through getting your Shopify and Meta credentials, then plugging them in.

---

## 4. Get your Shopify credentials

You need an **Admin API access token** from your Shopify store. This is what lets the script read your orders.

> **You only do this once.** Once you have the token, you don't need to do this again unless you delete the app.

1. Log into your Shopify admin at `https://yourstore.myshopify.com/admin` (replace `yourstore` with your actual store).
2. In the left sidebar, click **Settings** (gear icon at the very bottom).
3. Click **Apps and sales channels**.
4. Click **Develop apps** (top right of the page). If you've never done this before, Shopify will ask you to "Allow custom app development" — click that and confirm.
5. Click **Create an app**.
6. Give it a name (e.g. `CM Tracker`) and click **Create app**.
7. Click the **Configuration** tab.
8. Under **Admin API integration**, click **Configure**.
9. Scroll through the list of scopes and check the boxes for these (use the search box at the top to find each one quickly):
   - `read_orders`
   - `read_all_orders` *(this one is important — without it, you can only read the last 60 days)*
   - `read_reports` *(only if you want the hourly-analysis skill)*
10. Click **Save** at the top right.
11. Click the **API credentials** tab.
12. Click **Install app** at the top right. Confirm by clicking **Install** in the dialog.
13. After it installs, you'll see an **Admin API access token** field with a "Reveal token once" button. Click it.
14. **Copy the token immediately and paste it somewhere safe** (like a sticky note in your password manager). It starts with `shpat_` and you can only view it once. If you lose it, you'll have to uninstall and reinstall the app.

You also need your **store domain**. It's the `something.myshopify.com` part — for example, if your admin URL is `https://shopthebrand.myshopify.com/admin`, your store domain is `shopthebrand.myshopify.com`.

**Save these two values** somewhere you can find them in 5 minutes:

- Store domain: `____________.myshopify.com`
- Admin API token: `shpat_____________________`

---

## 5. Get your Meta (Facebook) credentials

You need a **Meta access token** with the `ads_read` permission, plus your **ad account ID**.

> **Heads up:** Meta tokens from the Graph API Explorer expire after about an hour. For long-term use, you'll want to extend it to a 60-day token (steps below). For now, just get a short token to make sure everything works.

### 5.1. Get a short-lived token (to test with)

1. Go to [developers.facebook.com](https://developers.facebook.com/). Log in with the Facebook account that has access to your ads.
2. In the top menu, hover over **My Apps** and click **Create App** (if you don't already have an app). Choose "Other" / "Business" as the type. Fill in a name like `CM Tracker`.
3. Once your app exists, in the top menu hover over **Tools** and click **Graph API Explorer**.
4. On the right side, find the **Meta App** dropdown and select your app.
5. Click the **User or Page** dropdown and select **Get User Access Token**.
6. A dialog will appear asking which permissions you want. **Click "Add Permission" and add `ads_read`**. (You may need to click "Add Permission" multiple times to find it — search for `ads_read`.)
7. Click **Generate Access Token**. Facebook will ask you to approve. Click through.
8. The long string in the **Access Token** field at the top is your token. **Copy it and paste it somewhere safe.** It starts with something like `EAAB...`.

### 5.2. Get your ad account ID

1. Go to [business.facebook.com](https://business.facebook.com/).
2. Click the menu icon (three lines) at the top left, then **Business settings**.
3. In the left sidebar, click **Accounts** → **Ad Accounts**.
4. Find the ad account you use for the store. Underneath the account name is a number — that's your ad account ID.
5. **The format the script needs is `act_` followed by the number.** For example, if the number is `1234567890123456`, your value is `act_1234567890123456`.

### 5.3. (Recommended) Extend your token to 60 days

The token from step 5.1 only lasts about an hour. To make it last 60 days:

1. In the same Graph API Explorer page, copy your short token from the Access Token field.
2. Open this URL in a new browser tab (replace `YOUR_TOKEN` with the token you just copied):
   ```
   https://graph.facebook.com/v21.0/oauth/access_token?grant_type=fb_exchange_token&client_id=YOUR_APP_ID&client_secret=YOUR_APP_SECRET&fb_exchange_token=YOUR_TOKEN
   ```
3. To find `YOUR_APP_ID` and `YOUR_APP_SECRET`: in your app's dashboard at [developers.facebook.com](https://developers.facebook.com/), click **App settings** → **Basic**. App ID is at the top. Click "Show" next to App secret (it'll ask for your password).
4. The URL will return a JSON response with a new `access_token` field. **That's your 60-day token.** Use that one instead.

You don't *have* to do this — the script will work with a short token, you just have to refresh it every hour. For real use, the 60-day token is the way.

**Save these three values:**

- Meta access token: `EAA________________________________`
- Ad account ID: `act_____________`
- API version: `v21.0` (just use this — it's the current version as of writing)

---

## 6. Configure the `.env` file

The `.env` file is where you tell the script your credentials and settings.

1. In the `contribution-margin-system` folder, find the file called `.env.example`.
2. **Make a copy of it and rename the copy to `.env`** (no extension, just `.env`).
   - **On Mac:** In Terminal, navigate to the folder and run:
     ```
     cd ~/Desktop/contribution-margin-system
     cp .env.example .env
     ```
   - **On Windows:** In Command Prompt:
     ```
     cd %USERPROFILE%\Desktop\contribution-margin-system
     copy .env.example .env
     ```
3. Open the new `.env` file in your code editor (right-click → Open With → Visual Studio Code, or whatever editor you installed).
4. Fill in each value with what you collected in sections 4 and 5. The file has comments explaining each one. The required ones are:
   ```
   BRAND_NAME=My Store                        ← shows up in the dashboard header
   SHOPIFY_STORE=yourstore.myshopify.com      ← from section 4
   SHOPIFY_ACCESS_TOKEN=shpat_xxxxx           ← from section 4
   META_ACCESS_TOKEN=EAAxxxxx                 ← from section 5
   META_AD_ACCOUNT_ID=act_xxxxx               ← from section 5
   ```
5. **For currency and timezone:**
   - If your Shopify revenue and Meta ad spend are in the same currency (e.g. both USD), leave `STORE_CURRENCY` and `AD_SPEND_CURRENCY` set to the same value.
   - If they're different (e.g. USD revenue but CAD ad spend, common for Canadian operators), set them accordingly. The script will look up the live exchange rate.
   - For `STORE_TIMEZONE`, use your store's timezone in IANA format. Most US stores: `America/New_York`. Other examples: `America/Los_Angeles`, `America/Chicago`, `Europe/London`, `Australia/Sydney`. [Full list here](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones).
6. **Save the file.** Make sure your editor saves it as plain text, not as `.env.txt` (Notepad on Windows is sneaky about this — see the tip below).

> **Important — `.env` filename gotcha on Windows.** Notepad and some editors sneakily save your file as `.env.txt` even when you type `.env`. To check: in File Explorer, click View → "File name extensions" so extensions show. If you see `.env.txt`, right-click → Rename and remove the `.txt`. The script will not work if the file is named `.env.txt`.

---

## 7. Fill in your unit economics

The script needs to know your COGS (cost of goods sold), shipping costs, and processing/returns rates to calculate real margin. This lives in `references/unit-economics.json`.

1. In the `references` folder, find the file called `unit-economics.template.json`.
2. **Make a copy of it and rename the copy to `unit-economics.json`** (drop the `.template` part). Same `cp` / `copy` pattern as the `.env` file.
3. Open `unit-economics.json` in your code editor.
4. Read `unit-economics.template.md` (in the same folder) — it walks through what every section means and how to figure out your numbers.
5. Fill in the JSON file with your actual numbers. Three things to be careful about:
   - **`processing_rate`**: pull this from a recent monthly statement from your payment processor. Don't guess. Most Shopify Payments stores land at ~4.1% blended once you include chargebacks and currency conversion fees.
   - **`returns_rate`**: pull from your last 90 days of refunds. `total_refunds / total_revenue`. Apparel ~5–8%, supplements ~1–2%, hard goods ~1–3%.
   - **`shipping_tiers`**: pull from your actual carrier rate sheet. Small per-order errors compound across thousands of orders.
6. **Save the file** and make sure it's still valid JSON. (If you accidentally delete a comma or quote, the script will refuse to start. If unsure, paste the file into [jsonlint.com](https://jsonlint.com/) — it'll tell you if there's a syntax error.)

If you've never done unit economics before, this is the part that takes the longest. Take your time. The accuracy of everything downstream depends on this file.

---

## 8. Test that it works

Time to do a manual test run.

1. Open Terminal (Mac) or Command Prompt (Windows).
2. Navigate to the project folder:
   - **Mac:**
     ```
     cd ~/Desktop/contribution-margin-system
     ```
   - **Windows:**
     ```
     cd %USERPROFILE%\Desktop\contribution-margin-system
     ```
3. Run the script:
   - **Mac:**
     ```
     python3 scripts/cm-tracker-cron.py
     ```
   - **Windows:**
     ```
     python scripts\cm-tracker-cron.py
     ```
4. You should see output like this:
   ```
   [2026-05-04T10:15:00...] Starting CM run...
     Fetching Shopify orders...
     Got 12 orders.
   [2026-05-04T10:15:08...] Done. Rev: $487.23 | CM: $34.10 | Orders: 12
   ```
5. After a successful run, the script created two files in a new `reports/` folder:
   - `reports/cm-tracker.jsonl` — the snapshot log (one line per run)
   - `reports/cm-tracker.html` — the dashboard
6. **Open the HTML dashboard:**
   - **Mac:** in Terminal, run `open reports/cm-tracker.html` — it'll open in your default browser.
   - **Windows:** in File Explorer, navigate to `Desktop\contribution-margin-system\reports`, double-click `cm-tracker.html`.
7. You should see a styled dashboard with your revenue, CM, ROAS, and order count for today, plus a waterfall breakdown.

If you see errors in step 4 instead of a clean output line, jump to [section 11](#11-if-something-goes-wrong).

---

## 9. Schedule it to run every 15 minutes

Once the manual run works, schedule it so it runs automatically every 15 minutes. The dashboard's auto-refresh will keep showing fresh numbers without you doing anything.

### On Mac (using cron)

1. In Terminal, type:
   ```
   crontab -e
   ```
   This opens an editor (probably `vim`, which is awkward — see tip below).
2. Press `i` to enter insert mode.
3. Add this line, but **replace `/Users/yourname/Desktop/contribution-margin-system` with your actual path**:
   ```
   */15 * * * * /usr/bin/python3 /Users/yourname/Desktop/contribution-margin-system/scripts/cm-tracker-cron.py >> /Users/yourname/Desktop/contribution-margin-system/reports/cron.log 2>&1
   ```
   To find your actual path, in Terminal navigate to the folder (as in step 8.2), then run `pwd`. Copy what it prints.
4. Press `Esc`, then type `:wq` and press Enter to save and exit.
5. Confirm it saved by running:
   ```
   crontab -l
   ```
   You should see your line.

> **Tip — if vim is too painful**, run this instead of `crontab -e`. It uses a simpler editor (nano):
> ```
> EDITOR=nano crontab -e
> ```
> In nano, you just type, then press `Ctrl+O` to save, Enter to confirm, `Ctrl+X` to exit.

> **Heads up — macOS may block cron from accessing your Desktop.** If after 15 minutes you don't see new lines in `reports/cm-tracker.jsonl`, this is probably why. Open System Settings → Privacy & Security → Full Disk Access → click the `+` button → navigate to `/usr/sbin/cron` (you may need to press `Cmd+Shift+G` and type `/usr/sbin`) and add it. Or move the project folder out of `Desktop` to your home folder (`~/cm-tracker`) where cron can access it without extra permissions.

### On Windows (using Task Scheduler)

1. Press the Windows key, type `Task Scheduler`, press Enter.
2. In the right panel, click **Create Basic Task**.
3. Name: `CM Tracker`. Click Next.
4. Trigger: **Daily**. Click Next. Set start time to now. Click Next.
5. Action: **Start a program**. Click Next.
6. Program/script: `python` (just the word).
7. Add arguments: `scripts\cm-tracker-cron.py`
8. Start in: paste the full path to your project folder, e.g. `C:\Users\YourName\Desktop\contribution-margin-system`
9. Click Next, then **check the box "Open the Properties dialog when I click Finish"**, then Finish.
10. In the Properties dialog that opens, go to the **Triggers** tab, click your trigger, click **Edit**.
11. Check **Repeat task every** and set it to `15 minutes` for a duration of `1 day`.
12. Click OK twice to save.

To confirm it's working, after 15 minutes look for new lines in `reports\cm-tracker.jsonl` (each line is one snapshot).

### Confirming the cron is running (both platforms)

After 15–30 minutes:

1. Open `reports/cm-tracker.jsonl` in your code editor.
2. Each line in the file is a snapshot. After two scheduled runs, you should see at least 2 lines.
3. Open `reports/cm-tracker.html` in your browser. You should see the latest snapshot at the top, plus a "Pacing" table showing all snapshots from today.

The dashboard auto-refreshes every 10 minutes when you have it open in a browser tab.

---

## 10. Use the skills inside Claude Code

Now the fun part. Three skills are included; you "load" them into Claude Code by copying them into a special folder, and then you can ask Claude Code questions in plain English.

### 10.1. Find Claude Code's skills folder

Claude Code looks for skills in a `.claude/skills/` folder inside whatever project you open it in. The simplest setup: open Claude Code with the `contribution-margin-system` folder as the project, and the skills will load automatically.

1. Open Terminal (Mac) or Command Prompt (Windows).
2. Navigate to the project folder:
   - Mac: `cd ~/Desktop/contribution-margin-system`
   - Windows: `cd %USERPROFILE%\Desktop\contribution-margin-system`
3. Create the `.claude/skills/` directory and copy the three skills into it:
   - **Mac:**
     ```
     mkdir -p .claude/skills
     cp -r skills/cm-tracker .claude/skills/
     cp -r skills/cm-trends .claude/skills/
     cp -r skills/hourly-analysis .claude/skills/
     ```
   - **Windows:**
     ```
     mkdir .claude\skills
     xcopy /E /I skills\cm-tracker .claude\skills\cm-tracker
     xcopy /E /I skills\cm-trends .claude\skills\cm-trends
     xcopy /E /I skills\hourly-analysis .claude\skills\hourly-analysis
     ```
4. Start Claude Code in this folder:
   ```
   claude
   ```
5. Once you see the `❯` prompt, the skills are loaded.

### 10.2. Ask questions

Try these one at a time:

**Single-period CM (uses `cm-tracker` skill):**
- "How much did we make yesterday?"
- "What's our contribution margin so far today?"
- "Pull yesterday's P&L and show me the waterfall."
- "Which ads spent over $50 yesterday and what was their CPA?"

**Multi-period comparison (uses `cm-trends` skill):**
- "Compare this week to last week."
- "Was March better than February?"
- "Show me daily CM for the last 14 days."
- "Is today's CM normal variance or actually bad?"

**Hourly profitability (uses `hourly-analysis` skill — needs at least 7 days of cron data):**
- "What hours of the day are we losing money?"
- "Pull our CVR by hour for the last 90 days."
- "Cross-reference CVR by hour with CM by hour. Where do they disagree?"

Claude Code will pick the right skill based on what you ask. If it picks the wrong one or seems confused, be more specific (e.g. "use the cm-trends skill to compare...").

### 10.3. Where the data comes from

- **For single-period and trend questions**, Claude Code hits Shopify and Meta APIs live using your `.env` credentials.
- **For hourly questions**, Claude Code reads `reports/cm-tracker.jsonl` (the cron log) plus pulls 90-day CVR from Shopify.

You don't have to do anything different — the skills handle which source to use.

---

## 11. If something goes wrong

### "command not found: python3" / "'python' is not recognized"

Python isn't installed, or it isn't on your PATH. Go back to [section 2.1](#21-install-python) and reinstall, making sure to **check the "Add to PATH" box on Windows**.

### "ModuleNotFoundError: No module named 'requests'"

You skipped section 2.2. Run:
- Mac: `pip3 install requests python-dotenv`
- Windows: `pip install requests python-dotenv`

### "ERROR: missing required env vars"

Your `.env` file is missing values, or the file is named wrong (e.g. `.env.txt` instead of `.env`). Check:
1. The file is in the project root, not in `references/` or `scripts/`.
2. The file is named exactly `.env` with the dot, no `.txt` at the end.
3. None of the lines have empty values after the `=` sign.

### "ERROR: unit economics file not found"

You skipped section 7. Copy `references/unit-economics.template.json` to `references/unit-economics.json` and fill it in.

### Shopify returns 401 / "Invalid API key or access token"

Your token is wrong, expired, or doesn't have the right scopes. Go back to section 4, recreate the custom app, and make sure you copy the new token into `.env`.

### Meta returns "Invalid OAuth access token" or 190

Your Meta token expired (the short-lived one only lasts about an hour). Get a new one from Graph API Explorer (section 5.1), or extend it to 60 days (section 5.3).

### Meta returns "Insufficient permissions"

The token doesn't have `ads_read`. Regenerate it in Graph API Explorer with that permission added.

### Numbers in the dashboard look wrong

Almost always your `unit-economics.json` is off. Re-check `processing_rate` and `returns_rate` against your real statements first — those are the most common errors. Then check shipping tiers.

### Cron isn't running on Mac

See the "macOS may block cron" tip in section 9. Most often, granting cron Full Disk Access fixes it. Easier alternative: move the folder out of `~/Desktop` to `~/cm-tracker`.

### The `.jsonl` file is filling up — is that OK?

Yes. Each line is small (a few KB). After a year of runs every 15 minutes, the file will be roughly 100MB. If you ever want to compress old data, just rename the file (`mv cm-tracker.jsonl cm-tracker-2026.jsonl`) and the cron will start a fresh one.

### I'm stuck on something not in this list

Open Claude Code in the project folder and describe what's wrong. Claude can read your `.env`, look at error messages, and walk you through fixes interactively.

---

## 12. What this bundle does NOT include

To set expectations clearly:

- **No bid throttling / cost cap automation.** The YouTube video ended with a script that automatically tightened bids at 6pm and loosened them at 8am. That script is intentionally not in this bundle — it's the most account-specific piece (depends on your campaign structure, your Meta optimization goal type, your tolerance for scheduled changes). The discovery layer (`hourly-analysis`) is the high-leverage part. Once you know which hours leak money, building the throttle is straightforward.
- **No Telegram, Slack, or email notifications.** The cron writes a JSONL log and refreshes the HTML dashboard. If you want push notifications, the JSONL log is easy to hook into.
- **No automatic SKU updates.** When you add new products, you'll need to update `unit-economics.json` by hand. Worth automating once you outgrow this — but at the size where that matters, you have a data team.

---

## Credit

This system was built and refined by [The Prompted](https://www.youtube.com/@theprompted) on a real DTC store. The methodology — real CM not revenue-minus-spend, JSONL append-only design, CVR-vs-CM triangulation, throttle-not-pause — is hard-won from running real ad accounts.

If this is useful, the original videos on YouTube walk through how it was built and what we learned along the way.
