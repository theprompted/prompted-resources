#!/usr/bin/env python3
"""
CM Tracker Cron — captures real contribution margin from Shopify + Meta Ads
every 15 minutes, writes to JSONL, and updates an HTML dashboard.

Configure via .env (see .env.example).
Unit economics live in references/unit-economics.json (see template).

Run manually:
    python3 cm-tracker-cron.py

Or schedule via cron (every 15 min):
    */15 * * * * /usr/bin/python3 /path/to/cm-tracker-cron.py >> /path/to/cron.log 2>&1
"""

import json
import os
import socket
import sys
import tempfile
import time
import traceback
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import requests
from dotenv import load_dotenv

# Force network timeouts to prevent cron hangs
socket.setdefaulttimeout(30)

# ---------------------------------------------------------------------------
# Configuration (loaded from .env)
# ---------------------------------------------------------------------------

# Where this script lives — used as the project root by default.
PROJECT_ROOT = Path(os.environ.get("CM_PROJECT_ROOT", Path(__file__).resolve().parent.parent))

ENV_FILE = PROJECT_ROOT / ".env"
load_dotenv(ENV_FILE)

UNIT_ECON_FILE = PROJECT_ROOT / "references" / "unit-economics.json"
REPORTS_DIR = PROJECT_ROOT / "reports"
HTML_OUTPUT = REPORTS_DIR / "cm-tracker.html"
JSONL_OUTPUT = REPORTS_DIR / "cm-tracker.jsonl"

# Brand / display
BRAND_NAME = os.environ.get("BRAND_NAME", "My Store")

# Shopify
SHOPIFY_STORE = os.environ.get("SHOPIFY_STORE", "")
SHOPIFY_ACCESS_TOKEN = os.environ.get("SHOPIFY_ACCESS_TOKEN", "")

# Meta
META_TOKEN = os.environ.get("META_ACCESS_TOKEN", "")
META_AD_ACCOUNT = os.environ.get("META_AD_ACCOUNT_ID", "")
META_API_VERSION = os.environ.get("META_API_VERSION", "v21.0")
META_BASE = f"https://graph.facebook.com/{META_API_VERSION}"

# Currency
STORE_CURRENCY = os.environ.get("STORE_CURRENCY", "USD")
AD_SPEND_CURRENCY = os.environ.get("AD_SPEND_CURRENCY", "USD")
FX_RATE_OVERRIDE = os.environ.get("FX_RATE_OVERRIDE")  # e.g. "0.73"

# Timezone for the store / dashboard
STORE_TZ = ZoneInfo(os.environ.get("STORE_TIMEZONE", "America/New_York"))

# Ad-level filter threshold (in store currency)
AD_SPEND_THRESHOLD = float(os.environ.get("AD_SPEND_THRESHOLD", "50"))

# Validation
REQUIRED = {
    "SHOPIFY_STORE": SHOPIFY_STORE,
    "SHOPIFY_ACCESS_TOKEN": SHOPIFY_ACCESS_TOKEN,
    "META_ACCESS_TOKEN": META_TOKEN,
    "META_AD_ACCOUNT_ID": META_AD_ACCOUNT,
}
missing = [k for k, v in REQUIRED.items() if not v]
if missing:
    print(f"ERROR: missing required env vars: {', '.join(missing)}", file=sys.stderr)
    sys.exit(1)

# ---------------------------------------------------------------------------
# Unit economics — loaded from JSON, see references/unit-economics.template.md
# ---------------------------------------------------------------------------

def load_unit_economics() -> dict:
    if not UNIT_ECON_FILE.exists():
        print(
            f"ERROR: unit economics file not found at {UNIT_ECON_FILE}.\n"
            f"Copy references/unit-economics.template.json to {UNIT_ECON_FILE} "
            f"and fill in your store's COGS, weights, shipping tiers, and rates.",
            file=sys.stderr,
        )
        sys.exit(1)
    with open(UNIT_ECON_FILE) as f:
        return json.load(f)


UNIT_ECON = load_unit_economics()
PRODUCT_COGS = UNIT_ECON["product_cogs"]
PRODUCT_WEIGHTS = UNIT_ECON["product_weights"]
SHIPPING_TIERS = UNIT_ECON["shipping_tiers"]  # list of [max_oz, rate]
PROCESSING_RATE = UNIT_ECON.get("processing_rate", 0.041)
RETURNS_RATE = UNIT_ECON.get("returns_rate", 0.02)
PRODUCT_DETECTION = UNIT_ECON.get("product_detection_rules", [])
SIZE_DETECTION = UNIT_ECON.get("size_detection_rules", [])
DEFAULT_PRODUCT = UNIT_ECON.get("default_product_type", "default")
DEFAULT_SIZE = UNIT_ECON.get("default_size", "default")

# ---------------------------------------------------------------------------
# Currency
# ---------------------------------------------------------------------------

def get_fx_rate() -> float:
    """Returns the rate to convert ad spend currency to store currency."""
    if STORE_CURRENCY == AD_SPEND_CURRENCY:
        return 1.0
    if FX_RATE_OVERRIDE:
        return float(FX_RATE_OVERRIDE)
    # Live FX lookup — using exchangerate.host (free, no auth)
    try:
        r = requests.get(
            "https://api.exchangerate.host/latest",
            params={"base": AD_SPEND_CURRENCY, "symbols": STORE_CURRENCY},
            timeout=10,
        )
        r.raise_for_status()
        rate = r.json()["rates"][STORE_CURRENCY]
        return float(rate)
    except Exception as e:
        print(f"FX lookup failed ({e}), defaulting to 1.0", file=sys.stderr)
        return 1.0

# ---------------------------------------------------------------------------
# Product / size detection
# ---------------------------------------------------------------------------

def detect_product_type(title: str) -> str:
    """Match the title against ordered detection rules from unit-economics.json."""
    t = title.lower()
    for rule in PRODUCT_DETECTION:
        # rule = {"contains_all": ["v-neck"], "contains_any": ["neon"], "type": "vneck_neon"}
        contains_all = [s.lower() for s in rule.get("contains_all", [])]
        contains_any = [s.lower() for s in rule.get("contains_any", [])]
        if contains_all and not all(s in t for s in contains_all):
            continue
        if contains_any and not any(s in t for s in contains_any):
            continue
        return rule["type"]
    return DEFAULT_PRODUCT


def detect_size(variant: str) -> str:
    if not variant:
        return DEFAULT_SIZE
    v = variant.upper()
    for rule in SIZE_DETECTION:
        # rule = {"contains_any": ["3XL", "XXXL"], "size": "3xl"}
        contains_any = [s.upper() for s in rule.get("contains_any", [])]
        if contains_any and any(s in v for s in contains_any):
            return rule["size"]
    return DEFAULT_SIZE


def get_cogs(product_type: str, size: str) -> float:
    table = PRODUCT_COGS.get(product_type, PRODUCT_COGS.get(DEFAULT_PRODUCT, {}))
    if "default" in table:
        return float(table["default"])
    return float(table.get(size, table.get(DEFAULT_SIZE, 0)))


def get_weight(product_type: str, size: str) -> float:
    table = PRODUCT_WEIGHTS.get(product_type, PRODUCT_WEIGHTS.get(DEFAULT_PRODUCT, {}))
    if "default" in table:
        return float(table["default"])
    return float(table.get(size, table.get(DEFAULT_SIZE, 0)))


def lookup_shipping(total_oz: float) -> float:
    if total_oz <= 0:
        return 0.0
    for max_oz, rate in SHIPPING_TIERS:
        if total_oz <= max_oz:
            return float(rate)
    # Above largest tier — use largest rate
    return float(SHIPPING_TIERS[-1][1])

# ---------------------------------------------------------------------------
# Shopify
# ---------------------------------------------------------------------------

def fetch_shopify_orders(date_str: str) -> list:
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=STORE_TZ)
    next_day = dt + timedelta(days=1)
    fmt = "%Y-%m-%dT%H:%M:%S%z"
    start = dt.replace(hour=0, minute=0, second=0).strftime(fmt)
    end = next_day.replace(hour=0, minute=0, second=0).strftime(fmt)
    # Insert colon in tz offset: -0400 → -04:00
    start = start[:-2] + ":" + start[-2:]
    end = end[:-2] + ":" + end[-2:]

    all_orders = []
    url = f"https://{SHOPIFY_STORE}/admin/api/2024-10/orders.json"
    params = {
        "created_at_min": start,
        "created_at_max": end,
        "status": "any",
        "limit": 250,
    }
    headers = {"X-Shopify-Access-Token": SHOPIFY_ACCESS_TOKEN}

    while url:
        resp = requests.get(url, params=params, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        for o in data.get("orders", []):
            if o.get("cancelled_at") is None and o.get("financial_status") == "paid":
                all_orders.append(o)
        link = resp.headers.get("Link", "")
        url = None
        params = None  # only needed on first request
        if 'rel="next"' in link:
            for part in link.split(","):
                if 'rel="next"' in part:
                    url = part.split("<")[1].split(">")[0]
                    break
    return all_orders

# ---------------------------------------------------------------------------
# Meta
# ---------------------------------------------------------------------------

def _meta_get(endpoint: str, params: dict, retries: int = 1) -> dict:
    params["access_token"] = META_TOKEN
    for attempt in range(retries + 1):
        resp = requests.get(f"{META_BASE}/{endpoint}", params=params, timeout=30)
        if resp.status_code == 500 and attempt < retries:
            time.sleep(2)
            continue
        resp.raise_for_status()
        return resp.json()
    return {}


def fetch_meta_account_insights(date_str: str) -> dict:
    data = _meta_get(f"{META_AD_ACCOUNT}/insights", {
        "fields": "spend,impressions,clicks,actions,action_values",
        "time_range": json.dumps({"since": date_str, "until": date_str}),
    })
    return data.get("data", [{}])[0] if data.get("data") else {}


def fetch_meta_campaign_data(date_str: str) -> list:
    budgets_resp = _meta_get(f"{META_AD_ACCOUNT}/campaigns", {
        "fields": "name,daily_budget,lifetime_budget,status",
        "filtering": json.dumps([{
            "field": "effective_status", "operator": "IN", "value": ["ACTIVE"]
        }]),
        "limit": 50,
    })
    budget_map = {}
    for c in budgets_resp.get("data", []):
        budget_map[c["id"]] = {
            "name": c["name"],
            "daily_budget": int(c.get("daily_budget", 0)) / 100,
            "lifetime": c.get("lifetime_budget") is not None,
        }

    insights_resp = _meta_get(f"{META_AD_ACCOUNT}/insights", {
        "fields": "campaign_name,campaign_id,spend,actions,action_values",
        "time_range": json.dumps({"since": date_str, "until": date_str}),
        "level": "campaign",
        "limit": 50,
    })

    fx = get_fx_rate()
    campaigns = []
    for row in insights_resp.get("data", []):
        cid = row.get("campaign_id", "")
        spend_local = float(row.get("spend", 0))
        purchases = 0
        purchase_value = 0.0
        for a in row.get("actions", []):
            if a.get("action_type") == "purchase":
                purchases = int(a["value"])
        for a in row.get("action_values", []):
            if a.get("action_type") == "purchase":
                purchase_value = float(a["value"])

        info = budget_map.get(cid, {})
        daily_budget = info.get("daily_budget", 0)
        utilization = (spend_local / daily_budget * 100) if daily_budget > 0 else 0

        campaigns.append({
            "name": row.get("campaign_name", "Unknown"),
            "campaign_id": cid,
            "spend_local": spend_local,
            "spend_in_store_currency": spend_local * fx,
            "purchases": purchases,
            "purchase_value": purchase_value,
            "daily_budget": daily_budget,
            "utilization_pct": utilization,
            "is_budget_limited": utilization >= 90,
            "is_lifetime": info.get("lifetime", False),
        })

    campaigns.sort(key=lambda c: c["spend_local"], reverse=True)
    return campaigns


def fetch_meta_ad_insights(date_str: str) -> list:
    """Fetch every ad with spend > 0 for the given date. Paginated."""
    fx = get_fx_rate()
    ads = []
    params = {
        "fields": "ad_id,ad_name,adset_name,campaign_name,spend,impressions,clicks,outbound_clicks,actions,action_values",
        "time_range": json.dumps({"since": date_str, "until": date_str}),
        "level": "ad",
        "limit": 100,
        "filtering": json.dumps([{"field": "spend", "operator": "GREATER_THAN", "value": "0"}]),
    }
    endpoint = f"{META_AD_ACCOUNT}/insights"
    data = _meta_get(endpoint, params)

    def _process(rows):
        for row in rows:
            spend_local = float(row.get("spend", 0))
            impressions = int(row.get("impressions", 0))
            clicks = int(row.get("clicks", 0))
            outbound = 0
            for oc in row.get("outbound_clicks", []):
                if oc.get("action_type") == "outbound_click":
                    outbound = int(oc["value"])
            purchases = 0
            purchase_value = 0.0
            for a in row.get("actions", []):
                if a.get("action_type") == "purchase":
                    purchases = int(a["value"])
            for a in row.get("action_values", []):
                if a.get("action_type") == "purchase":
                    purchase_value = float(a["value"])

            cpm = (spend_local / impressions * 1000) if impressions > 0 else 0
            cpc = (spend_local / clicks) if clicks > 0 else 0
            cpa = (spend_local / purchases) if purchases > 0 else 0
            roas = (purchase_value / (spend_local * fx)) if spend_local > 0 else 0

            ads.append({
                "ad_id": row.get("ad_id", ""),
                "ad_name": row.get("ad_name", ""),
                "adset_name": row.get("adset_name", ""),
                "campaign_name": row.get("campaign_name", ""),
                "spend_local": round(spend_local, 2),
                "impressions": impressions,
                "clicks": clicks,
                "outbound_clicks": outbound,
                "cpm_local": round(cpm, 2),
                "cpc_local": round(cpc, 2),
                "purchases": purchases,
                "purchase_value": round(purchase_value, 2),
                "cpa_local": round(cpa, 2),
                "roas": round(roas, 2),
            })

    _process(data.get("data", []))

    next_url = data.get("paging", {}).get("next")
    while next_url:
        resp = requests.get(next_url, timeout=30)
        resp.raise_for_status()
        page = resp.json()
        _process(page.get("data", []))
        next_url = page.get("paging", {}).get("next")

    ads.sort(key=lambda a: a["spend_local"], reverse=True)
    return ads

# ---------------------------------------------------------------------------
# CM calculation
# ---------------------------------------------------------------------------

def calculate_order_economics(order: dict) -> dict:
    revenue = float(order.get("total_price", 0))
    total_discounts = float(order.get("total_discounts", 0))
    tips = 0.0
    total_cogs = 0.0
    total_weight = 0.0
    units = 0
    products = Counter()

    for item in order.get("line_items", []):
        title = item.get("title", "")
        if "tip" in title.lower():
            tips += float(item.get("price", 0)) * item.get("quantity", 1)
            continue
        qty = item.get("quantity", 1)
        ptype = detect_product_type(title)
        size = detect_size(item.get("variant_title", ""))
        unit_cogs = get_cogs(ptype, size)
        unit_weight = get_weight(ptype, size)
        total_cogs += unit_cogs * qty
        total_weight += unit_weight * qty
        units += qty
        pname = title.split(" - ")[0] if " - " in title else title
        products[pname] += qty

    shipping = lookup_shipping(total_weight) if total_weight > 0 else 0
    processing = revenue * PROCESSING_RATE
    returns_reserve = (revenue - tips) * RETURNS_RATE
    margin = revenue - total_cogs - shipping - processing - returns_reserve

    return {
        "revenue": revenue,
        "cogs": total_cogs,
        "shipping": shipping,
        "processing": processing,
        "returns": returns_reserve,
        "margin": margin,
        "tips": tips,
        "discounts": total_discounts,
        "units": units,
        "products": dict(products),
    }


def calculate_daily_cm(orders: list, meta: dict, campaigns: list) -> dict:
    fx = get_fx_rate()
    total = {
        "revenue": 0, "cogs": 0, "shipping": 0, "processing": 0, "returns": 0,
        "margin_before_ads": 0, "tips": 0, "discounts": 0,
        "order_count": len(orders), "total_units": 0,
    }
    all_products = Counter()
    upo = []
    for o in orders:
        e = calculate_order_economics(o)
        total["revenue"] += e["revenue"]
        total["cogs"] += e["cogs"]
        total["shipping"] += e["shipping"]
        total["processing"] += e["processing"]
        total["returns"] += e["returns"]
        total["margin_before_ads"] += e["margin"]
        total["tips"] += e["tips"]
        total["discounts"] += e["discounts"]
        total["total_units"] += e["units"]
        upo.append(e["units"])
        for p, q in e["products"].items():
            all_products[p] += q

    upo_dist = Counter(upo)
    spend_local = float(meta.get("spend", 0))
    spend_store = spend_local * fx
    meta_purchases = 0
    meta_pv = 0.0
    for a in meta.get("actions", []):
        if a.get("action_type") == "purchase":
            meta_purchases = int(a["value"])
    for a in meta.get("action_values", []):
        if a.get("action_type") == "purchase":
            meta_pv = float(a["value"])

    cm = total["margin_before_ads"] - spend_store
    n = total["order_count"]
    rev = total["revenue"]

    total.update({
        "spend_local": spend_local,
        "spend_in_store_currency": spend_store,
        "fx_rate": fx,
        "cm": cm,
        "meta_purchases": meta_purchases,
        "meta_purchase_value": meta_pv,
        "roas": (rev / spend_store) if spend_store > 0 else 0,
        "aov": (rev / n) if n > 0 else 0,
        "margin_before_ads_pct": (total["margin_before_ads"] / rev * 100) if rev > 0 else 0,
        "cm_pct": (cm / rev * 100) if rev > 0 else 0,
        "units_per_order_avg": (total["total_units"] / n) if n > 0 else 0,
        "units_per_order_dist": dict(upo_dist),
        "products": dict(all_products.most_common()),
        "campaigns": campaigns,
    })
    return total

# ---------------------------------------------------------------------------
# HTML dashboard (PromptedOS-flavored, brand name configurable)
# ---------------------------------------------------------------------------

DASHBOARD_CSS = """
:root {
    --bg-page: #F8F8F7; --bg-white: #ffffff;
    --bg-blue: #EBF9FF; --bg-purple: #F7F1FF;
    --bg-yellow: #FFFDE7; --bg-green: #E8F5E9;
    --accent-teal: #53DBC9; --accent-yellow: #FFDE00;
    --accent-purple: #9D4EDD; --accent-red: #E53935;
    --text-black: #000000; --text-dark: #1a1a1a;
    --text-gray: #4a4a4a; --text-muted: #6b6b6b;
    --shadow-lg: -0.31rem 0.31rem 0 0 #383838;
    --shadow-sm: -0.19rem 0.19rem 0 0 #383838;
    --border: 2px solid black;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 1rem; line-height: 1.7; color: var(--text-dark);
    background: var(--bg-page); padding: 2rem 1.5rem; max-width: 900px; margin: 0 auto;
}
h1, h2, h3 { font-family: 'SF Mono', 'Fira Code', 'Consolas', monospace; }
.card {
    background: var(--bg-white); border: var(--border); box-shadow: var(--shadow-lg);
    border-radius: 0; padding: 1.5rem; margin-bottom: 1.5rem;
}
.kpi-row { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1.5rem; }
.kpi {
    flex: 1; min-width: 140px; background: var(--bg-white); border: var(--border);
    box-shadow: var(--shadow-sm); padding: 1rem; text-align: center;
}
.kpi .label { font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted);
    font-family: 'SF Mono', monospace; letter-spacing: 0.05em; }
.kpi .value { font-size: 1.5rem; font-weight: 700; margin-top: 0.25rem; }
.kpi .positive { color: #2e7d32; }
.kpi .negative { color: var(--accent-red); }
table { width: 100%; border-collapse: collapse; }
th { font-family: 'SF Mono', monospace; font-size: 0.75rem; text-transform: uppercase;
    letter-spacing: 0.05em; color: var(--text-muted); text-align: left;
    padding: 0.5rem 0.75rem; border-bottom: var(--border); }
td { padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; }
td.num { text-align: right; font-variant-numeric: tabular-nums; }
tr.warn { background: var(--bg-yellow); }
.updated { font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem; }
.header-accent { display: inline-block; background: var(--accent-teal); padding: 0.1rem 0.6rem;
    border: var(--border); box-shadow: var(--shadow-sm); margin-right: 0.5rem; }
.day-divider { border-top: 3px solid var(--accent-teal); margin: 2rem 0 1rem 0; padding-top: 1rem; }
.pacing-table th, .pacing-table td { font-size: 0.8rem; }
.pacing-table th.cum, .pacing-table td.cum {
    background: #FAFAFA;
    border-left: 1px dashed #ccc;
}
.pacing-table td.cum { color: var(--text-muted); }
@media (max-width: 500px) {
    body { padding: 1rem 0.75rem; }
    .kpi-row { flex-direction: column; }
    .kpi .value { font-size: 1.2rem; }
    td, th { padding: 0.4rem 0.5rem; font-size: 0.85rem; }
    .pacing-table { font-size: 0.7rem; }
}
"""


def _render_pacing_rows(snapshots: list) -> str:
    """Render pacing rows showing cumulative state at each hourly snapshot.

    Snapshots are passed newest-first. We render oldest-first so the day
    reads naturally top-to-bottom (morning → evening). Each row is the
    running day-to-date totals as of that timestamp.
    """
    if not snapshots:
        return ""
    chrono = sorted(snapshots, key=lambda s: s.get("ts", ""))
    rows = []
    for s in chrono:
        cm_class = "positive" if s["cm"] >= 0 else "negative"
        rows.append(
            f"<tr>"
            f"<td><b>{s.get('time','')}</b></td>"
            f"<td class='num'>${s['revenue']:,.2f}</td>"
            f"<td class='num'>{s['order_count']}</td>"
            f"<td class='num'>${s['spend_in_store_currency']:,.2f}</td>"
            f"<td class='num'><span class='{cm_class}'>${s['cm']:,.2f}</span></td>"
            f"<td class='num'>{s['roas']:.2f}x</td>"
            f"</tr>"
        )
    return "".join(rows)


def _render_snapshot_detail(snap: dict, is_latest: bool) -> str:
    cm_class = "positive" if snap["cm"] >= 0 else "negative"
    open_attr = " open" if is_latest else ""
    mba_pct = snap.get("margin_before_ads_pct", 0)
    html = f"""
    <details class="snapshot-detail"{open_attr}>
    <summary style="cursor:pointer;font-family:'SF Mono',monospace;font-weight:700;padding:0.5rem 0;">
    {snap.get('time','')} — Rev ${snap['revenue']:,.2f} | CM ${snap['cm']:,.2f} | {snap['order_count']} orders
    </summary>
    <div class="card" style="margin-top:0.5rem;">
        <h3>Contribution Margin Waterfall</h3>
        <table>
            <tr><td>Cash Collected</td><td class="num"><b>${snap['revenue']:,.2f}</b></td></tr>
            <tr><td>COGS</td><td class="num">(${snap['cogs']:,.2f})</td></tr>
            <tr><td>Shipping</td><td class="num">(${snap['shipping']:,.2f})</td></tr>
            <tr><td>Processing ({PROCESSING_RATE*100:.1f}%)</td><td class="num">(${snap['processing']:,.2f})</td></tr>
            <tr><td>Returns Reserve ({RETURNS_RATE*100:.1f}%)</td><td class="num">(${snap['returns']:,.2f})</td></tr>
            <tr style="border-top:var(--border);"><td><b>Margin Before Ads</b></td><td class="num"><b>${snap['margin_before_ads']:,.2f} ({mba_pct:.1f}%)</b></td></tr>
            <tr><td>Ad Spend</td><td class="num">(${snap['spend_in_store_currency']:,.2f}) {STORE_CURRENCY} / {snap['spend_local']:,.2f} {AD_SPEND_CURRENCY}</td></tr>
            <tr style="border-top:var(--border);"><td><b>Contribution Margin</b></td><td class="num"><b class="{cm_class}">${snap['cm']:,.2f} ({snap['cm_pct']:.1f}%)</b></td></tr>
        </table>
        <p style="margin-top:0.75rem;font-size:0.85rem;color:var(--text-muted);">
            AOV: ${snap['aov']:,.2f} | Units/Order: {snap['units_per_order_avg']:.1f} | Discounts: ${snap['discounts']:,.2f}
        </p>
    </div>
    """

    dist = snap.get("units_per_order_dist", {})
    n = snap["order_count"]
    if dist and n > 0:
        html += '<div class="card"><h3>Units Per Order</h3><table>'
        html += "<tr><th>Units</th><th>Orders</th><th>%</th></tr>"
        for u in sorted(int(k) for k in dist.keys()):
            cnt = dist.get(str(u), dist.get(u, 0))
            html += f"<tr><td>{u}</td><td class='num'>{cnt}</td><td class='num'>{cnt/n*100:.0f}%</td></tr>"
        html += "</table></div>"

    products = snap.get("products", {})
    if products:
        html += '<div class="card"><h3>Products by Units</h3><table>'
        html += "<tr><th>Units</th><th>Product</th></tr>"
        sorted_p = sorted(products.items(), key=lambda x: -x[1])
        shown = 0
        other_units = 0
        other_count = 0
        for pname, qty in sorted_p:
            if qty <= 2 and shown >= 8:
                other_units += qty
                other_count += 1
            else:
                html += f"<tr><td class='num'>{qty}</td><td>{pname}</td></tr>"
                shown += 1
        if other_count:
            html += f"<tr><td class='num'>{other_units}</td><td><i>{other_count} other products</i></td></tr>"
        html += "</table></div>"

    campaigns = snap.get("campaigns", [])
    if campaigns:
        html += '<div class="card"><h3>Campaigns</h3><table>'
        html += "<tr><th>Campaign</th><th>Spend</th><th>Purch</th><th>CPA</th><th>Budget</th><th>Util</th></tr>"
        for c in campaigns:
            if c["spend_local"] < 1:
                continue
            cpa = f"${c['spend_local']/c['purchases']:,.0f}" if c["purchases"] > 0 else "—"
            budget_str = f"${c['daily_budget']:,.0f}" if c["daily_budget"] > 0 else "lifetime"
            util_str = f"{c['utilization_pct']:.0f}%" if c["daily_budget"] > 0 else "—"
            row_class = " class='warn'" if c["is_budget_limited"] or (c["purchases"] == 0 and c["spend_local"] > 20) else ""
            html += (
                f"<tr{row_class}><td>{c['name'][:40]}</td>"
                f"<td class='num'>${c['spend_local']:,.2f}</td>"
                f"<td class='num'>{c['purchases']}</td>"
                f"<td class='num'>{cpa}</td>"
                f"<td class='num'>{budget_str}</td>"
                f"<td class='num'>{util_str}</td></tr>"
            )
        html += "</table></div>"

    html += "</details>"
    return html


def _render_day_html(day: dict) -> str:
    snapshots = day.get("snapshots", [])
    if not snapshots:
        return ""
    latest = snapshots[0]
    cm_class = "positive" if latest["cm"] >= 0 else "negative"
    html = f"""
    <div class="day-section" data-date="{day['date']}">
    <h2><span class="header-accent">$</span>{day['date']}</h2>
    <p class="updated">{len(snapshots)} snapshot{'s' if len(snapshots)!=1 else ''} — latest: {latest.get('time','')}</p>
    <div class="kpi-row">
        <div class="kpi"><div class="label">Revenue</div><div class="value">${latest['revenue']:,.2f}</div></div>
        <div class="kpi"><div class="label">CM</div><div class="value {cm_class}">${latest['cm']:,.2f}</div></div>
        <div class="kpi"><div class="label">ROAS</div><div class="value">{latest['roas']:.2f}x</div></div>
        <div class="kpi"><div class="label">Orders</div><div class="value">{latest['order_count']}</div></div>
    </div>
    """
    if len(snapshots) > 1:
        html += '<div class="card"><h3>Pacing — hour by hour</h3>'
        html += '<p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:0.75rem;">Cumulative day-to-date at each hourly snapshot.</p>'
        html += '<table class="pacing-table">'
        html += "<tr><th>Time</th><th>Revenue</th><th>Orders</th><th>Spend</th><th>CM</th><th>ROAS</th></tr>"
        html += _render_pacing_rows(snapshots)
        html += "</table></div>"
    for i, s in enumerate(snapshots):
        html += _render_snapshot_detail(s, is_latest=(i == 0))
    html += "</div>"
    return html


def generate_html(days: list, refresh_seconds: int = 600) -> str:
    days_html = ""
    for i, day in enumerate(days):
        if i > 0:
            days_html += '<div class="day-divider"></div>'
        days_html += _render_day_html(day)
    historical_json = json.dumps(days, default=str)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="refresh" content="{refresh_seconds}">
<title>{BRAND_NAME} — Contribution Margin</title>
<style>{DASHBOARD_CSS}
.snapshot-detail {{ margin-bottom: 1rem; }}
.snapshot-detail summary:hover {{ color: var(--accent-purple); }}
</style>
</head>
<body>
<h1><span class="header-accent">{BRAND_NAME}</span>Contribution Margin Tracker</h1>
<p class="updated">Auto-refreshes every {refresh_seconds//60} min — all snapshots preserved</p>
{days_html}
<script type="application/json" id="historical-data">{historical_json}</script>
</body>
</html>"""


def update_html_file(snapshot: dict, now: datetime):
    date_str = now.strftime("%Y-%m-%d")
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    days = []
    if HTML_OUTPUT.exists():
        try:
            content = HTML_OUTPUT.read_text()
            marker = 'id="historical-data">'
            idx = content.find(marker)
            if idx >= 0:
                start = idx + len(marker)
                end = content.find("</script>", start)
                if end > start:
                    days = json.loads(content[start:end])
        except Exception:
            pass

    today_group = next((d for d in days if d.get("date") == date_str), None)
    if today_group is None:
        today_group = {"date": date_str, "snapshots": []}
        days.insert(0, today_group)

    today_group["snapshots"].insert(0, snapshot)
    days = [d for d in days if d.get("date") == date_str] + \
           [d for d in days if d.get("date") != date_str]

    html = generate_html(days)
    tmp = tempfile.NamedTemporaryFile(mode="w", dir=REPORTS_DIR, suffix=".html", delete=False)
    try:
        tmp.write(html)
        tmp.close()
        os.replace(tmp.name, HTML_OUTPUT)
    except Exception:
        os.unlink(tmp.name)
        raise

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    now = datetime.now(STORE_TZ)
    date_str = now.strftime("%Y-%m-%d")
    errors = []

    print(f"[{now.isoformat()}] Starting CM run...", flush=True)

    orders = []
    try:
        print("  Fetching Shopify orders...", flush=True)
        orders = fetch_shopify_orders(date_str)
        print(f"  Got {len(orders)} orders.", flush=True)
    except Exception as e:
        errors.append(f"Shopify: {e}")
        traceback.print_exc(file=sys.stderr)

    meta = {}
    campaigns = []
    ad_insights = []
    try:
        meta = fetch_meta_account_insights(date_str)
    except Exception as e:
        errors.append(f"Meta insights: {e}")
        print(f"Meta insights error: {e}", file=sys.stderr)
    try:
        campaigns = fetch_meta_campaign_data(date_str)
    except Exception as e:
        errors.append(f"Meta campaigns: {e}")
        print(f"Meta campaigns error: {e}", file=sys.stderr)
    try:
        ad_insights = fetch_meta_ad_insights(date_str)
    except Exception as e:
        errors.append(f"Meta ad insights: {e}")
        print(f"Meta ad insights error: {e}", file=sys.stderr)

    pnl = calculate_daily_cm(orders, meta, campaigns)

    snapshot = {
        "ts": now.isoformat(),
        "date": date_str,
        "time": now.strftime("%-I:%M %p"),
        "revenue": round(pnl["revenue"], 2),
        "cogs": round(pnl["cogs"], 2),
        "shipping": round(pnl["shipping"], 2),
        "processing": round(pnl["processing"], 2),
        "returns": round(pnl["returns"], 2),
        "margin_before_ads": round(pnl["margin_before_ads"], 2),
        "margin_before_ads_pct": round(pnl["margin_before_ads_pct"], 1),
        "spend_local": round(pnl["spend_local"], 2),
        "spend_in_store_currency": round(pnl["spend_in_store_currency"], 2),
        "fx_rate": round(pnl["fx_rate"], 4),
        "store_currency": STORE_CURRENCY,
        "ad_spend_currency": AD_SPEND_CURRENCY,
        "cm": round(pnl["cm"], 2),
        "cm_pct": round(pnl["cm_pct"], 1),
        "roas": round(pnl["roas"], 2),
        "order_count": pnl["order_count"],
        "aov": round(pnl["aov"], 2),
        "total_units": pnl["total_units"],
        "units_per_order_avg": round(pnl["units_per_order_avg"], 1),
        "units_per_order_dist": {str(k): v for k, v in pnl.get("units_per_order_dist", {}).items()},
        "products": pnl.get("products", {}),
        "campaigns": [{
            "name": c["name"],
            "spend_local": round(c["spend_local"], 2),
            "spend_in_store_currency": round(c["spend_in_store_currency"], 2),
            "purchases": c["purchases"],
            "daily_budget": c["daily_budget"],
            "utilization_pct": round(c["utilization_pct"], 1),
            "is_budget_limited": c["is_budget_limited"],
        } for c in campaigns if c["spend_local"] >= 1],
        "ads": ad_insights,
    }

    try:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        with open(JSONL_OUTPUT, "a") as f:
            f.write(json.dumps(snapshot) + "\n")
    except Exception as e:
        print(f"JSONL error: {e}", file=sys.stderr)

    try:
        update_html_file(snapshot, now)
    except Exception as e:
        print(f"HTML error: {e}", file=sys.stderr)

    if errors:
        print(f"[{now.isoformat()}] Done with errors: {errors}", flush=True)
    else:
        print(
            f"[{now.isoformat()}] Done. "
            f"Rev: ${pnl['revenue']:,.2f} | CM: ${pnl['cm']:,.2f} | "
            f"Orders: {pnl['order_count']}",
            flush=True,
        )


if __name__ == "__main__":
    main()
