# Unit Economics Reference (TEMPLATE)

> Fill this out with your store's actual numbers, then save as `unit-economics.md` (drop the `.template`). The cm-tracker skill and cron script both read from this file. Update quarterly or when costs change.

## Product COGS

List every product (or product family) you sell, with the per-unit cost to produce or source that product. If you have variants by size, list each size. If you print or finish in-house, include print cost.

### Example structure (replace with your products)

#### Product Family A
| Variant / Size | Blank Cost | Finishing | **Total COGS** | Weight |
|----------------|------------|-----------|---------------|--------|
| Small | $X.XX | $X.XX | **$X.XX** | X.X oz |
| Medium | $X.XX | $X.XX | **$X.XX** | X.X oz |
| Large | $X.XX | $X.XX | **$X.XX** | X.X oz |

#### Product Family B
| Variant / Size | Blank Cost | Finishing | **Total COGS** | Weight |
|----------------|------------|-----------|---------------|--------|
| Default | $X.XX | $X.XX | **$X.XX** | X.X oz |

### Bundles

If you sell bundles, document how to detect them and how to compute total COGS:

- `bundle_sku_pattern_1` → `N × Product Family A COGS`
- `bundle_sku_pattern_2` → `M × Product Family B COGS`
- Total weight = per-item weight × count

## Shipping Cost Lookup

Your **fulfillment cost** by total order weight. This is what *you* pay the carrier, not what the customer paid.

### Example: USPS Ground Advantage, Zone 6

| Weight Range | Rate |
|--------------|------|
| 0 – 4 oz | $X.XX |
| 4 – 8 oz | $X.XX |
| 8 – 12 oz | $X.XX |
| 12 – 16 oz | $X.XX |
| 16 – 32 oz | $X.XX |
| 32 – 48 oz | $X.XX |
| 48 – 64 oz | $X.XX |
| 64 – 80 oz | $X.XX |

Pull these from your actual shipping bills or carrier rate sheet. **Don't guess** — small per-order errors compound across thousands of orders.

### Per-item weights

Document weight by product / size so the cron script can sum total order weight:

- Product Family A, Small: X.X oz
- Product Family A, Medium: X.X oz
- Product Family A, Large: X.X oz
- Product Family B, default: X.X oz

**Default fallback** when size is unknown: use the most common size (e.g. medium / S-XL).

## Customer-Facing Shipping (informational)

Document what your customer is charged so you can explain how the math reconciles:

- Under $X order subtotal: customer pays $X.XX
- $X+ subtotal: free shipping (you absorb full cost)
- Member tier: free shipping at $X subtotal

The customer's shipping charge is already inside `total_price` in Shopify. Your fulfillment cost is its own line in the waterfall. Both belong.

## Payment Processing

Effective rate including any flat per-transaction fees:

- **Default rate:** ~`X.X%` of total collected (revenue + shipping + tips)

Common processor rates:
- Shopify Payments: ~2.9% + $0.30 per transaction
- Higher-risk processors: 3.5%+
- Blended (with chargebacks, currency conversion, etc.): often 3.8–4.2%

Compute your real blended rate from your processor's monthly statement: `total_fees / total_collected`.

## Returns Reserve

A percentage of revenue set aside to cover returns / refunds you'll process later:

- **Default rate:** ~`X.X%` of (revenue – tips)

Pull this from your historical data: `total_refunds_last_90d / total_revenue_last_90d`. Different categories have very different return rates (apparel ~5–8%, supplements ~1–2%, hard goods ~1–3%).

## Contribution Margin Formula

Once the tables above are filled in, the formula is:

```
revenue       = total_price                        (cash collected from Shopify)
total_cogs    = sum(unit_cogs × quantity for each line item, excluding tips)
shipping_cost = lookup(total_order_weight_oz)      (your cost to ship)
processing    = revenue × processing_rate          (your processor's cut)
returns_rsv   = (revenue - tips) × returns_rate    (set aside for returns)

margin_before_ads = revenue - total_cogs - shipping_cost - processing - returns_rsv
cm                = margin_before_ads - ad_spend_in_store_currency
```

The shipping the customer paid is **already inside `total_price`**, so it offsets the shipping cost line naturally. Don't double-count.

## Product Type Detection (used by the cron script)

Document how to detect product family and size from Shopify line item titles / variants. The cron script uses these rules to look up COGS without hitting an external mapping file.

### Title detection rules (example)

- Title contains `"Product Family A"` or `"alternate name"` → Family A COGS
- Title contains `"Product Family B"` → Family B COGS
- Default → Family A COGS

### Variant / size detection rules (example)

- Variant contains `"Large"` → Large COGS + Large weight
- Variant contains `"Medium"` → Medium COGS + Medium weight
- Default → Medium COGS + Medium weight

Keep these rules deterministic and case-insensitive.

## Break-Even ROAS Targets (optional)

Useful for sanity-checking ad performance:

| Scenario | BEROAS |
|----------|--------|
| 1 unit @ $X with paid shipping | X.XXx |
| 1 unit @ $X with free shipping | X.XXx |
| 2 units @ $X (bundle) free ship | X.XXx |

Compute: `BEROAS = revenue / (revenue - margin_before_ads)`. The lower this is, the more "room" you have to spend on ads at break-even.

## CPA Targets (optional)

For each scenario above, derive the CPA at your target CM%:

| Target CM% | 1-unit CPA | 2-unit CPA |
|------------|------------|------------|
| 20% CM | $X | $X |
| 10% CM | $X | $X |
| 0% CM (break-even) | $X | $X |

Translate to your ad-spend currency if it differs from your store currency.
