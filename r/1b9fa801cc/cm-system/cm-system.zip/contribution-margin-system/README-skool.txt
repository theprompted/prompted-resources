==================================================
CONTRIBUTION MARGIN SYSTEM — SETUP GUIDE
==================================================

This guide walks you through setting up a real-time contribution margin tracker for your Shopify store. By the end, you will have:

  -  A dashboard you can open in your browser that updates every 15 minutes with your actual margin (not just revenue minus ad spend)
  -  Three "skills" you can ask Claude Code to use, like *how much did we make yesterday* or *what hours are we losing money*
  -  A log of every snapshot, so you can answer questions about your business going back days or weeks

This is the system from the YouTube video *"Recovering $1K/Day in Facebook Ads with Claude Code."*

  TIME TO SET UP:    about 60-90 minutes the first time, mostly waiting on accounts.
  COST:              $0. Everything used is free.
  TECHNICAL LEVEL:   if you have installed software before and can copy-paste a command into a terminal, you can do this.


==================================================
TABLE OF CONTENTS
==================================================

  1.   What you need before you start
  2.   Install the prerequisites
  3.   Download and unzip the bundle
  4.   Get your Shopify credentials
  5.   Get your Meta (Facebook) credentials
  6.   Configure the .env file
  7.   Fill in your unit economics
  8.   Test that it works
  9.   Schedule it to run every 15 minutes
  10.  Use the skills inside Claude Code
  11.  If something goes wrong
  12.  What this bundle does NOT include


==================================================
SECTION 1: WHAT YOU NEED BEFORE YOU START
==================================================

Before you do anything, make sure you have the following. If you do not have something on this list, the rest of the guide will not work.

  >>  A Shopify store that you own or have admin access to.
  >>  A Meta Ads account running Facebook / Instagram ads, where you have admin access.
  >>  A computer running macOS or Windows.
  >>  A Claude subscription (Pro or Team) — needed to run Claude Code.
  >>  About 60-90 minutes of focused time.

If any of those are not true, stop here and come back when they are.


==================================================
SECTION 2: INSTALL THE PREREQUISITES
==================================================

You will need three pieces of software:

  1.  Python — the language the cron script is written in
  2.  Claude Code — the AI tool that runs the skills
  3.  A code editor — to view and edit a couple of text files (.env and unit-economics.json)


--------------------------------------------------
2.1  INSTALL PYTHON
--------------------------------------------------

ON MAC

  1.  Open the Terminal app. (Press Cmd+Space to open Spotlight, type Terminal, press Enter.)

  2.  Copy and paste this exactly, then press Enter:

        python3 --version

  3.  IF YOU SEE a number like Python 3.11.x or higher, you already have Python and can skip to section 2.2.

  4.  IF YOU SEE "command not found" or a version below 3.11, do this:

        -  Go to python.org/downloads
        -  Click the big yellow "Download Python 3.x.x" button
        -  Open the file you downloaded (it ends in .pkg) and follow the installer. Click Continue / Agree / Install through every prompt. You may need to enter your Mac password.
        -  When it is done, CLOSE TERMINAL COMPLETELY and reopen it.
        -  Run python3 --version again to confirm. You should now see Python 3.11.x or higher.


ON WINDOWS

  1.  Open the Command Prompt app. (Press the Windows key, type cmd, press Enter.)

  2.  Copy and paste this exactly, then press Enter:

        python --version

  3.  IF YOU SEE a number like Python 3.11.x or higher, you already have Python and can skip to section 2.2.

  4.  IF YOU SEE "'python' is not recognized" or a version below 3.11, do this:

        -  Go to python.org/downloads
        -  Click the big yellow "Download Python 3.x.x" button
        -  Open the file you downloaded (it ends in .exe)

        >>  IMPORTANT: on the first installer screen, CHECK THE BOX that says "Add python.exe to PATH" at the bottom. If you skip this, nothing will work.

        -  Click "Install Now" and let it finish.
        -  When it is done, CLOSE COMMAND PROMPT COMPLETELY and reopen it.
        -  Run python --version again to confirm. You should now see Python 3.11.x or higher.


--------------------------------------------------
2.2  INSTALL THE PYTHON LIBRARIES THIS SCRIPT NEEDS
--------------------------------------------------

The script uses two small libraries: requests (for talking to Shopify and Meta) and python-dotenv (for reading your settings).

ON MAC, in Terminal:

  pip3 install requests python-dotenv

ON WINDOWS, in Command Prompt:

  pip install requests python-dotenv

You should see a few lines of output ending with something like "Successfully installed requests-... python-dotenv-...". If you see errors, see SECTION 11.


--------------------------------------------------
2.3  INSTALL CLAUDE CODE
--------------------------------------------------

Claude Code is a free tool from Anthropic that runs in your terminal and uses your Claude subscription.

  1.  Go to the Claude Code installation page at docs.claude.com/en/docs/claude-code/quickstart and follow the instructions there. (They keep the install command up to date — anything written here will go stale.)

  2.  Once installed, open a terminal in any folder and type "claude". The first time you run it, it will ask you to log in with your Claude account. Follow the prompts.

  3.  Once you see a "❯" prompt waiting for input, Claude Code is working. Type /exit or press Ctrl+D to exit for now.


--------------------------------------------------
2.4  INSTALL A CODE EDITOR
--------------------------------------------------

You only need a code editor to edit two text files. Any of these is fine — pick one:

  -  Visual Studio Code (free, popular) — code.visualstudio.com
  -  Sublime Text (free to evaluate) — sublimetext.com
  -  TextEdit (Mac, built-in) — works but you have to switch it to "plain text mode" via Format → Make Plain Text
  -  Notepad (Windows, built-in) — works fine for this

If you are not sure, install Visual Studio Code. It is the most common, and there are tons of tutorials if you ever get stuck.


==================================================
SECTION 3: DOWNLOAD AND UNZIP THE BUNDLE
==================================================

You have been given a zip file (e.g. contribution-margin-system.zip).

  1.  Move the zip file to a place you will remember. RECOMMENDED: your Desktop.

  2.  Double-click the zip file to extract it. You should now see a folder called contribution-margin-system on your Desktop.

  3.  Open that folder. You should see the following structure inside:

        contribution-margin-system/
            README.md                   <- this file
            .env.example
            skills/
                cm-tracker/
                cm-trends/
                hourly-analysis/
            scripts/
                cm-tracker-cron.py
            references/
                unit-economics.template.md
                unit-economics.template.json


  >>  TIP — MAKING HIDDEN FILES VISIBLE.
      The file .env.example starts with a dot, which makes it hidden by default on Mac and Windows.

        ON MAC:      in Finder, press Cmd+Shift+. (period) to toggle hidden files on and off.
        ON WINDOWS:  in File Explorer, click the "View" tab at the top, then check "Hidden items".

You now have all the code on your computer. The next sections walk through getting your Shopify and Meta credentials, then plugging them in.


==================================================
SECTION 4: GET YOUR SHOPIFY CREDENTIALS
==================================================

You need an Admin API access token from your Shopify store. This is what lets the script read your orders.

  >>  YOU ONLY DO THIS ONCE. Once you have the token, you do not need to do this again unless you delete the app.

  1.  Log into your Shopify admin at https://yourstore.myshopify.com/admin (replace "yourstore" with your actual store).

  2.  In the left sidebar, click Settings (gear icon at the very bottom).

  3.  Click "Apps and sales channels".

  4.  Click "Develop apps" (top right of the page). If you have never done this before, Shopify will ask you to "Allow custom app development" — click that and confirm.

  5.  Click "Create an app".

  6.  Give it a name (e.g. CM Tracker) and click "Create app".

  7.  Click the Configuration tab.

  8.  Under "Admin API integration", click "Configure".

  9.  Scroll through the list of scopes and check the boxes for these (use the search box at the top to find each one quickly):

        -  read_orders
        -  read_all_orders   (this one is important — without it, you can only read the last 60 days)
        -  read_reports      (only if you want the hourly-analysis skill)

  10. Click Save at the top right.

  11. Click the API credentials tab.

  12. Click "Install app" at the top right. Confirm by clicking Install in the dialog.

  13. After it installs, you will see an "Admin API access token" field with a "Reveal token once" button. Click it.

  14. COPY THE TOKEN IMMEDIATELY and paste it somewhere safe (like a sticky note in your password manager). It starts with shpat_ and you can only view it once. If you lose it, you will have to uninstall and reinstall the app.

You also need your STORE DOMAIN. It is the "something.myshopify.com" part — for example, if your admin URL is https://shopthebrand.myshopify.com/admin, your store domain is shopthebrand.myshopify.com.

SAVE THESE TWO VALUES somewhere you can find them in 5 minutes:

  Store domain:        ____________.myshopify.com
  Admin API token:     shpat_____________________


==================================================
SECTION 5: GET YOUR META (FACEBOOK) CREDENTIALS
==================================================

You need a Meta access token with the ads_read permission, plus your ad account ID.

  >>  HEADS UP: Meta tokens from the Graph API Explorer expire after about an hour. For long-term use, you will want to extend it to a 60-day token (steps below). For now, just get a short token to make sure everything works.


--------------------------------------------------
5.1  GET A SHORT-LIVED TOKEN (TO TEST WITH)
--------------------------------------------------

  1.  Go to developers.facebook.com. Log in with the Facebook account that has access to your ads.

  2.  In the top menu, hover over "My Apps" and click "Create App" (if you do not already have an app). Choose "Other" / "Business" as the type. Fill in a name like CM Tracker.

  3.  Once your app exists, in the top menu hover over "Tools" and click "Graph API Explorer".

  4.  On the right side, find the "Meta App" dropdown and select your app.

  5.  Click the "User or Page" dropdown and select "Get User Access Token".

  6.  A dialog will appear asking which permissions you want. Click "Add Permission" and add ads_read. (You may need to click "Add Permission" multiple times to find it — search for ads_read.)

  7.  Click "Generate Access Token". Facebook will ask you to approve. Click through.

  8.  The long string in the "Access Token" field at the top is your token. COPY IT AND PASTE IT SOMEWHERE SAFE. It starts with something like EAAB...


--------------------------------------------------
5.2  GET YOUR AD ACCOUNT ID
--------------------------------------------------

  1.  Go to business.facebook.com.

  2.  Click the menu icon (three lines) at the top left, then "Business settings".

  3.  In the left sidebar, click Accounts → Ad Accounts.

  4.  Find the ad account you use for the store. Underneath the account name is a number — that is your ad account ID.

  5.  THE FORMAT THE SCRIPT NEEDS is "act_" followed by the number. For example, if the number is 1234567890123456, your value is act_1234567890123456.


--------------------------------------------------
5.3  (RECOMMENDED) EXTEND YOUR TOKEN TO 60 DAYS
--------------------------------------------------

The token from step 5.1 only lasts about an hour. To make it last 60 days:

  1.  In the same Graph API Explorer page, copy your short token from the Access Token field.

  2.  Open this URL in a new browser tab (replace YOUR_TOKEN with the token you just copied):

        https://graph.facebook.com/v21.0/oauth/access_token?grant_type=fb_exchange_token&client_id=YOUR_APP_ID&client_secret=YOUR_APP_SECRET&fb_exchange_token=YOUR_TOKEN

  3.  To find YOUR_APP_ID and YOUR_APP_SECRET: in your app's dashboard at developers.facebook.com, click "App settings" → "Basic". App ID is at the top. Click "Show" next to App secret (it will ask for your password).

  4.  The URL will return a JSON response with a new access_token field. THAT IS YOUR 60-DAY TOKEN. Use that one instead.

You do not have to do this — the script will work with a short token, you just have to refresh it every hour. For real use, the 60-day token is the way.

SAVE THESE THREE VALUES:

  Meta access token:   EAA________________________________
  Ad account ID:       act_____________
  API version:         v21.0   (just use this — it is the current version as of writing)


==================================================
SECTION 6: CONFIGURE THE .ENV FILE
==================================================

The .env file is where you tell the script your credentials and settings.

  1.  In the contribution-margin-system folder, find the file called .env.example.

  2.  MAKE A COPY OF IT AND RENAME THE COPY TO .env (no extension, just .env).

        ON MAC: in Terminal, navigate to the folder and run:

          cd ~/Desktop/contribution-margin-system
          cp .env.example .env

        ON WINDOWS: in Command Prompt:

          cd %USERPROFILE%\Desktop\contribution-margin-system
          copy .env.example .env

  3.  Open the new .env file in your code editor (right-click → Open With → Visual Studio Code, or whatever editor you installed).

  4.  Fill in each value with what you collected in sections 4 and 5. The file has comments explaining each one. The required ones are:

        BRAND_NAME=My Store                       <- shows up in the dashboard header
        SHOPIFY_STORE=yourstore.myshopify.com     <- from section 4
        SHOPIFY_ACCESS_TOKEN=shpat_xxxxx          <- from section 4
        META_ACCESS_TOKEN=EAAxxxxx                <- from section 5
        META_AD_ACCOUNT_ID=act_xxxxx              <- from section 5

  5.  FOR CURRENCY AND TIMEZONE:

        -  If your Shopify revenue and Meta ad spend are in the same currency (e.g. both USD), leave STORE_CURRENCY and AD_SPEND_CURRENCY set to the same value.

        -  If they are different (e.g. USD revenue but CAD ad spend, common for Canadian operators), set them accordingly. The script will look up the live exchange rate.

        -  For STORE_TIMEZONE, use your store's timezone in IANA format. Most US stores: America/New_York. Other examples: America/Los_Angeles, America/Chicago, Europe/London, Australia/Sydney. Full list at en.wikipedia.org/wiki/List_of_tz_database_time_zones.

  6.  SAVE THE FILE. Make sure your editor saves it as plain text, not as .env.txt (Notepad on Windows is sneaky about this — see the tip below).


  >>  IMPORTANT — .ENV FILENAME GOTCHA ON WINDOWS.
      Notepad and some editors sneakily save your file as .env.txt even when you type .env. To check: in File Explorer, click View → "File name extensions" so extensions show. If you see .env.txt, right-click → Rename and remove the .txt. The script will not work if the file is named .env.txt.


==================================================
SECTION 7: FILL IN YOUR UNIT ECONOMICS
==================================================

The script needs to know your COGS (cost of goods sold), shipping costs, and processing/returns rates to calculate real margin. This lives in references/unit-economics.json.

  1.  In the references folder, find the file called unit-economics.template.json.

  2.  MAKE A COPY OF IT AND RENAME THE COPY TO unit-economics.json (drop the .template part). Same cp / copy pattern as the .env file.

  3.  Open unit-economics.json in your code editor.

  4.  Read unit-economics.template.md (in the same folder) — it walks through what every section means and how to figure out your numbers.

  5.  Fill in the JSON file with your actual numbers. Three things to be careful about:

        -  PROCESSING_RATE: pull this from a recent monthly statement from your payment processor. Don't guess. Most Shopify Payments stores land at ~4.1% blended once you include chargebacks and currency conversion fees.

        -  RETURNS_RATE: pull from your last 90 days of refunds. total_refunds / total_revenue. Apparel ~5-8%, supplements ~1-2%, hard goods ~1-3%.

        -  SHIPPING_TIERS: pull from your actual carrier rate sheet. Small per-order errors compound across thousands of orders.

  6.  SAVE THE FILE and make sure it is still valid JSON. (If you accidentally delete a comma or quote, the script will refuse to start. If unsure, paste the file into jsonlint.com — it will tell you if there is a syntax error.)

If you have never done unit economics before, this is the part that takes the longest. Take your time. The accuracy of everything downstream depends on this file.


==================================================
SECTION 8: TEST THAT IT WORKS
==================================================

Time to do a manual test run.

  1.  Open Terminal (Mac) or Command Prompt (Windows).

  2.  Navigate to the project folder:

        ON MAC:

          cd ~/Desktop/contribution-margin-system

        ON WINDOWS:

          cd %USERPROFILE%\Desktop\contribution-margin-system

  3.  Run the script:

        ON MAC:

          python3 scripts/cm-tracker-cron.py

        ON WINDOWS:

          python scripts\cm-tracker-cron.py

  4.  You should see output like this:

        [2026-05-04T10:15:00...] Starting CM run...
          Fetching Shopify orders...
          Got 12 orders.
        [2026-05-04T10:15:08...] Done. Rev: $487.23 | CM: $34.10 | Orders: 12

  5.  After a successful run, the script created two files in a new reports/ folder:

        -  reports/cm-tracker.jsonl  <- the snapshot log (one line per run)
        -  reports/cm-tracker.html   <- the dashboard

  6.  OPEN THE HTML DASHBOARD:

        ON MAC:      in Terminal, run "open reports/cm-tracker.html" — it will open in your default browser.
        ON WINDOWS:  in File Explorer, navigate to Desktop\contribution-margin-system\reports, double-click cm-tracker.html.

  7.  You should see a styled dashboard with your revenue, CM, ROAS, and order count for today, plus a waterfall breakdown.

If you see errors in step 4 instead of a clean output line, jump to SECTION 11.


==================================================
SECTION 9: SCHEDULE IT TO RUN EVERY 15 MINUTES
==================================================

Once the manual run works, schedule it so it runs automatically every 15 minutes. The dashboard's auto-refresh will keep showing fresh numbers without you doing anything.


--------------------------------------------------
ON MAC (USING CRON)
--------------------------------------------------

  1.  In Terminal, type:

        crontab -e

      This opens an editor (probably vim, which is awkward — see tip below).

  2.  Press "i" to enter insert mode.

  3.  Add this line, but REPLACE /Users/yourname/Desktop/contribution-margin-system with your actual path:

        */15 * * * * /usr/bin/python3 /Users/yourname/Desktop/contribution-margin-system/scripts/cm-tracker-cron.py >> /Users/yourname/Desktop/contribution-margin-system/reports/cron.log 2>&1

      To find your actual path, in Terminal navigate to the folder (as in step 8.2), then run "pwd". Copy what it prints.

  4.  Press Esc, then type :wq and press Enter to save and exit.

  5.  Confirm it saved by running:

        crontab -l

      You should see your line.


  >>  TIP — IF VIM IS TOO PAINFUL, run this instead of crontab -e. It uses a simpler editor (nano):

        EDITOR=nano crontab -e

      In nano, you just type, then press Ctrl+O to save, Enter to confirm, Ctrl+X to exit.


  >>  HEADS UP — macOS may block cron from accessing your Desktop. If after 15 minutes you do not see new lines in reports/cm-tracker.jsonl, this is probably why. Open System Settings → Privacy & Security → Full Disk Access → click the "+" button → navigate to /usr/sbin/cron (you may need to press Cmd+Shift+G and type /usr/sbin) and add it. Or move the project folder out of Desktop to your home folder (~/cm-tracker) where cron can access it without extra permissions.


--------------------------------------------------
ON WINDOWS (USING TASK SCHEDULER)
--------------------------------------------------

  1.  Press the Windows key, type "Task Scheduler", press Enter.

  2.  In the right panel, click "Create Basic Task".

  3.  Name: CM Tracker. Click Next.

  4.  Trigger: Daily. Click Next. Set start time to now. Click Next.

  5.  Action: "Start a program". Click Next.

  6.  Program/script: python (just the word).

  7.  Add arguments: scripts\cm-tracker-cron.py

  8.  Start in: paste the full path to your project folder, e.g. C:\Users\YourName\Desktop\contribution-margin-system

  9.  Click Next, then CHECK THE BOX "Open the Properties dialog when I click Finish", then Finish.

  10. In the Properties dialog that opens, go to the Triggers tab, click your trigger, click Edit.

  11. Check "Repeat task every" and set it to 15 minutes for a duration of 1 day.

  12. Click OK twice to save.

To confirm it is working, after 15 minutes look for new lines in reports\cm-tracker.jsonl (each line is one snapshot).


--------------------------------------------------
CONFIRMING THE CRON IS RUNNING (BOTH PLATFORMS)
--------------------------------------------------

After 15-30 minutes:

  1.  Open reports/cm-tracker.jsonl in your code editor.

  2.  Each line in the file is a snapshot. After two scheduled runs, you should see at least 2 lines.

  3.  Open reports/cm-tracker.html in your browser. You should see the latest snapshot at the top, plus a "Pacing" table showing all snapshots from today.

The dashboard auto-refreshes every 10 minutes when you have it open in a browser tab.


==================================================
SECTION 10: USE THE SKILLS INSIDE CLAUDE CODE
==================================================

Now the fun part. Three skills are included; you "load" them into Claude Code by copying them into a special folder, and then you can ask Claude Code questions in plain English.


--------------------------------------------------
10.1  FIND CLAUDE CODE'S SKILLS FOLDER
--------------------------------------------------

Claude Code looks for skills in a .claude/skills/ folder inside whatever project you open it in. The simplest setup: open Claude Code with the contribution-margin-system folder as the project, and the skills will load automatically.

  1.  Open Terminal (Mac) or Command Prompt (Windows).

  2.  Navigate to the project folder:

        ON MAC:      cd ~/Desktop/contribution-margin-system
        ON WINDOWS:  cd %USERPROFILE%\Desktop\contribution-margin-system

  3.  Create the .claude/skills/ directory and copy the three skills into it:

        ON MAC:

          mkdir -p .claude/skills
          cp -r skills/cm-tracker .claude/skills/
          cp -r skills/cm-trends .claude/skills/
          cp -r skills/hourly-analysis .claude/skills/

        ON WINDOWS:

          mkdir .claude\skills
          xcopy /E /I skills\cm-tracker .claude\skills\cm-tracker
          xcopy /E /I skills\cm-trends .claude\skills\cm-trends
          xcopy /E /I skills\hourly-analysis .claude\skills\hourly-analysis

  4.  Start Claude Code in this folder:

        claude

  5.  Once you see the "❯" prompt, the skills are loaded.


--------------------------------------------------
10.2  ASK QUESTIONS
--------------------------------------------------

Try these one at a time:


  SINGLE-PERIOD CM (uses cm-tracker skill):

    -  How much did we make yesterday?
    -  What's our contribution margin so far today?
    -  Pull yesterday's P&L and show me the waterfall.
    -  Which ads spent over $50 yesterday and what was their CPA?


  MULTI-PERIOD COMPARISON (uses cm-trends skill):

    -  Compare this week to last week.
    -  Was March better than February?
    -  Show me daily CM for the last 14 days.
    -  Is today's CM normal variance or actually bad?


  HOURLY PROFITABILITY (uses hourly-analysis skill — needs at least 7 days of cron data):

    -  What hours of the day are we losing money?
    -  Pull our CVR by hour for the last 90 days.
    -  Cross-reference CVR by hour with CM by hour. Where do they disagree?


Claude Code will pick the right skill based on what you ask. If it picks the wrong one or seems confused, be more specific (e.g. "use the cm-trends skill to compare...").


--------------------------------------------------
10.3  WHERE THE DATA COMES FROM
--------------------------------------------------

  -  FOR SINGLE-PERIOD AND TREND QUESTIONS, Claude Code hits Shopify and Meta APIs live using your .env credentials.
  -  FOR HOURLY QUESTIONS, Claude Code reads reports/cm-tracker.jsonl (the cron log) plus pulls 90-day CVR from Shopify.

You do not have to do anything different — the skills handle which source to use.


==================================================
SECTION 11: IF SOMETHING GOES WRONG
==================================================


--------------------------------------------------
"command not found: python3" / "'python' is not recognized"
--------------------------------------------------

Python is not installed, or it is not on your PATH. Go back to section 2.1 and reinstall, making sure to CHECK THE "Add to PATH" BOX ON WINDOWS.


--------------------------------------------------
"ModuleNotFoundError: No module named 'requests'"
--------------------------------------------------

You skipped section 2.2. Run:

  ON MAC:      pip3 install requests python-dotenv
  ON WINDOWS:  pip install requests python-dotenv


--------------------------------------------------
"ERROR: missing required env vars"
--------------------------------------------------

Your .env file is missing values, or the file is named wrong (e.g. .env.txt instead of .env). Check:

  1.  The file is in the project root, not in references/ or scripts/.
  2.  The file is named exactly .env with the dot, no .txt at the end.
  3.  None of the lines have empty values after the "=" sign.


--------------------------------------------------
"ERROR: unit economics file not found"
--------------------------------------------------

You skipped section 7. Copy references/unit-economics.template.json to references/unit-economics.json and fill it in.


--------------------------------------------------
SHOPIFY RETURNS 401 / "Invalid API key or access token"
--------------------------------------------------

Your token is wrong, expired, or does not have the right scopes. Go back to section 4, recreate the custom app, and make sure you copy the new token into .env.


--------------------------------------------------
META RETURNS "Invalid OAuth access token" OR 190
--------------------------------------------------

Your Meta token expired (the short-lived one only lasts about an hour). Get a new one from Graph API Explorer (section 5.1), or extend it to 60 days (section 5.3).


--------------------------------------------------
META RETURNS "Insufficient permissions"
--------------------------------------------------

The token does not have ads_read. Regenerate it in Graph API Explorer with that permission added.


--------------------------------------------------
NUMBERS IN THE DASHBOARD LOOK WRONG
--------------------------------------------------

Almost always your unit-economics.json is off. Re-check processing_rate and returns_rate against your real statements first — those are the most common errors. Then check shipping tiers.


--------------------------------------------------
CRON IS NOT RUNNING ON MAC
--------------------------------------------------

See the "macOS may block cron" tip in section 9. Most often, granting cron Full Disk Access fixes it. Easier alternative: move the folder out of ~/Desktop to ~/cm-tracker.


--------------------------------------------------
THE .JSONL FILE IS FILLING UP — IS THAT OK?
--------------------------------------------------

Yes. Each line is small (a few KB). After a year of runs every 15 minutes, the file will be roughly 100MB. If you ever want to compress old data, just rename the file (mv cm-tracker.jsonl cm-tracker-2026.jsonl) and the cron will start a fresh one.


--------------------------------------------------
I'M STUCK ON SOMETHING NOT IN THIS LIST
--------------------------------------------------

Open Claude Code in the project folder and describe what is wrong. Claude can read your .env, look at error messages, and walk you through fixes interactively.


==================================================
SECTION 12: WHAT THIS BUNDLE DOES NOT INCLUDE
==================================================

To set expectations clearly:

  -  NO BID THROTTLING / COST CAP AUTOMATION.
     The YouTube video ended with a script that automatically tightened bids at 6pm and loosened them at 8am. That script is intentionally not in this bundle — it is the most account-specific piece (depends on your campaign structure, your Meta optimization goal type, your tolerance for scheduled changes). The discovery layer (hourly-analysis) is the high-leverage part. Once you know which hours leak money, building the throttle is straightforward.

  -  NO TELEGRAM, SLACK, OR EMAIL NOTIFICATIONS.
     The cron writes a JSONL log and refreshes the HTML dashboard. If you want push notifications, the JSONL log is easy to hook into.

  -  NO AUTOMATIC SKU UPDATES.
     When you add new products, you will need to update unit-economics.json by hand. Worth automating once you outgrow this — but at the size where that matters, you have a data team.


==================================================
CREDIT
==================================================

This system was built and refined by The Prompted (youtube.com/@theprompted) on a real DTC store. The methodology — real CM not revenue-minus-spend, JSONL append-only design, CVR-vs-CM triangulation, throttle-not-pause — is hard-won from running real ad accounts.

If this is useful, the original videos on YouTube walk through how it was built and what we learned along the way.


==================================================
END OF GUIDE
==================================================
