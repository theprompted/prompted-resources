---
name: Hourly Analysis
description: "Find which hours of the day make money and which lose it. Combines Shopify session + CVR data by hour with CM data by hour from the JSONL log. Use for: 'when are we making money', 'should we tighten bids in the evening', 'CVR by hour', 'is our evening spend worth it'."
---

# Hourly Analysis — Hourly Profitability Discovery

Combine Shopify sessions + CVR by hour (90-day window from your store) with contribution margin by hour (computed from 15-min JSONL snapshots) to identify which hours of the day actually make money — and which ones bleed it.

## When to Use

- "What hours are we making money?"
- "When should we tighten bids?"
- "Is our evening spend worth it?"
- "CVR by hour, by day of week"
- "Back-test our hourly performance"

## The Core Insight

**CVR alone can lie to you.**

An hour can have decent conversion rate but still lose money if the spend during that hour is too high relative to the orders it produces. The reverse is also true — a low-CVR hour can be profitable if spend is appropriately scaled.

This skill triangulates two independent signals:

1. **Shopify CVR by hour, 90-day window** — tells you when *converting traffic* is concentrated
2. **CM delta by hour from the JSONL log** — tells you actual contribution margin landing in those hours

**When CVR and CM disagree, CM wins for scheduling decisions.** It measures actual profit, not just conversion efficiency.

## Prerequisites

### Shopify (with read_reports access)

Standard Admin API tokens often don't have `read_reports` scope, which is required for the ShopifyQL `sessions` and `sales` datasets. To get a token with this scope:

**Option A — Custom app:** Create a Shopify custom app in your admin, add `read_reports` and `read_orders` scopes, install it, and use the resulting `shpat_` token.

**Option B — OAuth flow:** If you have OAuth client credentials for your store, exchange them for an access token with the scopes you need:

```python
import requests
r = requests.post(
    "https://{SHOPIFY_STORE}/admin/oauth/access_token",
    json={
        "client_id":     "{your_oauth_client_id}",
        "client_secret": "{your_oauth_client_secret}",
        "grant_type":    "client_credentials",
    },
)
token = r.json()["access_token"]  # shpat_...
```

Set in `.env`:

```
SHOPIFY_STORE=your-store.myshopify.com
SHOPIFY_REPORTS_TOKEN=shpat_xxxxxxxxxxxxxxxxxxxxxxxx
```

**Important:** Keep this token in `.env` only — never commit it to source.

### JSONL log from `cm-tracker` cron

This skill reads `reports/cm-tracker.jsonl`, written by the cron script. You need at least 7–10 days of snapshots before the hourly CM signal stabilizes.

## Data Sources

### 1. Shopify Sessions + CVR by Hour

Use ShopifyQL via the **unstable** GraphQL API:

```
POST https://{SHOPIFY_STORE}/admin/api/unstable/graphql.json
Headers: X-Shopify-Access-Token: {SHOPIFY_REPORTS_TOKEN}
```

**ShopifyQL — CVR by hour (90-day window):**

```graphql
{
  shopifyqlQuery(query: "FROM sessions SHOW sessions, conversion_rate GROUP BY hour_of_day SINCE -90d UNTIL today ORDER BY hour_of_day ASC") {
    parseErrors
    tableData { columns { name } rows }
  }
}
```

**ShopifyQL — CVR by hour × day of week:**

```graphql
{
  shopifyqlQuery(query: "FROM sessions SHOW sessions, conversion_rate GROUP BY hour_of_day, day_of_week SINCE -90d UNTIL today ORDER BY day_of_week ASC, hour_of_day ASC") {
    parseErrors
    tableData { columns { name } rows }
  }
}
```

**ShopifyQL — gross sales by hour:**

```graphql
{
  shopifyqlQuery(query: "FROM sales SHOW gross_sales, net_sales GROUP BY hour_of_day SINCE -90d UNTIL today ORDER BY hour_of_day ASC") {
    parseErrors
    tableData { columns { name } rows }
  }
}
```

### Notes on ShopifyQL

- Use `GROUP BY` (not `GROUPED BY`) — the parser will reject the wrong form
- `rows` returns JSON objects directly — the field is `rows`, not `rows { cells }`
- `hour_of_day` is in your **store timezone**, not UTC
- `day_of_week` is `0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat`
- Use a **90-day window** — 7-day has too much variance; 30-day is borderline
- The `orders` dataset doesn't exist in ShopifyQL — estimate order counts as `sessions × conversion_rate`

### 2. CM Delta by Hour (from JSONL)

Read `reports/cm-tracker.jsonl`, compute CM deltas between consecutive 15-min snapshots, group by hour, and average across days.

```python
from collections import defaultdict
import json

snapshots = []
with open("reports/cm-tracker.jsonl") as f:
    for line in f:
        if line.strip():
            snapshots.append(json.loads(line))

by_date = defaultdict(list)
for s in snapshots:
    by_date[s["date"]].append(s)

hour_cms = defaultdict(list)
for date, snaps in by_date.items():
    snaps.sort(key=lambda x: x["ts"])
    for i in range(1, len(snaps)):
        prev, curr = snaps[i-1], snaps[i]
        hour_local = int(curr["ts"][11:13])  # ts has store-local offset
        cm_delta = curr["cm"] - prev["cm"]
        spend_delta = (curr.get("spend_local", 0) or 0) - (prev.get("spend_local", 0) or 0)
        if spend_delta > 0.5:  # ignore zero-spend snapshots
            hour_cms[hour_local].append({"cm": cm_delta, "spend": spend_delta})
```

### Caveats

- **Exclude tightened-bid days:** if you've already implemented a bid throttle (or paused ads at certain hours), JSONL CM during those hours reflects the suppressed spend, not the underlying performance. Filter those days out before computing the baseline, or your "evening losses" will look smaller than they actually are.
- **8 days is thin:** the JSONL signal stabilizes around 14+ days. Treat shorter windows as directional, not exact.
- **API errors leave gaps:** snapshots where `spend` drops to $0 mid-day are usually transient API errors. Filter those out (`if curr["spend_local"] > 0`).

## Analysis Pattern

Pull both data sources, then build three views:

### View 1: CVR by hour vs the average

| Hour | Sessions | CVR | vs avg |
|------|----------|-----|--------|

Flag rows where CVR is below the daily average.

### View 2: CM by hour from JSONL

| Hour | Avg Spend / hr | Avg CM / hr |
|------|----------------|-------------|

Flag hours where average CM is negative.

### View 3: CVR vs CM disagreements

Hours where CVR is above average but CM is negative are the **most important finding**. These are hours where conversion rate alone would say "fine," but the spend is so high relative to the revenue that you're underwater.

The reverse — low CVR but positive CM — is also worth noting; those hours are ones where lower-quality traffic is still profitable, often because spend is appropriately tight.

## Acting on Findings

Three options when problem hours are identified:

1. **Do nothing** — evening impressions may fill retargeting pools that convert in the morning. The system may depend on the lossy hours.
2. **Pause during bad hours** — aggressive. May hurt overall performance if the funnel needs full-day exposure.
3. **Throttle during bad hours** — reduce bids, stay in the auction, spend less. Test whether morning performance holds when evening spend drops.

**Throttling is the recommended first move.** It preserves system learning while reducing exposure. A scheduled job that tightens cost caps in the evening and loosens them in the morning is the canonical implementation.

(This bundle does not include the throttle script itself — that's where things get account-specific. The discovery layer is the high-leverage part.)

## DO NOT

- Use a 7-day window for CVR — too much variance, you'll chase noise
- Trust JSONL CM during periods when bids were already tightened — you'll under-call the size of the leak
- Use order count alone to judge an hour — high-volume hours can still lose money if spend is disproportionate
- Take action on a single week of JSONL data — wait for 14+ days
- Confuse correlation with causation — "we lose money at 7pm" is a finding; *why* requires investigation
