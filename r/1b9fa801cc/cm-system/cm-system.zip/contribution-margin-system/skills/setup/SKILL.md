---
name: Setup CM System
description: "Install all prerequisites for the contribution margin tracker. Trigger phrases: 'set up the cm system', 'set up the contribution margin tracker', 'install dependencies', 'set up this project', 'get me ready to track CM', 'install everything I need'."
---

# Setup the Contribution Margin System

Claude Code uses this skill to install every dependency the user needs to run the contribution margin tracker. Run this once per machine. After it succeeds, the user runs `cm-tracker`, `cm-trends`, or `hourly-analysis` whenever they want.

The user has already:
- Installed Claude Code (we're running inside it)
- Downloaded the bundle zip
- Unzipped it
- Opened Claude Code in the unzipped folder

The user has NOT necessarily:
- Installed Python
- Installed any Python libraries
- Configured `.env` with their Shopify and Meta credentials
- Filled out `references/unit-economics.json` with their actual COGS, weights, shipping, and rates
- Copied the skills into `.claude/skills/`

This skill handles the deterministic install steps. The credential and unit-economics steps require user input — the skill walks them through it interactively.

## Critical: ask before installing each major thing

Don't `pip install` without telling the user what's about to happen and why. Each install needs a one-line "I'm about to install X because Y."

## Critical: handle password prompts gracefully

If `pip install` triggers a sudo prompt (rare, but happens with system Python), tell the user clearly: *"You'll see a password prompt — type your password (you won't see characters as you type) and press Enter."*

## Detection order

Run these checks first, all in parallel via Bash:

```bash
# OS detection
uname -s        # Darwin = Mac, Linux = Linux, MINGW/MSYS = Windows

# Python
python3 --version 2>&1     # need 3.11+
which python3

# Already-installed Python packages
python3 -c "import requests; print(requests.__version__)" 2>&1
python3 -c "import dotenv; print('OK dotenv')" 2>&1

# .env exists?
ls -la .env 2>&1

# unit-economics.json exists?
ls -la references/unit-economics.json 2>&1

# Skills directory ready?
ls -la .claude/skills/ 2>&1
```

Tell the user the install plan in plain English before executing. Example:

> Here's what I'll set up:
> - Install Python libraries: requests (for Shopify and Meta APIs), python-dotenv (for reading your .env)
> - Copy the cm-tracker, cm-trends, and hourly-analysis skills into `.claude/skills/`
> - Walk you through filling out your `.env` (Shopify and Meta credentials)
> - Walk you through your `references/unit-economics.json` (COGS, shipping rates, etc.)
>
> Should I proceed?

## Install steps

### Step 1: Python (only if missing)

If `python3 --version` fails or returns < 3.11:

**Mac:** install Homebrew first if missing, then `brew install python@3.12`. Tell the user about the password prompt.
**Windows:** stop and ask the user to install from https://www.python.org/downloads/ (and check "Add to PATH"). Don't proceed automatically.
**Linux:** `apt install python3` or equivalent.

After installing, **tell the user to close and reopen Claude Code** so it picks up the new PATH.

### Step 2: Python libraries

```bash
pip3 install requests python-dotenv
```

If `pip3` complains about needing a virtual environment (PEP 668), use `pip3 install --break-system-packages requests python-dotenv` — fine for this use case.

### Step 3: Copy skills into `.claude/skills/`

```bash
mkdir -p .claude/skills
cp -r skills/cm-tracker .claude/skills/
cp -r skills/cm-trends .claude/skills/
cp -r skills/hourly-analysis .claude/skills/
cp -r skills/setup .claude/skills/
```

(Yes, copy this setup skill itself in too — so it persists for re-runs.)

### Step 4: Walk the user through `.env`

If `.env` doesn't exist yet:

```bash
cp .env.example .env
```

Then read the .env.example file and ask the user for each required value, in order:

1. **`BRAND_NAME`** — what to call their store in the dashboard header. Example: "Acme Co"
2. **`SHOPIFY_STORE`** — their `something.myshopify.com` domain. If they're not sure, ask: *"What's your Shopify admin URL? It looks like https://yourstore.myshopify.com/admin — I just need the domain part."*
3. **`SHOPIFY_ACCESS_TOKEN`** — the `shpat_...` token from a custom Shopify app. If they don't have one yet, walk them through creating one:
   - Shopify admin → Settings → Apps and sales channels → Develop apps → Create an app
   - Name it "CM Tracker" or similar
   - Configuration tab → Admin API integration → check `read_orders`, `read_all_orders`, `read_reports`
   - Save → API credentials → Install app → Reveal token
   - Tell them to copy it immediately — Shopify only shows it once
4. **`META_ACCESS_TOKEN`** — the Meta Graph API token with `ads_read` scope. If they don't have one, walk them through getting one at developers.facebook.com → Graph API Explorer.
5. **`META_AD_ACCOUNT_ID`** — format: `act_1234567890123456`. Found at business.facebook.com → Business Settings → Ad Accounts.
6. **`STORE_CURRENCY`** and **`AD_SPEND_CURRENCY`** — both ISO codes (e.g. USD, CAD). If they're the same, set both.
7. **`STORE_TIMEZONE`** — IANA timezone (e.g. America/New_York). Default to America/New_York if they're unsure.

After every value, write it to `.env` immediately so we don't lose progress if they need to step away.

### Step 5: Walk the user through `references/unit-economics.json`

If it doesn't exist yet:

```bash
cp references/unit-economics.template.json references/unit-economics.json
```

Then read both `references/unit-economics.template.json` and `references/unit-economics.template.md`, and walk the user through each section:

1. **Processing rate** — look up their actual blended rate from a recent payment processor statement. Default to 0.041 (4.1%) only if they don't know.
2. **Returns rate** — pull from their last 90 days of refund data. Default by category if they're unsure (apparel ~5–8%, supplements ~1–2%, hard goods ~1–3%).
3. **Product COGS** — for each product family, ask for the cost per unit (or per size variant if it varies). Build the JSON dict as we go.
4. **Product weights** — for each product, ask for the shipping weight in oz. Used to look up shipping cost.
5. **Shipping tiers** — list of `[max_oz, rate_in_store_currency]`. Ask them to pull this from their carrier rate sheet — don't make these up.
6. **Detection rules** — how to map Shopify product titles and variants to the COGS/weights tables.

This is the longest part of setup. Take it slow — every error here corrupts every margin number downstream. If they don't have all the info handy, tell them to come back when they do — partial unit economics is worse than no unit economics.

### Step 6: Smoke test

Run the cron script once with their real values to verify the whole pipeline works:

```bash
python3 scripts/cm-tracker-cron.py
```

If it succeeds, open the resulting `reports/cm-tracker.html` in their browser:

**Mac:** `open reports/cm-tracker.html`
**Windows:** ask them to navigate to it in File Explorer and double-click.

If it fails, the error message will tell us why — usually a credential issue (re-walk that section) or a unit-economics typo (validate JSON via jsonlint.com).

### Step 7: Optional — schedule it

Ask the user: "Want me to schedule this to run every 15 minutes automatically? It writes a JSONL log + refreshes an HTML dashboard you can refresh on demand."

If yes, install a cron entry (Mac/Linux) or a Task Scheduler entry (Windows). Use absolute paths.

## Final report to the user

After all steps pass:

> ✅ Setup complete.
>
> You're ready to track CM. Try:
>
> - *"How much did we make yesterday?"* → cm-tracker skill
> - *"Show me daily CM for the last 14 days"* → cm-trends skill
> - *"What hours of the day are we losing money?"* → hourly-analysis skill (needs at least 7 days of cron data first)
>
> If anything errors, just describe what you saw and I'll fix it.

## If anything fails

- Clearly identify which step failed.
- Show the user the actual error.
- Retry with a different approach, or stop cleanly and explain.
- **Do not silently skip a failed step.**

## When the user runs this again

This skill is idempotent. Every check returns "already installed/configured" and we skip it. We do re-run the smoke test.
