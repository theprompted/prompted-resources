---
name: CM Tracker
description: "Combined Shopify revenue + Meta ad spend report with real per-order contribution margin. Use when you want to know: 'how much did we make today', 'what's our actual margin after ads', 'how are we pacing', 'sales yesterday', 'real CM not just revenue minus spend'."
---

# CM Tracker

Combined revenue, ad spend, and **real contribution margin** report for an e-commerce store. Pulls Shopify orders and Meta Ads data, calculates actual COGS / shipping / processing per order, and delivers a true contribution margin — not just revenue minus ad spend.

This is the foundational skill in the contribution-margin-system bundle:

- **`cm-tracker`** (this skill) — full CM waterfall for a time period (default: yesterday)
- **`cm-trends`** — multi-period comparison (week vs week, month vs month, daily trend)
- **`hourly-analysis`** — hourly profitability via ShopifyQL CVR + JSONL CM deltas

## Why This Exists

Most ad reporting subtracts ad spend from revenue and calls that "margin." It isn't.

A real contribution margin pulls out everything that scales with revenue:

```
Revenue (cash collected)
- COGS (product cost)
- Shipping (your cost to fulfill, not what the customer paid)
- Processing fees (~4.1% blended)
- Returns reserve (~2% of revenue)
- Ad spend
= Contribution Margin
```

The shipping line is the easiest one to miss: shipping the customer paid is already inside `total_price`, and your fulfillment cost lands separately. Both belong in the waterfall.

## Prerequisites

### Shopify
- A Shopify store with the Admin API enabled
- An access token with `read_orders` and `read_all_orders` scopes (custom app or OAuth flow)
- Set in `.env`:
  ```
  SHOPIFY_STORE=your-store.myshopify.com
  SHOPIFY_ACCESS_TOKEN=shpat_xxxxxxxxxxxxxxxxxxxxxxxx
  ```

### Meta Ads
- A Facebook user access token with `ads_read` scope
- Your ad account ID (find it at `business.facebook.com` → Ad Accounts)
- Set in `.env`:
  ```
  META_ACCESS_TOKEN=EAAxxxxxxxxxxxx
  META_AD_ACCOUNT_ID=act_1234567890123456
  META_API_VERSION=v21.0
  ```

### Unit Economics
- Fill out `references/unit-economics.md` with your COGS, shipping tiers, and processing/returns rates. The template walks through every field.

### Currency
- If your store revenue and ad spend are in different currencies, set:
  ```
  STORE_CURRENCY=USD
  AD_SPEND_CURRENCY=CAD
  ```
- The skill will look up the current FX rate or you can set `FX_RATE_OVERRIDE=0.73` for deterministic runs.

## Execution

### Step 1: Determine Time Period

Default to **yesterday** unless the user specifies otherwise. For "today" or "how are we pacing," use today's date and note that data is partial / intraday.

Use your store's local timezone for date filters (Shopify expects ISO 8601 with offset):
```
created_at_min=YYYY-MM-DDT00:00:00-04:00
created_at_max=YYYY-MM-DDT00:00:00-04:00  # next day
```

### Step 2: Pull Data (in parallel)

**Shopify Orders:**
```
GET https://{SHOPIFY_STORE}/admin/api/2024-10/orders.json
  ?created_at_min=...&created_at_max=...&status=any&limit=250
Headers: X-Shopify-Access-Token: {SHOPIFY_ACCESS_TOKEN}
```

Extract from each order:
- `total_price` — **this is revenue**: cash actually collected (product + shipping charged + tips, net of discounts)
- `subtotal_price` — product amount before shipping. Use ONLY for the returns reserve calculation, not as revenue.
- `total_discounts` — for discount analysis (not a line item)
- `discount_codes` / `discount_applications` — discount source
- `line_items` — title, variant, quantity, price (drives COGS lookup)
- `customer.orders_count` — `1` = new customer
- `financial_status` — should be `"paid"`
- `cancelled_at` — should be `null`

If a page returns 250 orders, paginate via the `Link` header.

**Meta Ads — Account-Level:**
```
GET /{META_AD_ACCOUNT_ID}/insights
  ?fields=spend,impressions,clicks,actions,action_values
  &time_range={"since":"YYYY-MM-DD","until":"YYYY-MM-DD"}
```

**Meta Ads — Ad-Level (filter to spend > threshold):**
```
GET /{META_AD_ACCOUNT_ID}/insights
  ?fields=ad_name,adset_name,spend,impressions,clicks,actions,action_values,cost_per_action_type
  &time_range=...&level=ad&sort=spend_descending&limit=50
```
Threshold (e.g. spend > $50) filters down to the ads worth reviewing.

**Meta Ads — Campaign Budgets:**
```
GET /{META_AD_ACCOUNT_ID}/campaigns
  ?fields=name,daily_budget,lifetime_budget,status
  &filtering=[{"field":"effective_status","operator":"IN","value":["ACTIVE"]}]
```
`daily_budget` is in cents — divide by 100 for display.

### Step 3: Calculate Per-Order Economics

For every order, consult `references/unit-economics.md` and compute:

1. **Revenue** = `total_price` (cash collected — already includes shipping charged and tips)
2. **Identify product type** from line item title (your detection rules)
3. **Identify size** from variant title (your size rules)
4. **Look up COGS** per unit from your reference table
5. **Compute total order weight** by summing item weights
6. **Look up shipping cost** from weight-tier table (your fulfillment cost, regardless of what customer paid)
7. **Processing fees** = `total_price × processing_rate` (commonly ~4.1% blended)
8. **Returns reserve** = `(total_price - tips) × returns_rate` (commonly ~2%)
9. **Margin** = `revenue - cogs - shipping_cost - processing - returns_reserve`

The formula is just **cash in, minus all costs out**. Shipping the customer paid is already inside `total_price`, so it naturally offsets the shipping cost line.

### Step 4: Compile Report

Present in this order:

#### 1. Revenue & Margin Summary

| Metric | Value |
|--------|-------|
| Cash Collected (`total_price`) | $X |
| COGS | ($X) |
| Shipping Cost | ($X) |
| Processing Fees | ($X) |
| Returns Reserve | ($X) |
| **Margin Before Ads** | **$X (XX%)** |
| Ad Spend | ($X) |
| **Contribution Margin** | **$X (XX%)** |

If currencies differ, show both. Note the FX rate used.

#### 2. Order Stats

| Metric | Value |
|--------|-------|
| Orders | N |
| AOV | $X |
| Blended ROAS | X.Xx |
| CM per Order | $X |

Also: discounts given off retail ($X across N orders) as context, not as a waterfall line item.

#### 3. New Customer AOV

- N new customers (X% of orders) — AOV: $X
- N returning customers — AOV: $X

#### 4. Products by Units Sold

Sorted most to least. Group products with 1-2 units as "N other products" to keep it readable.

#### 5. Ads Over Threshold

Default threshold: $50 spend. Show all higher.

| Ad | Spend | Purchases | CPA | ROAS |
|----|-------|-----------|-----|------|

Flag any with $0 purchases.

#### 6. Campaign Budget Utilization

| Campaign | Daily Budget | Spend | % Used |

Flag any at 90%+ as **budget-limited**.

### Step 5: Pacing Comparison (optional)

When the user asks "how are we pacing," compare to a prior day:
- Pull the comparison day's data the same way
- Show side-by-side: revenue, spend, orders, ROAS
- Note whether current day is partial (intraday)
- Project end-of-day estimates if asked

## Adjustable Parameters

| Parameter | Default | Example Override |
|-----------|---------|------------------|
| Time period | Yesterday | "today", "last 7 days", "this week" |
| Ad spend threshold | $50 | "ads over $100" |
| Currency rate | Looked up live | User can specify |
| Comparison day | None | "vs yesterday", "vs last week" |

## Optional: Run as a Cron

The full system includes a Python script (`scripts/cm-tracker-cron.py`) that runs every 15 minutes via cron, captures the same data this skill computes (no AI required), and writes it to a JSONL log + an HTML dashboard you can refresh on demand.

### What the cron produces

- **`reports/cm-tracker.jsonl`** — JSONL log, one line per 15-min snapshot. Each line includes the full waterfall, products by units, units-per-order distribution, campaign-level metrics, and ad-level metrics for every ad with spend.
- **`reports/cm-tracker.html`** — visual dashboard with cumulative snapshots and a pacing table. Refresh on demand or set the meta refresh interval in the script.

### When to use the JSONL vs running this skill interactively

- **Use the JSONL** for historical pacing, ad-level trends, "how did X perform between Y and Z" — the data is already there. No API calls needed.
- **Run this skill** for interactive analysis, drill-downs, comparisons, or anything requiring judgment beyond what the cron captures.

### Querying the JSONL

Each line is a JSON object. Key fields:

```
ts, date, time, revenue, cogs, shipping, processing, returns,
margin_before_ads, margin_before_ads_pct, spend_local, spend_other_currency,
cm, cm_pct, roas, orders, aov, total_units, units_per_order,
units_dist, products, campaigns[], ads[]
```

The `ads` array contains every ad with spend. Each entry includes:

```
ad_id, ad_name, adset_name, campaign_name, spend,
impressions, clicks, cpm, cpc, purchases,
purchase_value, cpa, roas
```

**Important:** Meta's intraday numbers are **cumulative** (total for the day so far). To get per-window performance ("how much did ad X spend between 2-4pm"), subtract the earlier snapshot from the later one.

## Drill-Down Follow-Ups

After the CM report, common follow-ups:

- **Drill into a campaign** — show all ads in that campaign with spend / purchases
- **Check budget limits** — which campaigns are capped
- **Pacing check** — "how's today going vs yesterday"
- **Trend / comparison** — use `cm-trends`
- **Hourly breakdown** — use `hourly-analysis`

## DO NOT

- Estimate revenue from Meta purchase values — always use actual Shopify orders
- Use a hardcoded FX rate — look up the current rate or state which one you used
- Mix up currencies anywhere in the waterfall
- Present conclusions before verifying daily totals reconcile (sum of order revenues = `revenue` total)
