---
name: CM Trends
description: "Compare contribution margin across time periods. Use for: 'how was January vs February', 'this week vs last week', 'CM trend', 'is today's performance normal', 'day by day since Sunday', 'last 2 weeks', 'monthly comparison'."
---

# CM Trends — Multi-Period Contribution Margin Analysis

Compare daily CM across time periods. Answers questions like:

- "How does this week compare to last week?"
- "Was March better than February?"
- "Is today's CM normal variance, or actually a problem?"
- "Show me daily CM for the last 14 days."

**This skill is for comparison and trends.** For a single period's full waterfall, use `cm-tracker`. For hourly profitability inside a day, use `hourly-analysis`.

## Why a Baseline Matters

A single day's CM is hard to read in isolation. Was $300 CM a great day or a bad one? Depends on the store's baseline.

This skill builds a rolling baseline from your historical data — typically 60–90 days — and reports new CM numbers in context:

```
Today: $312 CM
Baseline (90d):  P10=-$85   P25=+$67   P50=+$179   P75=+$339   P90=+$487
Today is at ~P70 — above-average day, well within normal range.
```

That framing lets you tell signal from noise. A $-100 day is alarming if your P5 is $-50; it's nothing if your P5 is $-200.

## Prerequisites

Same as `cm-tracker` — Shopify Admin API access, Meta Ads API access, and a filled-out `references/unit-economics.md`.

For historical data older than ~60 days, you may need a Shopify access token from a custom app rather than a session-issued token. Check your token's date scope before pulling long ranges.

## Execution

### Step 1: Determine What's Being Compared

Parse the user's request into time periods. Examples:

| User asks | Periods to pull |
|-----------|----------------|
| "how was March" | Full month, compared to baseline |
| "this week vs last week" | Two 7-day periods |
| "day by day since Sunday" | Daily rows from last Sunday |
| "Jan vs Feb vs Mar" | Three monthly comparisons |
| "last 2 weeks day by day" | 14 daily rows |

### Step 2: Pull Shopify Orders

Use Admin API version `2024-10`. Pull in weekly chunks (max 250 per request, paginate via the `Link` header).

```
GET https://{SHOPIFY_STORE}/admin/api/2024-10/orders.json
  ?created_at_min=YYYY-MM-DDT00:00:00-04:00
  &created_at_max=YYYY-MM-DDT00:00:00-04:00
  &status=any&limit=250
Headers: X-Shopify-Access-Token: {SHOPIFY_ACCESS_TOKEN}
```

**Pagination:** if a page returns exactly 250 orders, follow the `Link: rel="next"` header until you get fewer than 250.

### Step 3: Pull Meta Daily Spend

```
GET /{META_AD_ACCOUNT_ID}/insights
  ?fields=spend
  &time_range={"since":"YYYY-MM-DD","until":"YYYY-MM-DD"}
  &time_increment=1
```

`time_increment=1` returns one row per day. Max ~100 days per request.

### Step 4: Compute Daily CM

For each day:
1. Process all Shopify orders through your unit economics (from `cm-tracker` Step 3 — same formulas)
2. Subtract that day's Meta spend (converted to store currency if needed)
3. Store: `date`, `orders`, `revenue`, `margin_before_ads`, `spend`, `cm`

### Step 5: Build / Reuse Baseline Stats

If you've already computed baseline stats for the last 60–90 days, reuse them. Otherwise, compute and cache:

- **Percentiles:** P5, P10, P25, P50 (median), P75, P90, P95
- **Day-of-week averages:** what's an average Tuesday CM? An average Saturday CM?
- **Monthly summaries:** mean / median CM by month
- **Positive vs negative day count:** how often does CM go negative?

Save to `references/baseline-stats.json` so you don't recompute it every time.

### Step 6: Present Comparison

**For daily view:**

```
Date         Day  Ord    Rev      Margin    Spend     CM
2026-03-29   Sun   62  $3,934   $2,061   $1,606   $+455
2026-03-30   Mon   37  $2,149   $1,150   $1,235    $-85
2026-03-31   Tue   54  $3,201   $1,720   $1,289   $+431
...
```

**For monthly view:**

```
Month      Ord    Revenue    Margin    Spend       CM     CM%   ROAS
Jan 2026   878  $ 56,869   $30,562  $ 24,993  $+5,569   +9.8%  2.28x
Feb 2026   803  $ 48,857   $25,711  $ 20,837  $+4,873  +10.0%  2.34x
Mar 2026   941  $ 61,202   $32,418  $ 26,103  $+6,315  +10.3%  2.31x
```

**Always include context from baseline:**

- Reference your percentiles inline (P10/P25/P50/P75/P90)
- Flag any day below P5 as a red flag
- Note day-of-week context (e.g. weekend may run hotter than weekdays)
- If a period is significantly different from baseline, note it but don't jump to conclusions about cause — that's the operator's job

### Step 7: Stats Summary (for multi-day views)

For any view spanning more than 3 days, append:

| Stat | Value |
|------|-------|
| Mean CM | $X |
| Median CM | $X |
| Min / Max | $X / $X |
| Positive days | N of M |
| Negative days | N of M |
| vs baseline | +X% / -X% |

## DO NOT

- Estimate revenue from Meta purchase values — pull actual Shopify orders
- Use a hardcoded FX rate — always state which one you used
- Mix currencies in the waterfall
- Rush — verify daily totals sum to period totals before presenting
- Present conclusions about *causes* (creative changes, audience shifts, seasonality) — that's interpretation. Show the data, name the deviation, let the operator decide what changed.
