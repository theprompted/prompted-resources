# /tattoos-not-fashion — Turn a Decoded Pocket Into 20 Tattoo-Grade Shirt Concepts + Prompts

The last link in the chain, seen through a different lens than `/make-the-flag`. Take a **decoded pocket** (who they are, how they talk, what they'd never say out loud) and turn it into 20 designs, each one built to be worn **like a tattoo** — something she'd never take off, not just something that looks good for a day. Every design is generated FROM one of the three reasons people actually get tattoos. The split across those three reasons is **derived from the decode**, not guessed. Then STOP and ask before spending a cent generating.

> **The one idea:** *fashion* is the shallow trap — a design that "looks good" gets worn once. A *tattoo* is identity — you'd never take it off. People get tattoos for three reasons, and only one of them is "looks good" (it's dead last). This skill designs for the other two first, in the proportion the pocket actually lives in, and hands you 20 concepts + ready-to-run prompts. It never guesses in a vacuum and it never auto-generates.

## Where this sits in the chain (say this to the user)
```
/parade-hunt         → find the parade (the crowd that keeps refilling)
   → pick the pocket  (one slice inside it, big but tight)
/identity-decoder    → know the pocket (deep psychology, media diet, verbatim language)
/tattoos-not-fashion → MAKE THE TATTOO  ← YOU ARE HERE (3 reasons → derived split → concepts → prompts → optional generate)
```
The first three are the groundwork. This skill picks up right where a finished decode leaves off — the **same input** `/make-the-flag` takes. It is a NEW LENS on the same decode, not a new decode. It is USELESS on a thin decode: the reason-weighting and the "why it's hers" lines are only as good as the understanding of the pocket underneath them.

## When to use
- "/tattoos-not-fashion", "tattoos not fashion", "run the tattoo lens on this pocket", "give me tattoo-grade designs", "20 concepts weighted to who she is", "concepts for [pocket] through the tattoo lens".
- You have a decoded pocket (from `/identity-decoder`, or an equivalent understanding) and want 20 shirt concepts split across the three tattoo reasons, plus ready-to-run prompts.

## When NOT to use
- No decode yet / you only have a broad niche → run the upstream chain first (`/parade-hunt` → pick the pocket → `/identity-decoder`). This skill will OFFER to do that if you arrive without a decode.
- You want the flag-lens version (the 12 identity flags, ~5 concepts per selected flag) → use `/make-the-flag`. This is a sibling skill, a different lens on the same input — overlap is fine and expected.
- You already have final concepts and just want ad scenes from a finished flat design → use `/the-overlap`.
- You want to mechanically composite a design onto a PSD mockup → use `/bb-mockup`.

## The engine it applies (the three reasons + the ink ladder)
People who permanently mark themselves do it for three reasons, and the order is the whole point (Pew, n=8,480):

| Reason | What it says | Pew % | Where it sits |
|---|---|---|---|
| **Honor / remember** | "this is who/what I love, what I lost, what I became" | **69%** | the top rung — identity + meaning |
| **Statement / belief** | "this is what I stand for, the line I'd defend" | **47%** | the middle rung |
| **Improve looks** | "this is a nice design" | **32%** | the bottom rung — where designers START and where most designs die |

Read top to bottom: the reason that drives the MOST permanent ink is meaning, and "looks good" is dead last. That is the exact mistake designers make — they optimize the one thing that matters least. This skill designs from the top of the ladder down, in the proportion **this** pocket actually lives in. (Evidence: Pew Research Center's 2023 tattoo survey, n=8,480.)

---

## ⛔ OPERATING RULES (mirror /make-the-flag, /parade-hunt, /identity-decoder — read before EVERY run)
1. **Never leak the plumbing.** No file paths, script names, JSON field names, or error mechanics on screen, and — critically for this skill — **no raw scoring math shown to the user.** The scoring (0–3 per reason, round, tie-break) is how YOU derive the split; the user sees only the plain-language result ("that's why the batch is 11 belief, 6 honor, 3 looks"). They get a warm reflect, "give me a moment," then clean concepts. Do the grind silently.
2. **REFLECT first, before any work.** After you have the decode, your next message reflects the pocket back in your own words and names which reason it leans on — proves you read it — THEN you go score and build. Skipping this makes it feel like a vending machine.
3. **Present as a CHOICE, gate before spend.** Show concepts + prompts, then ask "want me to generate a few samples?" Never auto-generate. Generation costs API credits — it is always a decided step, never a default.
4. **Phrase OR word OR design — never phrase-only.** A concept can be a phrase [P], a coined word/mark [W], or a design/motif [D] (an icon, a seal, a silhouette, a near-textless illustration). All three are vehicles for the same thing: a design she'd wear like a tattoo. Do not bias to text. Looks-reason concepts especially skew toward [D].
5. **The split is DERIVED, not vibes.** The hard rule: it needs to be derived from reason, otherwise it looks random. You must be able to point at the decode and say why a reason scored what it scored. See STEP 2. A random-looking split is a fail even if the designs are good.
6. **De-fingerprint.** Never surface another brand's exact winning phrase or an identifying detail. Instantiate the format for the pocket in front of you; don't recite a catalog. Any example you show should ride a stand-in pocket, never a real one you're actively working.
7. **Each run writes to its own folder** so runs never collide: `tattoos-not-fashion/runs/<pocket-slug>/`.

---

## THE FLOW (in order — never jump to generation)

### STEP 0 — Get the decoded pocket (the fodder)
Ask for the decode. Same input as `/make-the-flag`. Three ways it can arrive:
- **A finished decode** — a path to an `/identity-decoder` decode HTML (or the pocket + its psychology/language pasted in). The ideal input.
- **A pocket name only** (e.g. "golf dads") — you can proceed on a lighter read, but SAY it's lighter and offer to run `/identity-decoder` first for a real decode.
- **Nothing / just a broad niche** — offer to run the upstream chain: `/parade-hunt` → Pick the Pocket → `/identity-decoder`. Don't fabricate a decode.

Capture from the decode the raw material the three reasons feed on:
- **Trigger moments / origin** — why she started, a hard season she ran/knit/cooked through, a loss. → feeds *honor*.
- **Milestones, roles, dates, places, motifs** she's proud of — the first race, the role she earned, her city, her craft. → feeds *honor*.
- **Core values, the line she'd defend, the reframe she keeps making, the wry warning she gives** — what she stands for. → feeds *belief*.
- **Private shame / the wound** — the thing someone told her she isn't, that she's still healing. → feeds *belief* (the defiant answer to it).
- **Her aesthetic world** — the Pinterest-saved still life, the ritual objects, the scene she loves. → feeds *looks*.
- **Verbatim vocabulary + the repellent list** — the exact warm words she uses on herself, AND the tones that make her cringe (respect the repellent list absolutely; a single cringe word poisons the whole design).

### STEP 1 — REFLECT the pocket (mandatory, before scoring)
One warm message: reflect the pocket back in your words, name what jumps out and which reason it leans on ("this crowd's whole identity is a quiet defiance — she's been told she's *not a real [X]* and everything she'd wear answers that, so this is going to come out belief-heavy"), then say you're going to weight the three reasons to how she actually lives and go quiet. Do the reflect in her register, using her warm words, never a cringe word from the repellent list.

### STEP 2 — Score the three reasons and DERIVE the 20-slot split (the floor-and-lean, done silently)
This is the heart of the skill and the thing Andrew insisted be derived, not guessed. Do it in your head from the decode; **never show the math on screen.**

1. **Score each of the three reasons 0–3** for how much of the pocket's *emotional charge* lives there. Read it straight off the decode:
   - **Honor** high when there's a rich origin story, real milestones/dates/roles/places, a craft, a loss, a "who I became" arc. Low when the crowd is more about a stance than a personal history.
   - **Belief** high when there's a loud value, a defended line, a reframe she keeps making, and especially a **wound** ("someone told me I'm not a real ___") that everything she'd wear answers. Low when the crowd isn't defending anything.
   - **Looks** high when there's a genuine, specific aesthetic world she shops and saves (a whole Pinterest board). Low or **0** when the crowd is anti-aesthetic, has no coherent look, or would find a purely-pretty design hollow.
   - Ground every score in a specific thing from the decode. If you can't name why a reason scored what it did, you scored by vibes — go back.

2. **Distribute 20 slots by weight:** `slots(reason) = round( score(reason) ÷ total_score × 20 )`.

3. **Tie-break to sum to exactly 20.** After rounding, if the total is over 20, trim from the **lowest LIVE reason** (never below its floor of a couple designs while it's still live); if under 20, dump the remainder into the **heaviest reason**. The heaviest reason absorbs slop; the lightest live reason gives it up.

4. **A reason scored 0 is DROPPED entirely** — no token-weak designs padding the batch. Keep a one-line **"why 0"** for it (the on-camera teaching moment: "looks scored 0 because this crowd distrusts anything polished — a pretty-only design would read as fake to her").

5. **Sanity-check the split reads as obviously right for THIS pocket.** A defiance-driven crowd should come out belief-heavy; a milestone/legacy crowd honor-heavy; an aesthetic-first crowd with a thin story looks-heavier. If the split surprises you, re-read the decode before trusting it.

> **Worked examples (illustrative only — DERIVE fresh from every decode, never reuse these numbers):**
> - A milestone/legacy-driven crowd with no coherent aesthetic → honor 3 / belief 3 / looks 0 → **10 / 10 / 0** (looks dropped, shown greyed with its "why 0").
> - A defiance-driven crowd healing a "you're not a real ___" wound, with a real but wary aesthetic → belief 3 / honor 2 / looks 1 → **belief 11 / honor 6 / looks 3** (all three lanes live, belief clearly leads).

### STEP 3 — Author the concepts by spreading each reason across its SUB-ANGLES
20 prompts on one reason must NOT be 20 near-identical designs. Spread each reason's slots across its sub-angles. **These sub-angle banks are reason-generic — instantiate each one with THIS pocket's specific material; do not treat them as a fixed checklist to fill in order.**

**HONOR / remember** — designs for *her* specific history, not "honoring" in the abstract:
- *who she became* (the role/identity she earned) · *what she lost / ran through* (a hard season, honored quietly by a motif, never spelled out as pain) · *a milestone* (the first ___, the finish) · *a role* (the title she'd claim) · *a date* (personalizable, dated to HER day so it stops being a slogan) · *a place* (her city/route/kitchen — personalizable) · *a motif* (a near-textless line-art symbol of her origin).

**STATEMENT / belief** — the flag she wants on her chest:
- *the value* (the thing she'd defend at a dinner table) · *the inside line* (a phrase her tribe recognizes on sight) · *the reframe* (her private shame flipped into identity — the answer to the wound) · *the wry warning / the deal-with-it* (dry, self-possessed, a little funny) · *the coined word / definition* (a Maxxing-style mock-definition that redefines an insult as identity on her terms).

**LOOKS** — kept minimal, often ironic; skews to [D] design/motif:
- *the aesthetic still-life* (her ritual objects arranged as a line-art flat-lay) · *the near-textless illustration* (one pretty line-art object — deliberately says little about who she is; include it partly for contrast) · *the scene* (the pretty moment she loves, minimal words).

Each concept = a **title** + a **type tag** (`Phrase` / `Word` / `Design·mark`, with a sub-note: `seal` / `line-art` / `definition` / `back-print` / `personalizable` / `motif`) + a one-line **"why it's hers"** grounded in the decode + the full generation prompt (STEP 4). **Badge-check every one:** would she WEAR it to declare identity? If it's clever with no identity under it, cut and repick. Keep her warm words *on the shirt*; keep every repellent-list word off it.

### STEP 4 — Turn each concept into a REAL Ideogram V3 DESIGN prompt

> 🔒 **KEEP IT CLEAN:** design for the pocket in front of you, never by reciting some other brand's exact winning phrase. Nothing you show — reflect, brief, concepts, prompts, output HTML — should carry another brand's name or copy. Refer to the formats only by their generic names (the definition/Maxxing format, thin line-art, seal, back-print).

⛔ **The #1 failure mode is a LIGHT prompt.** A one-liner like *"print-ready t-shirt design, transparent background, bold lettering reading 'X', clean vector"* is a FAIL. So is a flat-lay/mockup framing — this skill's default is **flat white-ink artwork on a solid black background**, NOT "flat print on white background / centered chest print." The proven prompts are dense, spatially-composed art-direction specs. Match that depth or the design is worthless.

**Every generation prompt MUST follow this exact skeleton** (copy the depth, not any pocket's words):
- **Opens:** `A t-shirt graphic design on a solid black background.`
- **Explicit top-to-bottom visual hierarchy** — say what sits where, element by element: the word/phrase and its placement and weight (which line the claim lands on), tiny thin line-art icon accents, small delicate radiating lines above, a script line beneath, an arc, a seal ring — spatial, not a word-list.
- **The ink + style spine:** `White ink only, single color, flat design, thin line-art style` (plus a one-word tone that matches the concept — *quietly defiant, warm and knowing, proud and dignified, dry and self-possessed*).
- **Closes:** `clean and airy with breathing room between all elements. No gradients, no shadows, no mockup, no t-shirt.`

**The three design TYPES (vary them — don't force one skeleton):**
- **[P] Phrase** — the phrase IS the design. Emphasize the word the claim lands on with a heavier weight on its line. On 6+ words, note `arc it` or `back-print` for legibility.
- **[W] Word / coined** — tight single word/mark, OR the **definition / Maxxing format** (inlined below).
- **[D] Design / mark** — a circular **SEAL** (caps arced top + bottom, icon centered, thin ring), an icon **LEDGER/motif**, a **word hidden in an illustration**, or a pure **textless line-art motif**. Looks-reason and origin-motif concepts live here.

**The definition / Maxxing format (self-contained — the highest-converting typography style):** a mock-dictionary design. Top to bottom: (1) the coined **WORD** in large bold clean **sans-serif** block caps, "not rounded or bubbly, structured and confident like a professional logo"; (2) small delicate thin **radiating lines + a tiny heart accent** above, generous spacing; (3) a small **thin line-art thematic icon** below the word; (4) the **phonetic** in small clean text, e.g. `/slō·mak·sing/`; (5) the **`(verb)`** in small italic; (6) the **definition** as a clean uniform arc of hand-lettered script, ≤7 words, each word capitalized; (7) the ink/close spine above.
> Exemplar depth to match: *"A t-shirt graphic design on a solid black background. Large bold clean sans-serif block letters "PUZZLEMAXXING" centered at top, not rounded or bubbly, structured and confident like a professional logo. Small delicate thin radiating lines and a tiny star accent above. Generous spacing between elements. Below, a small thin line-art crossword grid with a tiny pencil. Below that in small clean text "/puz·əl·mak·sing/" and below that in small italic text "(verb)". Below that in a clean uniform arc, hand-lettered script text reads "Solving It One Square At A Time" with each word capitalized. White ink only, single color, flat design, thin line-art style icons, clean and airy with breathing room between all elements. No gradients, no shadows, no mockup, no t-shirt."*

**Text-length caution:** Ideogram accuracy drops past ~7–8 words of on-shirt text. Keep on-shirt text SHORT; flag any long line and give a shortened backup (the coined word tight, the definition ≤7 words).

**Ideogram V3 settings (baked into `generate.py --mode ideogram`):** `image_size: square_hd`, `rendering_speed: QUALITY`, `style: DESIGN`, `expand_prompt: false`. Locked negative: `"bubbly letters, rounded letters, childish, cartoon, mockup, t-shirt, person, body, gradient, shadow, 3d, photorealistic, cluttered, cramped, dictionary, book page, paper texture"`.

Aim for prompts in the **50–110 word range** like the reference examples. If a prompt is one sentence, it's too light — go back and art-direct it, element by element.

### STEP 5 — Build the deliverable HTML (mirror the approved output shape exactly)
Write `tattoos-not-fashion/runs/<pocket-slug>/concepts.html`, cleanly styled (a light, readable page — mono headers, generous whitespace, one accent color). Top to bottom:
1. **Header** — 🖋 icon block, `Tattoos, Not Fashion`, a one-line "worn like a tattoo" promise, and a `POCKET: <name>` tag.
2. **"The lens these were made through"** — recap the tattoo idea IN DESIGN TERMS (a design sells when worn like a tattoo, something she'd never take off; people get tattoos for three reasons — honor/remember, statement/belief, improve looks; those three are the lens). This exists so a cold reader gets why designs are grouped by three reasons. **NO raw scoring math on screen** (never show something like "3/3 → 10" — the reader sees only the plain-language result).
3. **"The brief"** — two sub-parts: **Who she is** (2–3 sentences from the decode, in her register) + **What that told us for the designs** (which reasons lead and WHY, then the plain-language split, e.g. "so the batch is 11 belief, 6 honor, 3 looks"). NO scoring notation.
4. A short **"How to read each one"** strip (why-line, then the ready-to-run prompt; the tag says Phrase / Word / Design·mark).
5. **20 concepts grouped by reason, heaviest reason first.** Each concept in a `.concept` block: a numbered badge (1–20, continuous across groups), the title, the type tag, the one-line why, then the prompt in a `.code-block`. A `.reason-banner` above each group (`N of 20 · the #1/#2/#3 reason` + a one-line why this reason leads for her). **No "Layout" line between why and prompt — just why → prompt.**
6. **Dropped reason** (only if one scored 0) — a greyed card with its "why 0" line.
7. **Gate card** — yellow, "Your move" / "generate a few, or leave it here?".
8. Footer line: `/tattoos-not-fashion · <pocket> · 20 concepts · <split>`.

### STEP 6 — GATE: present, then ask "generate? y/n"
Present the deliverable (path or file-browser URL — do NOT auto-open Chrome; Andrew is ~99% remote). Then ask, plainly: **"Want me to generate a few samples so you can see them, or leave it here with the concepts + prompts?"** Do NOT generate before this answer. This is the spend gate.

### STEP 7 — Optional generation (ONLY after a yes)
If yes, generate ~5 samples (a taste, not the whole batch) with the `--mode ideogram` capability. Reuse `generate.py` in this folder — do NOT re-implement the client. Build the prompts JSON (`[{"label","prompt"}]`), output to `tattoos-not-fashion/runs/<pocket-slug>/images/`, then build a small review grid and LOOK at the results before declaring done.

> ⚠️ Generation spends API credits. Only run it on an explicit yes. `generate.py` is a dry-run by default and requires `--go` to spend — it is NOT auto-invoked.

**Verified Ideogram mechanics (in `generate.py --mode ideogram`, do not deviate):** `FAL_KEY` from `$FAL_KEY` / `--env-file` / repo `.env` (no path hardcoded). `fal_client.subscribe("fal-ai/ideogram/v3", arguments={prompt, image_size:"square_hd", rendering_speed:"QUALITY", style:"DESIGN", expand_prompt:False, num_images:1, negative_prompt:<locked>})`, download the result URL to a PNG. Sequential loop, `num_images:1` each.

---

## OUTPUT
- `tattoos-not-fashion/runs/<pocket-slug>/concepts.html` — the deliverable (the shape in STEP 5). Cleanly styled, presentation-ready.
- `tattoos-not-fashion/runs/<pocket-slug>/prompts.json` — the 20 prompts as `[{label, prompt}]` (feeds `generate.py`).
- `tattoos-not-fashion/runs/<pocket-slug>/images/` — sample generations (ONLY if STEP 7 ran).
- `tattoos-not-fashion/runs/<pocket-slug>/review.html` — keep/regenerate grid (ONLY if STEP 7 ran).

## The chain, composed
This isn't one prompt — it's a chain of skills that hand off to each other: **Parade Hunt** (find the parade, pick the pocket) → **Identity Decoder** (know the pocket) → **Tattoos, Not Fashion** (make the tattoo). Each does a real job. This skill is the last link and it deliberately stops before spending money, so you decide what's worth generating. It's a sibling to **Make The Flag** — same input, a different lens (the three tattoo reasons instead of the twelve flags). Running both on one decode gives you two angles on the same pocket.

## Reference
- The engine this applies: the three tattoo reasons + the ink ladder (Pew Research Center's 2023 tattoo survey, n=8,480).
- `generate.py` (this folder) — the runnable generation capability (`--mode ideogram`), invoked ONLY after the STEP 6 gate.
